"""
PeoplePulse AI — Score Employees (Inference Only)
=====================================================
Loads the saved model artifacts (from save_model.py) and scores an
input CSV of employee data, WITHOUT retraining — much faster than
running the full train_attrition_model.py pipeline.

Usage:
    python ml_models/score_employees.py
    python ml_models/score_employees.py --input data/PeoplePulse_HR_Dataset.csv \
                                         --output ml_models/attrition_predictions.csv
"""

import argparse
import pathlib
import joblib
import pandas as pd
import numpy as np

PROJECT_ROOT = pathlib.Path(__file__).parent.parent
ARTIFACT_DIR = PROJECT_ROOT / "ml_models" / "artifacts"

# Re-import the feature engineering function from save_model.py to guarantee
# identical logic between training and inference (avoids train/serve skew)
import sys
sys.path.insert(0, str(PROJECT_ROOT / "ml_models"))
from save_model import engineer_features


def risk_tier(p: float, p50: float, p85: float, p975: float) -> str:
    if p >= p975: return "Critical"
    if p >= p85:  return "High"
    if p >= p50:  return "Medium"
    return "Low"


def main():
    parser = argparse.ArgumentParser(description="Score employees using the saved attrition model")
    parser.add_argument("--input", default=str(PROJECT_ROOT / "data" / "PeoplePulse_HR_Dataset.csv"))
    parser.add_argument("--output", default=str(PROJECT_ROOT / "ml_models" / "quick_scores.csv"),
                         help="Output path. Defaults to quick_scores.csv (NOT attrition_predictions.csv) "
                              "to avoid overwriting the full-schema file produced by train_attrition_model.py, "
                              "which includes SHAP driver columns this fast-scoring script does not compute.")
    args = parser.parse_args()

    model_path = ARTIFACT_DIR / "attrition_model.joblib"
    if not model_path.exists():
        print(f"❌ No saved model found at {model_path}")
        print("   Run 'python ml_models/save_model.py' first.")
        return

    print("Loading saved model artifacts...")
    model = joblib.load(model_path)
    preprocessor = joblib.load(ARTIFACT_DIR / "preprocessor.joblib")
    feature_cols = joblib.load(ARTIFACT_DIR / "feature_columns.joblib")

    print(f"Loading input data: {args.input}")
    df = pd.read_csv(args.input)
    df["Exit_Reason"] = df["Exit_Reason"].fillna("N/A")

    fe = engineer_features(df)
    X = fe[feature_cols].copy()

    print("Transforming features and scoring...")
    X_transformed = preprocessor.transform(X)
    proba = model.predict_proba(X_transformed)[:, 1]

    # Percentile thresholds computed on the ACTIVE population only,
    # consistent with the methodology in train_attrition_model.py Step 10
    active_mask = (df["Attrition"] == "No").values
    active_proba = proba[active_mask] if active_mask.any() else proba
    p50, p85, p975 = np.percentile(active_proba, [50, 85, 97.5])

    risk_scores = np.round(proba * 100, 1)
    tiers = [risk_tier(p, p50, p85, p975) for p in proba]

    output = df[["Employee_ID", "Employee_Name", "Department", "Job_Role",
                 "Job_Level", "Manager_ID", "Attrition"]].copy()
    output["Risk_Score"] = risk_scores
    output["Risk_Tier"] = tiers
    output["Model_Probability"] = proba.round(4)
    output = output.sort_values("Risk_Score", ascending=False).reset_index(drop=True)

    output.to_csv(args.output, index=False)
    print(f"\n✅ Scored {len(output):,} employees")
    print(f"✅ Output saved: {args.output}")
    print(f"\nRisk tier distribution:")
    print(output["Risk_Tier"].value_counts().reindex(["Low","Medium","High","Critical"]))


if __name__ == "__main__":
    main()
