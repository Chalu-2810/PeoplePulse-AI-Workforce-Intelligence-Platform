"""
PeoplePulse AI — Save Model Artifacts
========================================
Retrains the production model pipeline (preprocessing + Logistic Regression,
matching the model selected as "production candidate" in
train_attrition_model.py) and persists it to disk via joblib, so future
scoring runs don't need to retrain from scratch.

Usage:
    python ml_models/save_model.py
"""

import sys
import pathlib
import joblib
import pandas as pd
import numpy as np

from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer

PROJECT_ROOT = pathlib.Path(__file__).parent.parent
ARTIFACT_DIR = PROJECT_ROOT / "ml_models" / "artifacts"
ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """Mirrors the feature engineering block in train_attrition_model.py Step 2."""
    fe = df.copy()

    level_medians = fe.groupby('Job_Level')['Salary'].median()
    fe['Level_Median_Salary'] = fe['Job_Level'].map(level_medians)
    fe['Compa_Ratio'] = (fe['Salary'] / fe['Level_Median_Salary']).round(4)
    fe['Pay_Deficit_Flag'] = (fe['Compa_Ratio'] < 0.85).astype(int)
    fe['Pay_Premium_Flag'] = (fe['Compa_Ratio'] > 1.15).astype(int)

    fe['Expected_Promotions'] = fe['Years_At_Company'] / 2.8
    fe['Promotion_Gap'] = np.clip(fe['Expected_Promotions'] - fe['Promotions'], 0, 15).round(2)
    fe['Promotion_Velocity'] = np.where(
        fe['Promotions'] > 0, fe['Years_At_Company'] / fe['Promotions'], fe['Years_At_Company']
    ).round(2)

    fe['Eng_Sat_Index'] = (fe['Engagement_Score'] * fe['Satisfaction_Score'] / 100).round(2)
    fe['Disengagement_Score'] = (100 - fe['Engagement_Score']).round(2)
    fe['Wellbeing_Composite'] = (
        fe['Engagement_Score'] * 0.4 + fe['Satisfaction_Score'] * 0.35 + fe['Attendance_Pct'] * 0.25
    ).round(2)

    fe['Chronic_Absence_Flag'] = (fe['Attendance_Pct'] < 85).astype(int)
    fe['Early_Tenure_Flag'] = (fe['Years_At_Company'] < 2).astype(int)
    fe['Late_Career_Flag'] = (fe['Years_At_Company'] > 8).astype(int)
    fe['HIPO_At_Risk'] = ((fe['Performance_Rating'] >= 4) & (fe['Engagement_Score'] < 65)).astype(int)
    fe['PIP_Risk'] = (fe['Performance_Rating'] == 1).astype(int)
    fe['Underpaid_HighPerformer'] = ((fe['Performance_Rating'] >= 4) & (fe['Compa_Ratio'] < 0.95)).astype(int)

    level_avg_training = fe.groupby('Job_Level')['Training_Hours'].mean()
    fe['Level_Avg_Training'] = fe['Job_Level'].map(level_avg_training)
    fe['Training_Ratio'] = (fe['Training_Hours'] / fe['Level_Avg_Training']).round(4)
    fe['Training_Underinvestment_Flag'] = (fe['Training_Ratio'] < 0.6).astype(int)

    level_order = {'L1':1,'L2':2,'L3':3,'L4':4,'L5':5,'L6':6,'L7':7,'L8':8}
    fe['Job_Level_Num'] = fe['Job_Level'].map(level_order)

    high_att_depts = ['Customer Success','Sales','Operations','Marketing']
    fe['High_Att_Dept'] = fe['Department'].isin(high_att_depts).astype(int)

    fe['Is_Remote'] = (fe['Work_Mode'] == 'Remote').astype(int)
    fe['Is_Hybrid'] = (fe['Work_Mode'] == 'Hybrid').astype(int)
    fe['Leave_Normalized'] = (fe['Leave_Count'] / 30).round(4)

    return fe


def main():
    print("Loading dataset and engineering features...")
    df = pd.read_csv(PROJECT_ROOT / "data" / "PeoplePulse_HR_Dataset.csv")
    df['Exit_Reason'] = df['Exit_Reason'].fillna('N/A')
    fe = engineer_features(df)

    DROP_COLS = [
        'Employee_ID', 'Employee_Name', 'Manager_ID', 'Job_Level',
        'Performance_Label', 'Exit_Reason', 'Attrition',
        'Level_Median_Salary', 'Level_Avg_Training',
    ]
    FEATURE_COLS = [c for c in fe.columns if c not in DROP_COLS]
    X = fe[FEATURE_COLS].copy()
    y = (fe['Attrition'] == 'Yes').astype(int)

    CATEGORICAL_COLS = X.select_dtypes(include=['object']).columns.tolist()
    NUMERIC_COLS = X.select_dtypes(include=['number']).columns.tolist()

    preprocessor = ColumnTransformer([
        ('num', Pipeline([
            ('impute', SimpleImputer(strategy='median')),
            ('scale', StandardScaler())
        ]), NUMERIC_COLS),
        ('cat', OneHotEncoder(handle_unknown='ignore', drop='first'), CATEGORICAL_COLS),
    ])

    print("Fitting preprocessor + Logistic Regression (production model)...")
    X_transformed = preprocessor.fit_transform(X)

    model = LogisticRegression(class_weight='balanced', max_iter=1000, C=1.0, random_state=42)
    model.fit(X_transformed, y)

    joblib.dump(model, ARTIFACT_DIR / "attrition_model.joblib")
    joblib.dump(preprocessor, ARTIFACT_DIR / "preprocessor.joblib")
    joblib.dump(FEATURE_COLS, ARTIFACT_DIR / "feature_columns.joblib")

    print(f"✅ Model saved: {ARTIFACT_DIR / 'attrition_model.joblib'}")
    print(f"✅ Preprocessor saved: {ARTIFACT_DIR / 'preprocessor.joblib'}")
    print(f"✅ Feature column list saved: {ARTIFACT_DIR / 'feature_columns.joblib'}")
    print(f"\nTo reload: joblib.load('{ARTIFACT_DIR / 'attrition_model.joblib'}')")


if __name__ == "__main__":
    main()
