# PeoplePulse AI — Testing & Validation Guide

Three layers of validation exist in this project: SQL-level (database
integrity), Python-level (pytest suite), and ML-level (model calibration).
All three should pass before considering a deployment "production ready."

---

## Layer 1 — Database Validation (SQL)

```bash
psql -h localhost -U peoplepulse_app -d peoplepulse -f sql/validation/run_validation.sql
```

Runs 8 query sets covering:
1. **Row counts** — confirms 10,000 employees, 11 departments, etc.
2. **Referential integrity** — 0 orphaned foreign keys
3. **Null/completeness checks** — required fields are never null
4. **Range/domain checks** — confirms CHECK constraints are enforced
5. **Business logic sanity** — attrition rate, avg salary, etc. within documented bands
6. **View validation** — all 3 analytical views resolve and return data
7. **Org hierarchy walkability** — recursive CTE confirms no circular manager references
8. **Flight risk tier validation** — actual attrition increases monotonically across risk tiers (requires `hr.flight_risk_score` populated)

Pass condition for each query is documented inline as a SQL comment immediately following it.

---

## Layer 2 — Python Test Suite (pytest)

```bash
pytest tests/ -v
```

**77 tests across 4 files:**

### `test_data_quality.py` (26 tests)
Schema integrity (row count, column presence, ID uniqueness), domain
constraints (age/salary/score ranges), referential integrity (manager
chains, exit reason consistency), and business logic sanity (attrition
rate band, salary band, engagement band).

### `test_kpi_validation.py` (17 tests)
Recomputes KPIs from the KPI Framework (`docs/04_kpi_framework.md`)
directly from raw data and checks against documented value bands —
catches silent drift if the dataset changes without updating documentation.

### `test_model_validation.py` (14 tests)
The most important file for ML governance. Includes:
- `test_monotonic_attrition_rate_across_tiers` — **the test that would
  have caught the original fixed-threshold calibration bug** documented
  in `docs/12_career_assets.md`. If you ever modify the risk segmentation
  logic, this test is your safety net.
- `test_critical_tier_meaningfully_riskier_than_low` — enforces a minimum
  1.5x lift between tiers
- `test_all_models_beat_random_baseline` — every trained model must exceed AUC 0.5

### `test_dashboard_validation.py` (20 tests)
Authentication (all 6 demo accounts), RBAC (role→page access matrix),
row-level security (HRBP department isolation — including a check that
two different HRBPs see disjoint employee sets), data loading integrity,
and export function smoke tests (Excel/PDF byte validation).

**Run a single file:**
```bash
pytest tests/test_model_validation.py -v
```

**Run with coverage report:**
```bash
pytest tests/ --cov=streamlit_app --cov=ml_models --cov-report=html
open htmlcov/index.html
```

---

## Layer 3 — ML Model Calibration Validation

This is conceptually layer 2's `test_model_validation.py`, but worth
calling out separately because it's the most domain-specific check and
the one most likely to silently break after a well-intentioned code change
(e.g., switching `class_weight` parameters, changing the train/test split,
or modifying feature engineering).

**The core invariant that must always hold:**
```
Actual attrition rate (Low tier) < Actual attrition rate (Medium tier)
                                  < Actual attrition rate (High tier)
                                  < Actual attrition rate (Critical tier)
```

If you change ANYTHING in `ml_models/train_attrition_model.py` related to
model training or risk segmentation, run this immediately after:
```bash
python ml_models/train_attrition_model.py
pytest tests/test_model_validation.py::TestRiskTierCalibration -v
```

If `test_monotonic_attrition_rate_across_tiers` fails, the most common
cause (per the documented Phase 8 incident) is reverting from
percentile-based thresholds back to fixed probability cutoffs without
accounting for `class_weight='balanced'`'s effect on the probability
distribution. See the risk segmentation methodology comment block at the
top of Step 10 in `train_attrition_model.py` for the full explanation.

---

## Continuous Integration Recommendation

If setting up CI (GitHub Actions example):
```yaml
name: PeoplePulse AI Tests
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - run: pip install -r requirements.txt
      - run: pytest tests/ -v --cov
      - run: python -c "import ast,glob; [ast.parse(open(f).read()) for f in glob.glob('streamlit_app/**/*.py', recursive=True)]"
```

This validates both the test suite AND that every Streamlit page file has
valid Python syntax (catching a broken page before it reaches production).

---

## Validation Summary Table

| Layer | Tool | Command | What It Catches |
|---|---|---|---|
| Database | SQL | `psql -f sql/validation/run_validation.sql` | Schema/load errors, orphaned FKs |
| Data Quality | pytest | `pytest tests/test_data_quality.py` | Dataset structural/statistical drift |
| KPIs | pytest | `pytest tests/test_kpi_validation.py` | KPI logic drift vs documentation |
| ML Model | pytest | `pytest tests/test_model_validation.py` | Calibration bugs, model regressions |
| Application | pytest | `pytest tests/test_dashboard_validation.py` | Auth/RBAC bugs, broken pages |
| Full Suite | pytest | `pytest tests/ -v` | All of the above, 77 tests, <5 sec |
