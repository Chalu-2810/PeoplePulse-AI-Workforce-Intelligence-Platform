# PeoplePulse AI — Dataset Design Reference

This is a navigation pointer. The full Phase 3 dataset design documentation
(causal generation rules, data dictionary, business assumptions, and an
interactive 6-tab profiling dashboard) lives in:

    data/dataset_profile.html   <- open in any browser
    data/generate_hr_dataset.py <- fully commented generator source

Open `data/dataset_profile.html` for:
- Attrition analysis (department/tenure breakdowns)
- Workforce composition (gender, location, work mode)
- Compensation analysis (salary bands, pay gap)
- Performance distribution
- Full design-rules narrative (causal model explanation)
- Complete data dictionary (all 24 columns, type, generation rule)
