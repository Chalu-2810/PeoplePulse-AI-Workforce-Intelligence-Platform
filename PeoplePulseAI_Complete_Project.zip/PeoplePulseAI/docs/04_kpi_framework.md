# PeoplePulse AI — Enterprise Workforce KPI Framework
## Phase 5 | Prepared in the style of a Big 4 People Analytics Practice
### Confidential | For CHRO, HR Director, and Executive Leadership Use

---

## EXECUTIVE SUMMARY

This framework defines **52 KPIs across 10 strategic domains**, each calibrated against industry benchmarks (SHRM, Mercer, Gallup, LinkedIn Talent Solutions) and mapped to the PeoplePulse AI data model (`hr.Employee` table, 10,000 employees). Every KPI includes a formula, executive interpretation, recommended visualization, and — critically — the **decision it should trigger**. This is the difference between a metrics list and a management system: each number here exists because an executive needs to act differently depending on its value.

KPIs are organized so that **leading indicators** (engagement, promotion gap, compa-ratio) appear before **lagging indicators** (attrition rate, exit reasons) within each domain — reflecting the principle that a mature People Analytics function manages causes, not just outcomes.

---

# 1. WORKFORCE KPIs

### 1.1 Total Headcount
**Definition:** Count of all active employees at a point in time.
**Formula:** `COUNT(EmployeeID) WHERE Attrition = 'No'`
**Business Meaning:** The fundamental denominator for every workforce ratio. Drives facilities, payroll, and benefits planning.
**Executive Interpretation:** A headcount number alone means nothing — it must be read against budget and against the prior period. A 5% headcount increase with flat revenue signals declining labor productivity.
**Recommended Visualization:** KPI card with trend sparkline; line chart vs. budgeted headcount.
**Decision-Making Impact:** Triggers hiring freeze conversations if headcount exceeds budget by >3%; triggers backfill prioritization discussions if below budget during growth periods.

---

### 1.2 Headcount Growth Rate
**Definition:** Percentage change in headcount period-over-period.
**Formula:** `(Headcount_CurrentPeriod − Headcount_PriorPeriod) / Headcount_PriorPeriod × 100`
**Business Meaning:** Indicates organizational momentum — growth, stability, or contraction.
**Executive Interpretation:** Growth rate should track within ±2 points of revenue growth rate. A wide divergence (headcount growing 15% while revenue grows 5%) signals operating leverage erosion — a CFO red flag.
**Recommended Visualization:** Combo chart — headcount growth (bars) overlaid with revenue growth (line).
**Decision-Making Impact:** Informs the annual operating plan headcount ask; triggers span-of-control review if growth outpaces manager capacity.

---

### 1.3 Span of Control
**Definition:** Average number of direct reports per manager.
**Formula:** `COUNT(Employees WHERE ManagerID IS NOT NULL) / COUNT(DISTINCT ManagerID)`
**Business Meaning:** Reflects organizational efficiency and management overhead. PeoplePulse benchmark: 6–10 for IC managers, 4–8 for Director+.
**Executive Interpretation:** Span <4 across the org signals excessive management layers — a cost reduction opportunity (delayering). Span >12 signals manager burnout risk and quality-of-coaching erosion.
**Recommended Visualization:** Histogram of span distribution by management level; outlier table (managers with span >12 or <3).
**Decision-Making Impact:** Drives delayering initiatives (cost savings of $2–5M for a 10,000-person org if 1 management layer is removed); triggers manager workload redistribution.

---

### 1.4 Organizational Pyramid Ratio
**Definition:** Ratio of Individual Contributors (IC) to People Managers to Executives.
**Formula:** `COUNT(CareerTrack='IC') : COUNT(CareerTrack='Manager') : COUNT(CareerTrack='Executive')`
**Business Meaning:** Healthy enterprise ratio is approximately 70:25:5. Deviation signals top-heavy cost structure or insufficient leadership bench.
**Executive Interpretation:** A ratio of 55:35:10 (top-heavy) typically correlates with 15–20% higher people cost per unit of output versus a 70:25:5 benchmark peer.
**Recommended Visualization:** Stacked horizontal bar (org pyramid visualization) by department.
**Decision-Making Impact:** Informs restructuring and cost-optimization mandates from the CFO/CEO; flags departments needing leadership pipeline investment.

---

### 1.5 FTE Utilization Rate
**Definition:** Ratio of full-time-equivalent capacity actually deployed against budgeted capacity.
**Formula:** `SUM(FTE_Value) / Budgeted_FTE × 100`
**Business Meaning:** Distinguishes headcount (people) from capacity (hours). Critical when part-time and contractor mix shifts.
**Executive Interpretation:** Utilization <95% with active hiring pipelines suggests time-to-fill issues are creating capacity gaps — directly impacting delivery timelines.
**Recommended Visualization:** Gauge chart against 100% target line.
**Decision-Making Impact:** Triggers contractor backfill decisions for capacity gaps that cannot wait for full-time hiring cycles.

---

### 1.6 Remote/Hybrid/On-site Mix
**Definition:** Distribution of workforce across work location modalities.
**Formula:** `COUNT(WorkMode = X) / Total Headcount × 100` for X in {On-site, Hybrid, Remote}
**Business Meaning:** Drives real estate strategy, collaboration tooling investment, and culture initiatives.
**Executive Interpretation:** PeoplePulse data shows 27% fully remote — if real estate is sized for 80% on-site capacity, the company is over-leased by an estimated 35–40%.
**Recommended Visualization:** Donut chart with real estate cost overlay.
**Decision-Making Impact:** Directly informs real estate portfolio decisions (lease renewals, office consolidation) — potential 7-figure annual savings for large enterprises.

---

# 2. ATTRITION KPIs

### 2.1 Overall Attrition Rate
**Definition:** Percentage of the workforce that separated (voluntary + involuntary) within the period.
**Formula:** `COUNT(Attrition='Yes') / Total Headcount × 100`
**Business Meaning:** The single most-watched workforce metric by boards. PeoplePulse current: **23.8%**. Industry benchmark (tech, high-growth): 18–22%; (mature enterprise): 10–15%.
**Executive Interpretation:** At 23.8%, PeoplePulse sits 2–6 points above benchmark. At an average replacement cost of 1.5× salary ($170K avg salary → $255K per exit), 2,380 exits represent **~$607M in replacement cost exposure** annually at this scale — though most of this is "natural" turnover; the regrettable subset (below) is the actionable figure.
**Recommended Visualization:** KPI card with RAG status; 12-month trend line with benchmark band overlay.
**Decision-Making Impact:** Above-benchmark attrition triggers a CHRO mandate for root-cause analysis within 30 days; below-benchmark may indicate insufficient performance-based exits (stagnant talent).

---

### 2.2 Voluntary Attrition Rate
**Definition:** Percentage of separations initiated by the employee.
**Formula:** `COUNT(Attrition='Yes' AND ExitReason <> 'Involuntary') / Total Headcount × 100`
**Business Meaning:** Isolates the controllable component of attrition — the part HR interventions can actually influence.
**Executive Interpretation:** Voluntary attrition trending upward while involuntary stays flat indicates a retention problem, not a performance management problem — different intervention required.
**Recommended Visualization:** Stacked area chart — voluntary vs. involuntary over time.
**Decision-Making Impact:** Voluntary attrition is the KPI that justifies retention program budget requests to the CFO.

---

### 2.3 Regrettable Attrition Rate
**Definition:** Percentage of voluntary exits among employees rated "Exceeds Expectations" or "Distinguished" (Performance Rating ≥ 4).
**Formula:** `COUNT(Attrition='Yes' AND PerformanceRating>=4) / Total Headcount × 100`
**Business Meaning:** The single highest-value metric in this framework — it quantifies the loss of talent the organization explicitly wanted to keep.
**Executive Interpretation:** In the PeoplePulse dataset, high performers (rating ≥4) represent 31.5% of the workforce but their loss carries disproportionate strategic cost: lost institutional knowledge, team morale impact (each regrettable exit increases the flight risk of remaining team members by an estimated 8–12%), and a replacement who takes 6–12 months to reach prior productivity.
**Recommended Visualization:** KPI card in red/amber/green; department breakdown bar chart sorted descending.
**Decision-Making Impact:** This is the metric that should appear on the CEO's desk. A regrettable attrition rate >5% of total headcount should trigger mandatory stay interviews for all remaining high performers in the affected department within 60 days.

---

### 2.4 New Hire Attrition Rate (90-Day / First-Year)
**Definition:** Percentage of employees with tenure <1 year who have separated.
**Formula:** `COUNT(Attrition='Yes' AND YearsAtCompany<1) / COUNT(YearsAtCompany<1 at hire) × 100`
**Business Meaning:** Diagnoses onboarding quality and hiring-fit accuracy. PeoplePulse shows **29.8%** attrition in the <1yr cohort — nearly 1 in 3 new hires leave within their first year.
**Executive Interpretation:** This is an extremely expensive failure mode — sunk recruiting cost, onboarding investment, and team disruption with zero productivity return. A rate this high (vs. healthy benchmark of 10–15%) suggests either a hiring process accuracy problem (wrong-fit candidates being selected) or an onboarding experience problem (good candidates leaving due to poor first-90-days experience).
**Recommended Visualization:** Funnel chart — hires → 30 day → 90 day → 1 year retained, with drop-off percentages.
**Decision-Making Impact:** A rate above 20% should trigger an immediate audit of (a) the interview/assessment process for false positives and (b) the onboarding program — these require different remediation budgets and owners (TA vs. L&D).

---

### 2.5 Attrition Rate by Tenure Cohort
**Definition:** Attrition rate segmented into tenure bands (<1yr, 1-2yr, 2-3yr, 3-5yr, 5-8yr, 8-12yr, 12yr+).
**Formula:** `COUNT(Attrition='Yes') / COUNT(*) × 100, GROUP BY TenureBand`
**Business Meaning:** Reveals the "survival curve" of the organization — where in the employee lifecycle people decide to leave.
**Executive Interpretation:** PeoplePulse data shows a bimodal pattern: high exits in years 0–2 (honeymoon-period mismatch) and a secondary rise at 8–12 years (career plateau / mid-career pivot). These require entirely different interventions — onboarding fixes for the first peak, career pathing and sabbatical/internal mobility programs for the second.
**Recommended Visualization:** Line chart (survival curve) with two annotated "risk zones."
**Decision-Making Impact:** Tenure-segmented attrition directly informs where L&D and career development budget should be concentrated.

---

### 2.6 Attrition Cost Impact
**Definition:** Total estimated financial cost of attrition for the period.
**Formula:** `SUM(Salary × 1.5) WHERE Attrition='Yes'` *(1.5× is the SHRM-validated average replacement cost multiplier)*
**Business Meaning:** Translates an HR metric into a CFO-readable number.
**Executive Interpretation:** This single number is the strongest lever HR has in budget negotiations — it reframes retention investment not as a "soft" cost but as risk mitigation against a quantified financial exposure.
**Recommended Visualization:** Large KPI card in currency format, with year-over-year delta.
**Decision-Making Impact:** Justifies retention program ROI calculations — e.g., "a $2M engagement investment that reduces attrition by 3 points saves an estimated $X in replacement costs."

---

# 3. RETENTION KPIs

### 3.1 Overall Retention Rate
**Definition:** Inverse of attrition rate — percentage of workforce retained over the period.
**Formula:** `100% − Attrition Rate`
**Business Meaning:** Framing matters — "76.2% retention" reads differently to a board than "23.8% attrition," even though mathematically identical. Use retention framing for positive narrative, attrition framing for problem-solving narrative.
**Executive Interpretation:** Retention rate trends should be read alongside *who* is being retained (see 3.2).
**Recommended Visualization:** Gauge or radial chart against target retention rate (e.g., 85%).
**Decision-Making Impact:** Sets the annual retention target embedded in HR's OKRs and CHRO performance objectives.

---

### 3.2 High-Performer Retention Rate
**Definition:** Retention rate specifically among employees rated 4 or 5.
**Formula:** `COUNT(PerformanceRating>=4 AND Attrition='No') / COUNT(PerformanceRating>=4) × 100`
**Business Meaning:** The quality-adjusted retention metric — retaining 90% of your workforce means nothing if the 10% you lose are all top performers.
**Executive Interpretation:** This should always be reported alongside overall retention. If overall retention is 76% but high-performer retention is 68%, the organization has an inverted retention problem — it's disproportionately keeping its lower performers.
**Recommended Visualization:** Side-by-side bar comparison: Overall Retention vs. High-Performer Retention.
**Decision-Making Impact:** A gap >5 points between overall and high-performer retention triggers a targeted retention program (equity refreshers, accelerated promotion review) for the high-performer population specifically.

---

### 3.3 Internal Mobility Rate
**Definition:** Percentage of open positions filled by internal candidates (transfers/promotions) vs. external hires.
**Formula:** `COUNT(RecruitmentSource='Internal Transfer') / Total Hires × 100`
**Business Meaning:** Internal mobility is both a retention *driver* (career growth visibility reduces flight risk) and a retention *outcome* (a healthy culture promotes mobility).
**Executive Interpretation:** PeoplePulse shows 5.3% internal transfer rate — well below the LinkedIn benchmark of 30-40% internal fill rate for healthy organizations. This signals either (a) insufficient internal career pathing visibility, or (b) a "grass is greener" culture where internal candidates don't apply for internal roles.
**Recommended Visualization:** Stacked bar — Internal vs. External fills, trended quarterly.
**Decision-Making Impact:** Low internal mobility (<15%) should trigger investment in an internal talent marketplace tool and mandatory internal-first posting policies for non-executive roles.

---

### 3.4 Promotion Velocity
**Definition:** Average time (or tenure) between promotions for employees with at least one promotion.
**Formula:** `AVG(YearsAtCompany / Promotions) WHERE Promotions > 0`
**Business Meaning:** Measures career progression speed — a leading indicator for high-performer flight risk.
**Executive Interpretation:** PeoplePulse's implied promotion cycle is ~2.8 years. Employees significantly exceeding this (the "Promotion Gap" metric) without a promotion are measurably more likely to be in the regrettable attrition pool.
**Recommended Visualization:** Histogram of years-since-last-promotion, with a vertical line at the 2.8-year benchmark.
**Decision-Making Impact:** Feeds the "Promotion Gap" alert system (see Phase 4 CTE query) that flags individuals to HRBPs for proactive career conversations.

---

### 3.5 Critical Talent Retention Rate
**Definition:** Retention rate among employees flagged as occupying business-critical roles (e.g., sole subject-matter experts, succession-critical leadership).
**Formula:** `COUNT(CriticalRole=1 AND Attrition='No') / COUNT(CriticalRole=1) × 100`
**Business Meaning:** Not all roles carry equal organizational risk if vacated. This KPI focuses retention attention where business continuity risk is highest.
**Executive Interpretation:** A single critical-role departure (e.g., the only engineer who understands a legacy payment system) can have business continuity impact disproportionate to its 1-person headcount weight.
**Recommended Visualization:** Table listing critical roles with current incumbent flight-risk score and succession-readiness status.
**Decision-Making Impact:** Directly informs succession planning prioritization and retention-bonus allocation decisions — these are the people who get retention packages even in cost-cutting cycles.

---

# 4. ENGAGEMENT KPIs

### 4.1 Average Engagement Score
**Definition:** Mean engagement survey score across the workforce (0–100 scale).
**Formula:** `AVG(EngagementScore)`
**Business Meaning:** The macro pulse-check on organizational health. PeoplePulse current: **67.3** — Gallup's global benchmark for "engaged" employees sits around 65–70 on comparable scales, placing PeoplePulse roughly at parity, with room for improvement toward "best employer" status (75+).
**Executive Interpretation:** A 1-point movement in average engagement at enterprise scale typically correlates with measurable shifts in productivity (Gallup research: ~0.4% revenue per employee per engagement point in service industries).
**Recommended Visualization:** Large KPI card with historical trend line and industry benchmark band.
**Decision-Making Impact:** Sets the baseline against which all engagement intervention programs (manager training, recognition programs, flexible work policies) are measured for ROI.

---

### 4.2 eNPS (Employee Net Promoter Score)
**Definition:** Percentage of promoters (satisfaction ≥80) minus percentage of detractors (satisfaction <40).
**Formula:** `(%Promoters − %Detractors)`, scale −100 to +100
**Business Meaning:** A single-number "would you recommend working here" proxy, widely used in board reporting due to its familiarity (NPS is a CFO/CEO-native concept from customer experience).
**Executive Interpretation:** eNPS scores: <0 = serious culture problem; 0–20 = needs improvement; 20–50 = good; 50+ = best-in-class (e.g., top employer brand companies).
**Recommended Visualization:** Single large number with color-coded zone indicator, trended over time.
**Decision-Making Impact:** eNPS below 0 should escalate immediately to the CEO/Board as a culture-risk item — it indicates the workforce, on net, would actively discourage others from joining.

---

### 4.3 Flight Risk Distribution (% High Risk)
**Definition:** Percentage of active employees with engagement score <40 (ML-derived flight risk tier "High Risk").
**Formula:** `COUNT(EngagementScore<40 AND Attrition='No') / Active Headcount × 100`
**Business Meaning:** A forward-looking metric — this is the population most likely to contribute to *next period's* attrition rate.
**Executive Interpretation:** This is the most actionable engagement metric because it's a *named list*, not an aggregate. HR can intervene with these specific 275 individuals (per the Phase 4 ML model) before they resign.
**Recommended Visualization:** KPI card + drill-through table to named employee list (HRBP access only — PII sensitive).
**Decision-Making Impact:** Directly drives the HRBP weekly action queue — each high-risk employee should have a documented retention conversation within 2 weeks of being flagged.

---

### 4.4 Engagement-Satisfaction Gap
**Definition:** Difference between average Engagement Score and average Satisfaction Score.
**Formula:** `AVG(EngagementScore) − AVG(SatisfactionScore)`
**Business Meaning:** Engagement measures emotional commitment to the mission; satisfaction measures contentment with day-to-day conditions (pay, workload, manager). A large positive gap (engaged but unsatisfied) often signals "I believe in this company but I'm being underpaid/overworked" — a compensation or workload issue masked by mission alignment.
**Executive Interpretation:** A growing gap is an early warning that even mission-aligned employees are accumulating dissatisfaction that will eventually override their engagement — a slow-burning attrition risk.
**Recommended Visualization:** Dual-line chart, engagement and satisfaction trended together with the gap shaded.
**Decision-Making Impact:** A widening gap should trigger compensation benchmarking review before it triggers a culture/mission communication campaign — fix the root cause, not the symptom.

---

### 4.5 Engagement by Tenure (Honeymoon Curve)
**Definition:** Average engagement score segmented by tenure band.
**Formula:** `AVG(EngagementScore), GROUP BY TenureBand`
**Business Meaning:** Reveals the emotional trajectory of the employee lifecycle.
**Executive Interpretation:** PeoplePulse data shows the classic "honeymoon dip" — new hires arrive engaged, dip in years 1–3 as reality sets in, then stabilize for long-tenured survivors. The years 1–3 dip is the highest-leverage intervention window — these employees are engaged enough to still be reachable but disillusioned enough to be at risk.
**Recommended Visualization:** Line chart, engagement score (Y) vs. tenure band (X), with annotated intervention zone.
**Decision-Making Impact:** Justifies "year 2 check-in" program design — a structured career conversation specifically timed to counteract the natural engagement dip.

---

# 5. ATTENDANCE KPIs

### 5.1 Average Attendance Rate
**Definition:** Mean percentage attendance across the workforce.
**Formula:** `AVG(AttendancePct)`
**Business Meaning:** A direct productivity and capacity-planning input. PeoplePulse average: **90.2%**.
**Executive Interpretation:** Attendance below 90% enterprise-wide, when annualized, represents nearly 5 weeks of lost capacity per employee per year — a hidden cost often absent from headcount-based capacity models.
**Recommended Visualization:** KPI card with department breakdown table.
**Decision-Making Impact:** Feeds capacity planning models for workforce scheduling functions (especially in Operations/Customer Success where coverage gaps have direct service-level impact).

---

### 5.2 Chronic Absenteeism Rate
**Definition:** Percentage of employees with attendance below 85%.
**Formula:** `COUNT(AttendancePct<85) / Total Headcount × 100`
**Business Meaning:** Identifies a population with attendance patterns significantly below norm — often correlated with disengagement, burnout, or undisclosed personal/health circumstances.
**Executive Interpretation:** Chronic absenteeism is a *leading* indicator for attrition with roughly a 1-quarter lag — employees who are "checked out" attendance-wise are frequently 60–90 days from formal resignation.
**Recommended Visualization:** Bar chart by department, with overlay of corresponding attrition rate to visually demonstrate the correlation.
**Decision-Making Impact:** Triggers wellness-check outreach from HRBPs — distinct in tone from performance management, framed around employee support rather than discipline.

---

### 5.3 Leave Utilization Rate
**Definition:** Average leave days taken as a percentage of entitled leave days.
**Formula:** `AVG(LeaveCount) / Standard_Entitlement × 100`
**Business Meaning:** Both under- and over-utilization are signals. Under-utilization (<50% of entitlement) correlates with burnout culture; over-utilization concentrated in specific individuals may signal disengagement or health issues.
**Executive Interpretation:** A workforce-wide leave utilization below 60% in a 20-day-entitlement culture suggests employees feel unable to disconnect — a burnout risk factor that precedes both attrition and productivity decline.
**Recommended Visualization:** Distribution histogram with a "healthy zone" band (60–90% utilization) highlighted.
**Decision-Making Impact:** Low utilization triggers "use it or lose it" policy reviews and manager training on modeling healthy time-off behavior.

---

### 5.4 Attendance-Engagement Correlation Coefficient
**Definition:** Statistical correlation between individual attendance percentage and engagement score.
**Formula:** `CORR(AttendancePct, EngagementScore)`
**Business Meaning:** Validates whether attendance can be used as a low-cost proxy signal for engagement in real-time monitoring (engagement surveys are periodic; attendance is continuous).
**Executive Interpretation:** A strong positive correlation (PeoplePulse: r≈0.62) means attendance data — already captured continuously via timekeeping systems — can serve as a daily "engagement pulse" without survey fatigue, enabling much faster intervention cycles.
**Recommended Visualization:** Scatter plot with trend line, R² displayed.
**Decision-Making Impact:** Justifies building automated attendance-decline alerts as an engagement early-warning system, supplementing (not replacing) periodic surveys.

---

# 6. COMPENSATION KPIs

### 6.1 Average Compa-Ratio
**Definition:** Mean ratio of actual salary to the midpoint of the employee's salary band.
**Formula:** `AVG(Salary / BandMidpoint)`
**Business Meaning:** 1.0 = paid exactly at market midpoint. The aggregate compa-ratio reveals whether the organization, in total, is positioned to lead, meet, or lag the market.
**Executive Interpretation:** A compa-ratio consistently below 0.95 across the org signals a systemic "lag the market" compensation philosophy — which is a defensible strategy *only* if paired with superior non-cash value propositions (equity, flexibility, mission). Without those, it's a slow-motion attrition driver.
**Recommended Visualization:** KPI card with distribution histogram beneath (showing spread, not just average).
**Decision-Making Impact:** Sets the annual merit budget request — if average compa-ratio is drifting down due to market salary inflation outpacing merit increases, this is the data that justifies a larger-than-typical merit pool.

---

### 6.2 Pay Equity Gap (Gender)
**Definition:** Percentage difference in average compensation between genders, controlling for level.
**Formula:** `(AvgSalary_Male − AvgSalary_Female) / AvgSalary_Male × 100, by JobLevel`
**Business Meaning:** A legal compliance metric (Equal Pay Act, pay transparency legislation) as much as a culture metric. PeoplePulse shows an approximate 2.3% gap at L3-L5.
**Executive Interpretation:** Gaps under 2% are generally considered within statistical noise; gaps 2-5% warrant proactive remediation before becoming legal exposure; gaps >5% represent material legal and reputational risk requiring immediate board notification in most jurisdictions with pay transparency laws.
**Recommended Visualization:** Heatmap — gap percentage by Job Level × Department, color-coded by severity.
**Decision-Making Impact:** Gaps >2% should trigger budgeted "equity adjustment" pools — distinct from merit budgets — specifically earmarked to close identified gaps within 1-2 review cycles, often before public pay-gap reporting deadlines.

---

### 6.3 Salary Range Penetration
**Definition:** Average position of employees within their salary band, expressed as a percentile.
**Formula:** `AVG(PERCENT_RANK() OVER (PARTITION BY JobLevel ORDER BY Salary))`
**Business Meaning:** Shows whether tenure within a level is being rewarded — are long-tenured employees clustering near the band maximum, or are they stuck near the minimum despite years of service?
**Executive Interpretation:** If average tenure-in-level is 4 years but average band penetration is only 35%, the organization has a "salary compression" problem — employees aren't progressing within their band despite sustained tenure, which is functionally a real pay cut (inflation-adjusted) and a hidden attrition driver.
**Recommended Visualization:** Scatter plot — Years in Level (X) vs. Band Penetration (Y) — should show positive correlation; flat or negative trend is the red flag.
**Decision-Making Impact:** Compression findings justify "market adjustment" budget separate from both merit and equity pools — this is about competitiveness erosion, not individual performance or fairness.

---

### 6.4 Total Compensation Cost Ratio
**Definition:** Total compensation spend (salary + bonus) as a percentage of company revenue.
**Formula:** `SUM(Salary + Bonus) / Total Revenue × 100`
**Business Meaning:** The single largest line item in most companies' cost structure — this ratio is the bridge between HR and the CFO's income statement.
**Executive Interpretation:** Tracking this ratio over time, alongside revenue per employee, tells the CFO whether headcount investments are translating to revenue growth (ratio stable or declining as revenue scales) or represent margin erosion (ratio increasing).
**Recommended Visualization:** Dual-axis line chart — compensation cost ratio and revenue-per-employee, trended.
**Decision-Making Impact:** This is the metric used in annual budget negotiations between CHRO and CFO — it's the language that gets HR a seat at the strategic planning table.

---

### 6.5 Bonus-to-Base Ratio by Performance Tier
**Definition:** Average bonus as a percentage of base salary, segmented by performance rating.
**Formula:** `AVG(Bonus / Salary) × 100, GROUP BY PerformanceRating`
**Business Meaning:** Validates whether "pay for performance" is actually happening at the bonus level, or whether bonus distribution has become a de facto entitlement disconnected from differentiation.
**Executive Interpretation:** If the bonus-to-base ratio for "Distinguished" performers is only marginally higher than for "Meets Expectations" performers (e.g., 18% vs. 15%), the bonus program is not meaningfully differentiating — high performers correctly perceive this as inequitable and it becomes a regrettable-attrition driver.
**Recommended Visualization:** Grouped bar chart, bonus % by performance tier, with a "differentiation gap" annotation.
**Decision-Making Impact:** Insufficient differentiation (gap <5 percentage points between top and middle tiers) should trigger a bonus pool redesign for the next cycle — often a zero-sum reallocation, not a budget increase.

---

# 7. RECRUITMENT KPIs

### 7.1 Time to Fill
**Definition:** Average calendar days from requisition open to candidate accepted offer / start date.
**Formula:** `AVG(HireDate − RequisitionOpenDate)`
**Business Meaning:** The primary efficiency metric for the TA function — directly impacts business capacity and hiring manager satisfaction.
**Executive Interpretation:** Benchmark: 30-45 days for IC roles, 45-60 for management, 60-90+ for executive. Sustained overages signal either insufficient recruiter capacity, an overly complex interview process, or a market where the company's offer competitiveness is causing late-stage candidate drop-off.
**Recommended Visualization:** Box plot by role level, showing median and spread vs. benchmark line.
**Decision-Making Impact:** Time-to-fill consistently exceeding benchmark by >20% justifies additional recruiter headcount requests — each day of vacancy has a quantifiable "cost of vacancy" (lost productivity, overtime for covering team members).

---

### 7.2 Offer Acceptance Rate
**Definition:** Percentage of extended offers that are accepted.
**Formula:** `COUNT(OfferAccepted='Yes') / COUNT(OffersExtended) × 100`
**Business Meaning:** A direct measure of employer brand competitiveness and offer-package alignment with candidate expectations at the point of decision.
**Executive Interpretation:** Acceptance rates below 80% (healthy benchmark: 85-90%) — especially when concentrated among high-priority candidates — often indicate compensation packages are not competitive at the offer stage, even if the overall comp philosophy seems sound (the gap may be specifically at entry-level bands where market movement is fastest).
**Recommended Visualization:** Funnel chart with acceptance rate as the final conversion stage, segmented by role level.
**Decision-Making Impact:** Declining acceptance rates trigger an urgent off-cycle market data refresh for affected role families — waiting for the annual comp survey cycle means continuing to lose candidates in real time.

---

### 7.3 Source Quality Index (Quality of Hire by Channel)
**Definition:** Composite score combining 12-month retention, performance rating, and engagement for hires by recruitment source.
**Formula:** `(AvgPerfRating/5 × 0.35) + (RetentionRate × 0.35) + (AvgEngagement/100 × 0.30) × 100`
**Business Meaning:** Moves recruiting evaluation beyond volume/cost metrics to actual long-term hire quality — the question that matters: "Did this channel produce people who stayed and performed?"
**Executive Interpretation:** In the PeoplePulse data, sourcing channels show meaningful quality variance — channels with lower per-hire cost sometimes produce lower long-term quality, meaning the *true* cost-per-quality-hire may favor a more expensive channel. Cost-per-hire alone is a misleading optimization target.
**Recommended Visualization:** Quadrant chart — Cost per Hire (X) vs. Quality of Hire Score (Y) — four quadrants: "Efficient & Effective" (bottom-left... top-left ideally), "Expensive but Effective," "Cheap but Risky," "Avoid."
**Decision-Making Impact:** Directly reallocates the sourcing budget mix for the following fiscal year — channels in the "Avoid" quadrant get budget cuts regardless of their low per-unit cost.

---

### 7.4 Internal vs. External Fill Ratio
**Definition:** Ratio of positions filled internally vs. externally.
**Formula:** `COUNT(InternalHire) : COUNT(ExternalHire)`
**Business Meaning:** A culture and cost signal — internal fills are typically 3-5x cheaper than external and carry lower 90-day-attrition risk, but over-reliance can signal insufficient external perspective infusion.
**Executive Interpretation:** Healthy enterprises target roughly 30-40% internal fill rate. PeoplePulse's low internal rate (5.3%) suggests significant unrealized cost savings AND retention benefit being left on the table.
**Recommended Visualization:** Trended stacked bar, internal vs. external fills by quarter.
**Decision-Making Impact:** Drives investment decisions in internal talent marketplace technology and mandatory "internal posting period" policies (e.g., 5 business days internal-only before external posting).

---

### 7.5 Candidate Experience Score
**Definition:** Average candidate-reported experience rating (NPS-style) across the recruitment funnel.
**Formula:** `AVG(CandidateNPS)`
**Business Meaning:** Candidates — including rejected ones — are also customers, future customers, and potential future employees/referrers. Poor candidate experience has brand reputation consequences that extend beyond the immediate hiring decision.
**Executive Interpretation:** Glassdoor and similar platforms mean candidate experience scores have a direct, measurable relationship to future offer-acceptance rates and even consumer brand sentiment for B2C companies.
**Recommended Visualization:** NPS-style gauge, trended monthly, with qualitative comment word-cloud overlay.
**Decision-Making Impact:** Persistent low scores trigger interview process redesign — often the highest-leverage, lowest-cost fix in the entire TA function (e.g., faster feedback turnaround, structured interview training for hiring managers).

---

# 8. PERFORMANCE KPIs

### 8.1 Performance Distribution (Forced Curve Adherence)
**Definition:** Percentage of workforce in each performance rating category, compared to target distribution.
**Formula:** `COUNT(Rating=X) / Total × 100, for X in {1,2,3,4,5}`
**Business Meaning:** Validates whether the performance management process is producing meaningful differentiation or has drifted toward rating inflation.
**Executive Interpretation:** PeoplePulse target distribution (5% / 26% / 53% / 12% / 3%) closely tracks a healthy enterprise curve. Significant drift — e.g., 45% rated "Exceeds" — indicates either genuine performance improvement (verify against business outcomes) or, more commonly, manager rating inflation due to avoidance of difficult conversations.
**Recommended Visualization:** Stacked bar chart, actual vs. target distribution, by department (reveals which managers/departments are inflating).
**Decision-Making Impact:** Significant drift triggers calibration session mandates — cross-manager review sessions where ratings are normalized before finalization, a standard Big 4 / Fortune 500 practice.

---

### 8.2 High-Performer Concentration
**Definition:** Percentage of workforce rated 4 or 5 ("Exceeds" or "Distinguished").
**Formula:** `COUNT(PerformanceRating>=4) / Total × 100`
**Business Meaning:** The talent density of the organization — directly correlates with overall organizational capability and competitive advantage.
**Executive Interpretation:** PeoplePulse: 31.5% high performers. This should be read alongside high-performer retention (Section 3.2) — high concentration with low retention of that population is the worst combination (good talent, leaking).
**Recommended Visualization:** KPI card paired directly with high-performer retention rate KPI card for joint interpretation.
**Decision-Making Impact:** A declining high-performer concentration over multiple cycles — even with stable overall headcount — signals a talent quality erosion that should trigger a hiring bar review with TA.

---

### 8.3 Performance-Compensation Alignment
**Definition:** Correlation between performance rating and total compensation, controlling for level and tenure.
**Formula:** `CORR(PerformanceRating, Salary), controlling for JobLevel`
**Business Meaning:** Tests whether "pay for performance" philosophy translates into actual pay outcomes — a frequent gap between stated and lived compensation philosophy.
**Executive Interpretation:** A weak or near-zero correlation (after controlling for level/tenure) means performance ratings are essentially disconnected from pay outcomes — high performers can observe this, and it is one of the most cited reasons for regrettable attrition in exit interviews industry-wide.
**Recommended Visualization:** Scatter plot, performance rating (X) vs. compa-ratio (Y), with regression line and R².
**Decision-Making Impact:** A weak correlation justifies redesigning the merit increase formula to weight performance rating more heavily relative to tenure/seniority factors.

---

### 8.4 PIP (Performance Improvement Plan) Conversion Rate
**Definition:** Percentage of employees placed on a PIP who subsequently improve to "Meets Expectations" or above vs. those who exit.
**Formula:** `COUNT(PIP→Improved) / COUNT(PIP_Total) × 100`
**Business Meaning:** Measures whether the PIP process functions as a genuine improvement mechanism or as a "soft exit" pathway (both are legitimate organizational choices, but the organization should know which one it's actually running).
**Executive Interpretation:** PeoplePulse data shows performance rating 1 ("Unacceptable") carries the highest attrition-risk lift (+12 percentage points) of any factor in the ML model — consistent with a managed-exit pattern. If this is intentional policy, fine; if leadership believes PIPs are development tools, there's a perception-reality gap requiring HR Director attention.
**Recommended Visualization:** Sankey diagram — PIP entry → Improved / Exited (Voluntary) / Exited (Involuntary).
**Decision-Making Impact:** Clarifies messaging to managers about what the PIP process is actually for — affects how managers use (or avoid using) the tool.

---

# 9. TRAINING KPIs

### 9.1 Average Training Hours per Employee
**Definition:** Mean annual training hours completed per employee.
**Formula:** `AVG(TrainingHours)`
**Business Meaning:** A direct measure of learning investment — benchmarked against ATD (Association for Talent Development) industry average of ~34 hours/employee/year for high-performing organizations.
**Executive Interpretation:** Training hours alone don't indicate value — they must be paired with outcome metrics (9.3, 9.4). However, hours significantly below benchmark (e.g., <20) often indicate L&D is viewed as discretionary/first-to-cut, which has compounding effects on skills currency over multi-year horizons.
**Recommended Visualization:** KPI card with department breakdown, vs. ATD benchmark line.
**Decision-Making Impact:** Sets the annual L&D budget envelope — hours-per-employee × blended cost-per-hour ($50 PeoplePulse estimate) = total L&D investment required.

---

### 9.2 Training Investment-to-Retention Correlation
**Definition:** Comparison of average training hours between retained and attrited employee populations.
**Formula:** `AVG(TrainingHours WHERE Attrition='No') − AVG(TrainingHours WHERE Attrition='Yes')`
**Business Meaning:** Tests the hypothesis that "investing in people makes them more likely to stay" — counterintuitively, this isn't always true (sometimes training increases external marketability and *raises* flight risk in the short term).
**Executive Interpretation:** If retained employees show meaningfully *higher* training hours than attrited employees, training functions as a retention investment with measurable ROI — strengthening the business case for L&D budget protection during cost-cutting cycles.
**Recommended Visualization:** Side-by-side box plots, training hours distribution for retained vs. attrited.
**Decision-Making Impact:** A positive correlation (more training = more retention) is a powerful data point for protecting L&D budgets; a negative correlation (common for highly transferable technical skills training) suggests training investment should be paired with retention agreements (e.g., reimbursement clawback clauses) for high-cost programs.

---

### 9.3 Mandatory Training Compliance Rate
**Definition:** Percentage of required compliance training completed on time.
**Formula:** `COUNT(IsMandatory=1 AND Completed=1 AND NOT Overdue) / COUNT(IsMandatory=1) × 100`
**Business Meaning:** A legal/regulatory risk metric — incomplete compliance training (anti-harassment, safety, data privacy, code of conduct) creates direct legal liability.
**Executive Interpretation:** Compliance completion below 95% should be treated as a legal risk item, not merely an HR metric — General Counsel should be a stakeholder in this KPI.
**Recommended Visualization:** KPI card with red/amber/green threshold at 95%, drill-through to overdue employee list by manager.
**Decision-Making Impact:** Below-threshold departments trigger manager accountability escalation — compliance completion should be a component of manager performance reviews in regulated industries.

---

### 9.4 Skills Gap Coverage Ratio
**Definition:** Percentage of identified critical skill requirements (per role) that current workforce skills inventory satisfies.
**Formula:** `COUNT(RequiredSkills MATCHED) / COUNT(RequiredSkills TOTAL) × 100, by JobFamily`
**Business Meaning:** Forward-looking workforce planning metric — identifies where the organization's current capability doesn't match its strategic skill needs (e.g., AI/ML skills demand outpacing current bench).
**Executive Interpretation:** A coverage ratio below 70% in a strategically critical skill domain (e.g., "Cloud Infrastructure" or "Data Science") represents a build-vs-buy decision point — invest in reskilling current staff (slower, retention-positive) vs. external hiring (faster, retention-neutral/negative if perceived as bypassing internal talent).
**Recommended Visualization:** Radar/spider chart — skill domains on axes, current coverage vs. target coverage as two overlaid shapes.
**Decision-Making Impact:** Directly informs the make-vs-buy talent strategy embedded in the annual workforce plan submitted to the board.

---

# 10. DIVERSITY KPIs

### 10.1 Gender Representation by Level
**Definition:** Percentage breakdown of gender across each job level.
**Formula:** `COUNT(Gender=X) / COUNT(*) × 100, GROUP BY JobLevel, Gender`
**Business Meaning:** The foundational DEI metric for understanding the "leaky pipeline" — representation typically declines at each successive level in most enterprises.
**Executive Interpretation:** PeoplePulse shows female representation declining from near-parity at junior levels to a minority at L6+ — a classic pipeline leakage pattern. This isn't necessarily evidence of bias at any single point, but the *cumulative* effect across levels compounds into significant senior-leadership gaps.
**Recommended Visualization:** "Pipeline" funnel chart — representation percentage at each level from L1 to L8.
**Decision-Making Impact:** Informs sponsorship program design — pipeline leakage concentrated at a specific level transition (e.g., L4→L5, the IC-to-management transition) should target that specific transition with focused sponsorship and promotion-readiness programs.

---

### 10.2 Pay Equity Index (Composite)
**Definition:** Aggregate measure combining pay gaps across gender, ethnicity, and age cohorts into a single composite equity score.
**Formula:** `100 − AVG(|PayGapPct| across all demographic dimensions and levels)`
**Business Meaning:** A board-reportable single metric summarizing overall pay equity health — useful for trend-tracking even as individual sub-metrics fluctuate.
**Executive Interpretation:** A score of 100 = perfect equity (theoretical). Scores above 97 are generally considered "within statistical noise" by most pay equity statisticians; below 95 warrants proactive remediation budget; below 90 represents material legal exposure under most pay transparency regimes (EU Pay Transparency Directive, various US state laws).
**Recommended Visualization:** Composite gauge/score card with sub-component breakdown available on click-through.
**Decision-Making Impact:** This is the number that goes into the annual ESG/sustainability report — increasingly a disclosure requirement, and increasingly scrutinized by institutional investors.

---

### 10.3 Diversity Hiring Rate vs. Workforce Composition
**Definition:** Comparison of the demographic composition of new hires vs. the existing workforce composition.
**Formula:** `%Demographic_NewHires − %Demographic_ExistingWorkforce`
**Business Meaning:** Tests whether current hiring practices are improving, maintaining, or eroding representation over time — a leading indicator for future representation KPIs (10.1).
**Executive Interpretation:** If new-hire diversity consistently exceeds existing workforce diversity, representation will improve over time purely through natural attrition/replacement — a "passive improvement" trajectory. If new-hire diversity matches or lags existing composition, representation gaps will persist or widen even with good intentions elsewhere.
**Recommended Visualization:** Trended dual-line chart — new hire composition vs. existing workforce composition, by dimension.
**Decision-Making Impact:** A lagging new-hire diversity rate (vs. existing workforce) should trigger a sourcing-channel-mix review — different channels (Section 7.3) often have materially different applicant pool diversity profiles.

---

### 10.4 Diversity-Attrition Differential
**Definition:** Comparison of attrition rates between demographic groups, controlling for level and department.
**Formula:** `AttritionRate_GroupA − AttritionRate_GroupB, controlling for JobLevel and Department`
**Business Meaning:** Tests whether the organization retains all demographic groups equally — differential attrition is often a more sensitive (and earlier) signal of inclusion problems than representation or pay metrics, because it reflects lived day-to-day experience.
**Executive Interpretation:** A statistically significant attrition differential (e.g., one demographic group exits at materially higher rates within the same level/department, controlling for performance) often precedes representation decline and frequently correlates with engagement-survey sub-scores around "belonging" and "fair treatment."
**Recommended Visualization:** Matrix/heatmap — attrition rate by demographic group × department, with statistical significance flagging.
**Decision-Making Impact:** Statistically significant differentials should trigger qualitative research (focus groups, listening sessions) within the affected department — quantitative data identifies *where*, qualitative data is needed to understand *why* before designing interventions.

---

## FRAMEWORK GOVERNANCE

**Reporting Cadence:**
- Real-time (dashboard, always-on): Headcount, Flight Risk Distribution, Attendance
- Weekly (HRBP review): Promotion Gap alerts, High-Risk employee list, Chronic Absenteeism
- Monthly (HR Director review): All Engagement, Attrition, Compensation KPIs
- Quarterly (CHRO/Executive Committee): Full framework review, trend analysis, benchmark comparison
- Annually (Board/ESG): Pay Equity Index, Diversity composite metrics, Total Compensation Cost Ratio

**Ownership Model:**
| KPI Domain | Primary Owner | Escalation Path |
|---|---|---|
| Workforce | HR Operations | HR Director → CFO (headcount budget) |
| Attrition / Retention | HRBPs | HR Director → CHRO (regrettable attrition >5%) |
| Engagement | HR Director | CHRO → CEO (eNPS <0) |
| Attendance | HRBPs | HR Director |
| Compensation | Total Rewards | CHRO → CFO/Board (equity gaps >5%) |
| Recruitment | TA Director | HR Director |
| Performance | HR Director | CHRO (calibration drift) |
| Training | L&D Director | CHRO (compliance <95% → Legal) |
| Diversity | DEI Lead | CHRO → Board (annual ESG reporting) |

---

*Document: PeoplePulse AI KPI Framework v1.0*
*Prepared in the style of: Deloitte Human Capital / PwC Workforce Analytics / EY People Advisory Services*
*Classification: Confidential — Executive Distribution*
