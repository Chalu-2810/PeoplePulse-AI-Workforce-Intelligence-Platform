# PeoplePulse AI — Advanced DAX Measures Library
## Phase 7 | Power BI MVP Standard | 50+ Production-Grade Measures
### Distinct from Phase 4 library — focuses on the 10 named composite measures + advanced variants

---

## TABLE OF CONTENTS
1. Attrition Rate — Advanced Variants (5)
2. Retention Rate — Advanced Variants (5)
3. Promotion Rate — Advanced Variants (4)
4. Salary Growth — Advanced Variants (5)
5. Headcount Growth — Advanced Variants (5)
6. Training Effectiveness — Advanced Variants (5)
7. Employee Risk Score — Advanced Variants (6)
8. Department Ranking — Advanced Variants (5)
9. Workforce Health Score — Composite (5)
10. Manager Effectiveness Score — Advanced Variants (5)
11. Time Intelligence & Utility Measures (5)

---

# 1. ATTRITION RATE — ADVANCED VARIANTS

### 1.1 Attrition Rate (Base Definition)
```dax
Attrition Rate =
DIVIDE(
    CALCULATE( COUNTROWS( HR_Data ), HR_Data[Attrition] = "Yes" ),
    COUNTROWS( HR_Data ),
    0
)
```
**Explanation:** Counts attrited rows divided by total rows in current filter context. `DIVIDE` with a third argument of 0 prevents divide-by-zero errors when a filter returns an empty department.

**Business Use Case:** The foundational KPI for Pages 1, 3, 11, 15. Every other attrition measure builds on this pattern.

**Performance Optimization Notes:** `COUNTROWS` is the fastest row-counting function in DAX — faster than `COUNT(column)` because it doesn't need to check for nulls. Avoid `CALCULATE(COUNT(...))` patterns when `COUNTROWS` suffices.

---

### 1.2 Attrition Rate — Rolling 12-Month
```dax
Attrition Rate Rolling 12M =
CALCULATE(
    [Attrition Rate],
    DATESINPERIOD(
        DimDate[Date],
        MAX( DimDate[Date] ),
        -12,
        MONTH
    )
)
```
**Explanation:** `DATESINPERIOD` creates a rolling window ending at the last visible date and extending 12 months back — smooths month-to-month volatility for trend lines.

**Business Use Case:** Page 3 survival-curve trend lines and Page 15 sparklines — boards prefer rolling annualized rates over single-month spikes which can be noisy with small department populations.

**Performance Optimization Notes:** Requires a proper marked Date Table. `DATESINPERIOD` is preferable to `DATEADD` + `DATESBETWEEN` combinations because it's a single function call optimized by the VertiPaq engine's date-range materialization.

---

### 1.3 Attrition Rate — Excluding Retirements
```dax
Attrition Rate Excl Retirement =
VAR TotalAttrited =
    CALCULATE( COUNTROWS( HR_Data ), HR_Data[Attrition] = "Yes" )
VAR RetirementCount =
    CALCULATE(
        COUNTROWS( HR_Data ),
        HR_Data[Attrition] = "Yes",
        HR_Data[Exit_Reason] = "Retirement"
    )
RETURN
    DIVIDE( TotalAttrited - RetirementCount, COUNTROWS( HR_Data ), 0 )
```
**Explanation:** Subtracts planned/expected retirement exits from the numerator — retirements are not "controllable" attrition and including them inflates the apparent severity of a retention problem.

**Business Use Case:** Used whenever a CHRO wants the "actionable" attrition number — particularly relevant for departments with an aging workforce (Finance, Legal in this dataset) where retirement-driven exits would otherwise distort department comparisons.

**Performance Optimization Notes:** Two `CALCULATE` calls over the same table — both benefit from filter context caching within the same visual's query plan. For very large fact tables (>10M rows), consider pre-flagging `IsRetirement` as a calculated column to avoid repeated string comparison.

---

### 1.4 Attrition Rate Variance vs Target
```dax
Attrition Rate vs Target =
VAR TargetRate = 0.18   -- could be a what-if parameter
RETURN
    [Attrition Rate] - TargetRate

Attrition Rate Variance Format =
VAR Variance = [Attrition Rate vs Target]
RETURN
    IF(
        Variance > 0,
        "▲ " & FORMAT( Variance, "0.0%" ) & " above target",
        "▼ " & FORMAT( ABS(Variance), "0.0%" ) & " below target"
    )
```
**Explanation:** Computes signed deviation from a hardcoded (or What-If parameter driven) target, then a second measure formats it with directional language for KPI card subtitles.

**Business Use Case:** Page 1 KPI card subtitle and Page 15 RAG status — translates a raw percentage into an instantly-readable directional statement for executives.

**Performance Optimization Notes:** Hardcoded targets evaluate instantly. If using a What-If parameter table instead (`TargetRate = SELECTEDVALUE('Target Parameter'[Value], 0.18)`), ensure the parameter table has a single-column relationship with no bidirectional cross-filtering to avoid ambiguous filter paths.

---

### 1.5 Attrition Rate — Statistically Significant Department Flag
```dax
Attrition Significance Flag =
VAR DeptRate    = [Attrition Rate]
VAR CompanyRate = CALCULATE( [Attrition Rate], ALL( HR_Data ) )
VAR DeptN       = COUNTROWS( HR_Data )
VAR StdErr      = SQRT( CompanyRate * (1 - CompanyRate) / DeptN )
VAR ZScore      = DIVIDE( DeptRate - CompanyRate, StdErr, 0 )
RETURN
    SWITCH(
        TRUE(),
        ZScore >  1.96, "🔴 Significantly Higher",
        ZScore < -1.96, "🟢 Significantly Lower",
        "⚪ Not Significant (within noise)"
    )
```
**Explanation:** Implements a simplified z-test for proportions — compares a department's attrition rate to the company rate, normalized by the standard error implied by the department's sample size. A z-score beyond ±1.96 corresponds to the 95% confidence threshold.

**Business Use Case:** Prevents over-reacting to a small department (e.g., Legal, n=288) showing a 28% rate when that might be just 2-3 people and statistically indistinguishable from noise — vs. Sales (n=1,750) showing 27.8%, which IS significant given its size.

**Performance Optimization Notes:** `SQRT` and statistical functions are scalar operations — cheap. The expensive part is the `ALL(HR_Data)` context transition to get company rate, which forces a full table scan ignoring filters. Cache this as a separate measure (`Company Attrition Rate`) if used across many visuals to benefit from query plan reuse.

---

# 2. RETENTION RATE — ADVANCED VARIANTS

### 2.1 Retention Rate (Base)
```dax
Retention Rate =
1 - [Attrition Rate]
```
**Explanation:** Simple complement. Defining it as a separate measure (rather than inlining `1 - [Attrition Rate]` everywhere) ensures a single point of formatting/definition control.

**Business Use Case:** Positive-framing KPI card for Page 1 — "76.2% Retention" reads better in an all-hands presentation than "23.8% Attrition," same number.

**Performance Optimization Notes:** Negligible cost — DAX measure reuse means `[Attrition Rate]` is evaluated once and reused, not recalculated.

---

### 2.2 High-Performer Retention Rate
```dax
High Performer Retention Rate =
VAR HiPoTotal =
    CALCULATE( COUNTROWS( HR_Data ), HR_Data[Performance_Rating] >= 4 )
VAR HiPoRetained =
    CALCULATE(
        COUNTROWS( HR_Data ),
        HR_Data[Performance_Rating] >= 4,
        HR_Data[Attrition] = "No"
    )
RETURN
    DIVIDE( HiPoRetained, HiPoTotal, 0 )
```
**Explanation:** Filters to the high-performer population first, then computes the retention rate within that subgroup specifically.

**Business Use Case:** Page 7 "Retention Comparison" visual — paired against overall Retention Rate to detect "inverted retention" (keeping the wrong people).

**Performance Optimization Notes:** Two separate `CALCULATE` calls with overlapping filters — DAX's formula engine will recognize the shared `Performance_Rating >= 4` filter and can reuse the filtered table cache in some query plans. For high-cardinality models, consider a calculated column `IsHighPerformer` (boolean) to enable storage-engine-level filtering instead of formula-engine comparisons.

---

### 2.3 Retention Rate by Tenure Cohort (Survival Function)
```dax
Retention Rate Survival =
VAR CurrentTenureBand = SELECTEDVALUE( HR_Data[Tenure_Band] )
VAR CohortTotal =
    CALCULATE(
        COUNTROWS( HR_Data ),
        REMOVEFILTERS( HR_Data[Attrition] )
    )
RETURN
    DIVIDE(
        CALCULATE( COUNTROWS(HR_Data), HR_Data[Attrition]="No" ),
        CohortTotal,
        0
    )
```
**Explanation:** `REMOVEFILTERS` on the Attrition column ensures the denominator counts the FULL cohort (both retained and attrited) within the selected tenure band, regardless of any Attrition slicer that might otherwise be applied — critical for survival-curve accuracy.

**Business Use Case:** Page 3 survival curve — each point on the curve represents "of everyone who ever reached this tenure, what % are still here."

**Performance Optimization Notes:** `REMOVEFILTERS` (the modern alias for `ALL` on specific columns) is more readable and equally performant. Scoping it to only the `Attrition` column (not the whole table) preserves department/location filters from slicers — an important precision detail.

---

### 2.4 Critical Talent Retention Rate
```dax
Critical Talent Retention Rate =
VAR CriticalPop =
    CALCULATE(
        COUNTROWS( HR_Data ),
        HR_Data[Job_Level] IN { "L6", "L7", "L8" }
            || HR_Data[Performance_Rating] = 5
    )
VAR CriticalRetained =
    CALCULATE(
        COUNTROWS( HR_Data ),
        ( HR_Data[Job_Level] IN { "L6", "L7", "L8" }
            || HR_Data[Performance_Rating] = 5 ),
        HR_Data[Attrition] = "No"
    )
RETURN
    DIVIDE( CriticalRetained, CriticalPop, 0 )
```
**Explanation:** Defines "critical talent" as either senior leadership (L6+) OR top-rated performers (rating=5), using boolean `OR` (`||`) logic inside `CALCULATE` filter arguments.

**Business Use Case:** Section 3.5 KPI from Phase 5 — surfaces retention specifically for succession-critical and irreplaceable individuals, a board-level concern distinct from overall retention.

**Performance Optimization Notes:** The `||` operator inside CALCULATE filter arguments generates a more complex filter predicate than separate `CALCULATE` filter parameters (which are implicitly ANDed). For very large models, an alternative is a calculated column `IsCriticalTalent` evaluated once at refresh time, then filtered with simple equality — trades refresh time for query time.

---

### 2.5 Retention Rate Heatmap Value (Department × Level Matrix)
```dax
Retention Rate Matrix =
IF(
    ISCROSSFILTERED( HR_Data[Department] ) && ISCROSSFILTERED( HR_Data[Job_Level] ),
    [Retention Rate],
    BLANK()
)
```
**Explanation:** Returns `BLANK()` unless BOTH Department and Job_Level are in the current filter context (i.e., this is a matrix cell, not a row/column total) — prevents misleadingly showing an aggregate "total" retention rate in cells meant to represent specific intersections only.

**Business Use Case:** Page 8 attrition-differential heatmap and similar matrix visuals — ensures totals row/column are visually blank rather than showing a confusing aggregate that doesn't represent any single cell's population.

**Performance Optimization Notes:** `ISCROSSFILTERED` is a lightweight context-inspection function — near-zero cost. This pattern is preferable to `HASONEVALUE` checks when multiple columns need joint verification.

---

# 3. PROMOTION RATE — ADVANCED VARIANTS

### 3.1 Promotion Rate (Base)
```dax
Promotion Rate =
DIVIDE(
    CALCULATE( COUNTROWS( HR_Data ), HR_Data[Promotions] >= 1 ),
    COUNTROWS( HR_Data ),
    0
)
```
**Explanation:** Percentage of the current population that has received at least one promotion during their tenure (cumulative, not annual).

**Business Use Case:** Page 2 and Page 7 — baseline promotion activity metric.

**Performance Optimization Notes:** Standard pattern — `CALCULATE` + `COUNTROWS` with single filter is storage-engine resolvable (pushed down to VertiPaq scan), the fastest possible DAX pattern.

---

### 3.2 Annualized Promotion Rate
```dax
Annualized Promotion Rate =
AVERAGEX(
    HR_Data,
    DIVIDE( HR_Data[Promotions], HR_Data[Years_At_Company], 0 )
)
```
**Explanation:** Computes a per-employee "promotions per year of tenure" ratio, then averages across the population — normalizes for the fact that longer-tenured employees have had more opportunities to be promoted.

**Business Use Case:** Fairer cross-department comparison than raw Promotion Rate when departments have very different average tenures (e.g., comparing a young Sales org to a tenured Finance org).

**Performance Optimization Notes:** `AVERAGEX` iterates row-by-row (formula engine) — for 10,000 rows this is trivial (<50ms), but for multi-million row fact tables, consider pre-computing `PromotionsPerYear` as a calculated column so `AVERAGEX` becomes a simple `AVERAGE` over a materialized column (storage engine).

---

### 3.3 Promotion Gap Severity Index
```dax
Promotion Gap Severity =
AVERAGEX(
    HR_Data,
    VAR ExpectedPromos = HR_Data[Years_At_Company] / 2.8
    VAR Gap            = ExpectedPromos - HR_Data[Promotions]
    VAR PerfWeight     = SWITCH( HR_Data[Performance_Rating], 5, 2, 4, 1.5, 3, 1, 2, 0.5, 1, 0.25 )
    RETURN MAX( Gap, 0 ) * PerfWeight
)
```
**Explanation:** Computes the raw promotion gap (expected vs. actual), then weights it by performance — a 2-year gap for a "Distinguished" performer is twice as severe as the same gap for a "Meets Expectations" performer, reflected via the `PerfWeight` multiplier.

**Business Use Case:** A single composite number for Page 1's "talent stagnation risk" — feeds into the Workforce Health Score (Section 9).

**Performance Optimization Notes:** `SWITCH` on an integer column is efficiently compiled to a lookup; nesting it inside `AVERAGEX` means it's evaluated once per row — for larger models, materialize `PerformanceWeight` as a calculated column joined from a small Performance Rating dimension table to move this logic to model-design time.

---

### 3.4 Promotion Rate — Internal Mobility Adjusted
```dax
Effective Career Mobility Rate =
VAR PromotedCount =
    CALCULATE( COUNTROWS( HR_Data ), HR_Data[Promotions] >= 1 )
VAR InternalTransferCount =
    CALCULATE(
        COUNTROWS( HR_Data ),
        HR_Data[Recruitment_Source] = "Internal Transfer"
    )
VAR TotalPop = COUNTROWS( HR_Data )
RETURN
    DIVIDE( PromotedCount + InternalTransferCount, TotalPop, 0 )
```
**Explanation:** Combines vertical mobility (promotions) with lateral mobility (internal transfers) into a single "career mobility" metric — both represent the organization investing in an employee's growth without external hiring.

**Business Use Case:** Page 2 and Page 6 — a more complete picture of "does this company grow its own talent" than promotion rate alone, which misses lateral moves that are equally valuable for retention.

**Performance Optimization Notes:** Two independent `CALCULATE` calls on different columns of the same table — DAX can evaluate these in parallel within the storage engine's columnar scan since they don't share filter dependencies. No optimization concern at this scale.

---

# 4. SALARY GROWTH — ADVANCED VARIANTS

### 4.1 Average Salary Growth Rate (Tenure-Implied)
```dax
Implied Annual Salary Growth Rate =
VAR AvgSalaryNewHires =
    CALCULATE(
        AVERAGE( HR_Data[Salary] ),
        HR_Data[Years_At_Company] < 1
    )
VAR AvgSalaryTenured =
    CALCULATE(
        AVERAGE( HR_Data[Salary] ),
        HR_Data[Years_At_Company] >= 5,
        HR_Data[Years_At_Company] <= 8
    )
VAR AvgTenureGap = 6.5   -- midpoint of 5-8yr band minus 0.5 (midpoint of <1yr)
RETURN
    DIVIDE(
        ( AvgSalaryTenured / AvgSalaryNewHires ) ^ ( 1/AvgTenureGap ) - 1,
        1,
        0
    )
```
**Explanation:** Without historical salary snapshots, this measure infers an *implied* compound annual growth rate by comparing the average salary of brand-new hires (proxy for "starting salary today") against the average salary of employees with 5-8 years tenure (proxy for "what starting salary X years ago grew into"), then solves for the CAGR using the standard compound growth formula `(End/Start)^(1/years) - 1`.

**Business Use Case:** Page 5 — gives Total Rewards a defensible estimate of real wage growth trajectory even in a single-snapshot dataset, useful for benchmarking against external CPI/market salary inflation rates.

**Performance Optimization Notes:** This is a "snapshot-inference" pattern — once true historical `FACT_COMPENSATION` event data is loaded (per Phase 2 schema), replace this with a true time-series CAGR using `DATESYTD`/`PARALLELPERIOD`. Flag this measure for retirement once historical comp data is available.

---

### 4.2 Salary Growth — YoY (when historical snapshots available)
```dax
Salary Growth YoY % =
VAR CurrentAvg = [Avg Salary]
VAR PriorAvg =
    CALCULATE(
        [Avg Salary],
        SAMEPERIODLASTYEAR( DimDate[Date] )
    )
RETURN
    DIVIDE( CurrentAvg - PriorAvg, PriorAvg, 0 )
```
**Explanation:** Standard time-intelligence YoY comparison — requires a marked Date table and a `FACT_COMPENSATION` or periodic snapshot fact table with a date key.

**Business Use Case:** Page 5 trend cards — the headline "compensation budget grew X% YoY" figure for CFO conversations.

**Performance Optimization Notes:** `SAMEPERIODLASTYEAR` requires a contiguous date range in the Date table (no gaps) to function correctly. Ensure the Date table spans at least 2 full years even if data only populates recently, otherwise this returns blank for early periods — a common source of "why is my YoY card empty" support tickets.

---

### 4.3 Salary Compression Index
```dax
Salary Compression Index =
VAR TenureGroupAvg =
    AVERAGEX(
        VALUES( HR_Data[Tenure_Band] ),
        CALCULATE( AVERAGE( HR_Data[Salary] ) )
    )
VAR OverallAvg = CALCULATE( AVERAGE(HR_Data[Salary]), ALL(HR_Data[Tenure_Band]) )
VAR Dispersion =
    SUMX(
        VALUES( HR_Data[Tenure_Band] ),
        VAR BandAvg = CALCULATE( AVERAGE(HR_Data[Salary]) )
        RETURN ( BandAvg - OverallAvg ) ^ 2
    )
RETURN
    DIVIDE( SQRT( Dispersion / COUNTROWS(VALUES(HR_Data[Tenure_Band])) ), OverallAvg, 0 )
```
**Explanation:** Computes the coefficient of variation (standard deviation / mean) of average salaries ACROSS tenure bands. A LOW value means salary doesn't vary much by tenure — i.e., long-tenured employees aren't earning meaningfully more than new hires, indicating compression.

**Business Use Case:** Section 6.3 of the KPI Framework — feeds the "salary compression" alert. A coefficient below ~0.08 (8% spread across tenure bands) suggests tenure isn't being rewarded.

**Performance Optimization Notes:** Nested iterators (`AVERAGEX`/`SUMX` over `VALUES()`) — with only 7 tenure bands this is 7×7=49 evaluations max, trivial. If extended to a higher-cardinality dimension (e.g., individual tenure months, 0-360), pre-aggregate tenure-band averages into a small summary table first.

---

### 4.4 Compa-Ratio Weighted Average (Headcount-Weighted)
```dax
Compa Ratio Weighted Avg =
VAR TotalSalary = SUM( HR_Data[Salary] )
VAR WeightedCompaSum =
    SUMX(
        HR_Data,
        HR_Data[Salary] *
            DIVIDE(
                HR_Data[Salary],
                CALCULATE(
                    MEDIAN( HR_Data[Salary] ),
                    ALLEXCEPT( HR_Data, HR_Data[Job_Level] )
                ),
                1
            )
    )
RETURN
    DIVIDE( WeightedCompaSum, TotalSalary, 0 )
```
**Explanation:** A simple `AVERAGE` of compa-ratios treats a $55K L1 employee's ratio the same as a $400K L8 executive's ratio. This measure weights each employee's compa-ratio by their salary, so high-cost roles have proportionally more influence on the aggregate — more financially meaningful for budget impact discussions.

**Business Use Case:** When the CFO asks "if we corrected all below-market compa-ratios, what's the budget impact" — a headcount-weighted average better approximates the dollar-weighted correction cost than a simple average.

**Performance Optimization Notes:** This is an O(n) iteration with a nested `CALCULATE` per row (computing level median) — for 10,000 rows, acceptable (~100-200ms). For larger models, pre-compute `Compa_Ratio` as a calculated column (as defined in Phase 4 Section 13) so this becomes `SUMX(HR_Data, Salary * Compa_Ratio) / SUM(Salary)` — removing the nested CALCULATE entirely.

---

### 4.5 Salary Growth Equity Check (by Gender)
```dax
Salary Growth Gap By Gender =
VAR MaleGrowth =
    CALCULATE(
        [Implied Annual Salary Growth Rate],
        HR_Data[Gender] = "Male"
    )
VAR FemaleGrowth =
    CALCULATE(
        [Implied Annual Salary Growth Rate],
        HR_Data[Gender] = "Female"
    )
RETURN
    MaleGrowth - FemaleGrowth
```
**Explanation:** Applies the implied-growth-rate measure (4.1) separately by gender — if male employees' implied salary growth trajectory outpaces female employees', this is an *additional* equity signal beyond the point-in-time pay gap (Section 6.2 KPI), because it suggests the gap WIDENS over a career rather than being a fixed offset.

**Business Use Case:** Page 5 / Page 8 — distinguishes "we have a hiring-time pay gap that stays constant" (less severe, fixable at offer stage) from "the gap compounds over tenure" (more severe, requires systemic merit-cycle intervention).

**Performance Optimization Notes:** Reuses measure 4.1 with additional filters — DAX measure composition like this is good practice (DRY principle) and has no meaningful performance penalty since the formula engine caches sub-expression results within a single query.

---

# 5. HEADCOUNT GROWTH — ADVANCED VARIANTS

### 5.1 Headcount Growth Rate (Period over Period)
```dax
Headcount Growth Rate =
VAR CurrentHC = [Total Employees]
VAR PriorHC =
    CALCULATE(
        [Total Employees],
        DATEADD( DimDate[Date], -1, MONTH )
    )
RETURN
    DIVIDE( CurrentHC - PriorHC, PriorHC, 0 )
```
**Explanation:** `DATEADD` shifts the entire filter context back one month, recomputing headcount as of that prior point — requires a snapshot-grain fact table (Phase 2 `FACT_EMPLOYEE_SNAPSHOT`).

**Business Use Case:** Page 1 and Page 2 headcount trend KPI cards.

**Performance Optimization Notes:** `DATEADD` is more flexible than `SAMEPERIODLASTYEAR`/`PREVIOUSMONTH` for arbitrary offsets but is marginally more expensive to evaluate due to its generality. For fixed month-over-month, `PREVIOUSMONTH(DimDate[Date])` is a lighter-weight, purpose-built alternative with identical results.

---

### 5.2 Net Headcount Change (Hires − Exits)
```dax
Net Headcount Change =
VAR Hires = CALCULATE( COUNTROWS(HR_Data), HR_Data[Years_At_Company] < (1/12) )  -- hired this month proxy
VAR Exits = CALCULATE( COUNTROWS(HR_Data), HR_Data[Attrition]="Yes" )
RETURN
    Hires - Exits
```
**Explanation:** Decomposes headcount growth into its two driver components — useful because the SAME net-zero growth number can mean "healthy churn" (high hires, high exits) or "frozen" (low hires, low exits), with very different strategic implications.

**Business Use Case:** Page 2 — paired with Headcount Growth Rate to add the "how" behind the "what."

**Performance Optimization Notes:** The `Years_At_Company < (1/12)` proxy for "hired this month" is a workaround for snapshot-only data. With true `FACT_RECRUITMENT` hire-date data (Phase 2 schema), replace with `CALCULATE(COUNTROWS(FACT_RECRUITMENT), FACT_RECRUITMENT[hire_date_key] = current period)` for accuracy.

---

### 5.3 Headcount Growth — Budget Variance
```dax
Headcount vs Budget Variance =
VAR ActualHC = [Total Employees]
VAR BudgetedHC = SUM( BudgetTable[BudgetedHeadcount] )  -- requires a budget table
RETURN
    ActualHC - BudgetedHC

Headcount vs Budget Variance % =
DIVIDE( [Headcount vs Budget Variance], SUM(BudgetTable[BudgetedHeadcount]), 0 )
```
**Explanation:** Compares actual to a separately-loaded budget table (one row per Department × Period with a `BudgetedHeadcount` column) — a common Power BI pattern joining operational data to planning data via Department key.

**Business Use Case:** Page 2 / Page 11 — the single most common question from Finance: "are we over or under our approved headcount plan."

**Performance Optimization Notes:** Requires `BudgetTable` to have a relationship to `Department` dimension (not directly to `HR_Data` fact, to avoid many-to-many ambiguity). If the relationship is correctly modeled as Dept(1) → BudgetTable(*) and Dept(1) → HR_Data(*), both measures resolve via simple cross-filtering with no formula-engine overhead.

---

### 5.4 Compound Annual Headcount Growth Rate (CAGR)
```dax
Headcount CAGR =
VAR EndHC   = [Total Employees]
VAR StartHC =
    CALCULATE(
        [Total Employees],
        DATEADD( DimDate[Date], -36, MONTH )   -- 3 years back
    )
VAR Years = 3
RETURN
    IF(
        StartHC > 0,
        ( EndHC / StartHC ) ^ ( 1/Years ) - 1,
        BLANK()
    )
```
**Explanation:** Standard CAGR formula applied to headcount over a fixed 3-year lookback — smooths out single-period noise for strategic planning narratives ("we've grown headcount at a 12% CAGR over 3 years").

**Business Use Case:** Page 15 Executive Summary — strategic, multi-year framing distinct from the month-over-month operational view on Page 2.

**Performance Optimization Notes:** The `IF(StartHC > 0, ...)` guard prevents errors when the Date table extends earlier than actual data exists (common in newly-deployed models where only 1 year of history has been loaded but the Date table spans 10 years for future-proofing).

---

### 5.5 Headcount Growth by Career Track
```dax
Headcount Growth - IC vs Manager =
VAR ICGrowth =
    VAR ICCurrent = CALCULATE([Total Employees], HR_Data[Job_Level] IN {"L2","L3","L4"})
    VAR ICPrior   = CALCULATE([Total Employees], HR_Data[Job_Level] IN {"L2","L3","L4"}, DATEADD(DimDate[Date],-12,MONTH))
    RETURN DIVIDE(ICCurrent-ICPrior, ICPrior, 0)
VAR MgmtGrowth =
    VAR MgmtCurrent = CALCULATE([Total Employees], HR_Data[Job_Level] IN {"L5","L6","L7","L8"})
    VAR MgmtPrior   = CALCULATE([Total Employees], HR_Data[Job_Level] IN {"L5","L6","L7","L8"}, DATEADD(DimDate[Date],-12,MONTH))
    RETURN DIVIDE(MgmtCurrent-MgmtPrior, MgmtPrior, 0)
RETURN
    MgmtGrowth - ICGrowth
```
**Explanation:** Compares the growth rate of management-track levels vs. IC-track levels. A positive result means management headcount is growing FASTER than IC headcount — a leading indicator of organizational "top-heaviness" developing (links to Section 1.4 of KPI Framework).

**Business Use Case:** Early warning for the Org Pyramid Ratio KPI — catches the trend BEFORE the pyramid ratio itself becomes visibly unhealthy.

**Performance Optimization Notes:** `IN {...}` set syntax for Job_Level filtering compiles to an efficient `OR` predicate pushed to the storage engine. Four nested `CALCULATE`/`DATEADD` combinations — for performance-sensitive dashboards, consider materializing `CareerTrack` as a calculated column (already done in Phase 2 `DIM_ROLE`) and filtering on that single column instead of an `IN` set across two measures.

---

# 6. TRAINING EFFECTIVENESS — ADVANCED VARIANTS

### 6.1 Training Effectiveness Index (Composite)
```dax
Training Effectiveness Index =
VAR RetentionLift =
    [Avg Training Hours - Active] - [Avg Training Hours - Attrited]
VAR PerfCorrelation =
    -- Simplified: avg performance of high-training vs low-training group
    VAR HighTrainingPerf =
        CALCULATE(
            AVERAGE( HR_Data[Performance_Rating] ),
            HR_Data[Training_Hours] >= 40
        )
    VAR LowTrainingPerf =
        CALCULATE(
            AVERAGE( HR_Data[Performance_Rating] ),
            HR_Data[Training_Hours] < 20
        )
    RETURN HighTrainingPerf - LowTrainingPerf
VAR ComplianceRate =
    DIVIDE(
        CALCULATE( COUNTROWS(HR_Data), HR_Data[Training_Hours] >= 20 ),
        COUNTROWS(HR_Data),
        0
    )
RETURN
    ( RetentionLift / 10 * 0.4 )      -- normalize hours-delta, 40% weight
    + ( PerfCorrelation * 0.4 )        -- performance delta, 40% weight
    + ( ComplianceRate * 0.2 )         -- baseline coverage, 20% weight
```
**Explanation:** Combines three signals into a single index: (1) does training correlate with retention, (2) does training correlate with performance, (3) is training reaching enough of the population. Each is normalized and weighted.

**Business Use Case:** Page 9 — a single number L&D can track quarter-over-quarter to demonstrate program value, rather than just reporting "hours delivered" (an input metric, not an outcome metric).

**Performance Optimization Notes:** This measure chains 5 `CALCULATE` calls — each triggers a context transition. For dashboards refreshing this on every slicer change across a large model, consider splitting into 3 separate measures (visible individually on a detail page) and only computing the weighted composite on the summary page where it's actually displayed, reducing redundant evaluation when users are on detail pages.

---

### 6.2 Training Hours per High-Performer
```dax
Training Investment Concentration =
VAR HiPoHours =
    CALCULATE(
        AVERAGE( HR_Data[Training_Hours] ),
        HR_Data[Performance_Rating] >= 4
    )
VAR OthersHours =
    CALCULATE(
        AVERAGE( HR_Data[Training_Hours] ),
        HR_Data[Performance_Rating] < 4
    )
RETURN
    DIVIDE( HiPoHours, OthersHours, 0 )
```
**Explanation:** Ratio >1 means high performers receive MORE training investment than the general population — could reflect intentional "invest in your best" strategy, OR could reflect a self-reinforcing pattern where already-strong performers get disproportionate development while struggling performers are neglected (a potential equity concern).

**Business Use Case:** Page 9 — context measure that informs whether L&D budget allocation philosophy matches stated talent strategy.

**Performance Optimization Notes:** Two simple filtered averages — fully storage-engine resolvable, sub-millisecond at this data volume.

---

### 6.3 Compliance Training At-Risk Count
```dax
Compliance At Risk Count =
CALCULATE(
    COUNTROWS( HR_Data ),
    HR_Data[Training_Hours] < 8   -- proxy: <8hrs likely missed mandatory modules
)

Compliance At Risk Trend =
VAR Current = [Compliance At Risk Count]
VAR Prior =
    CALCULATE( [Compliance At Risk Count], DATEADD(DimDate[Date], -1, MONTH) )
RETURN
    Current - Prior
```
**Explanation:** Identifies employees whose total training hours fall below a threshold likely indicating missed mandatory compliance modules (proxy in the absence of a dedicated `is_mandatory_flag` join — Phase 2 `FACT_TRAINING` schema has the proper flag for production use).

**Business Use Case:** Page 9 compliance RAG — surfaces a trend (is the at-risk population growing or shrinking) not just a snapshot count.

**Performance Optimization Notes:** This is explicitly a *proxy* measure for the flat single-table model. Once `FACT_TRAINING.is_mandatory_flag` and `is_overdue_flag` (Phase 2) are loaded, replace with `CALCULATE(DISTINCTCOUNT(FACT_TRAINING[employee_key]), FACT_TRAINING[is_mandatory_flag]=TRUE, FACT_TRAINING[completion_flag]=FALSE)` for accuracy.

---

### 6.4 Training ROI Proxy ($)
```dax
Training ROI Proxy =
VAR TotalTrainingCost = [Training Cost Estimate]   -- from Phase 4: Total Hours * $50
VAR RetentionSavings =
    VAR AttritionWithLowTraining =
        CALCULATE(
            COUNTROWS(HR_Data),
            HR_Data[Attrition]="Yes",
            HR_Data[Training_Hours] < 20
        )
    VAR ImpliedPreventedExits = AttritionWithLowTraining * 0.15  -- assume 15% would be retained with adequate training
    RETURN ImpliedPreventedExits * [Avg Salary] * 1.5
RETURN
    DIVIDE( RetentionSavings - TotalTrainingCost, TotalTrainingCost, 0 )
```
**Explanation:** A deliberately transparent, assumption-driven ROI estimate — explicitly states its 15% "implied prevention rate" assumption as a named variable so report consumers (and report builders) can see and adjust the assumption rather than treating ROI as a black box.

**Business Use Case:** Page 9 — when L&D budget is challenged, this measure gives a directional (not precision-claimed) financial argument. The accompanying tooltip/documentation MUST disclose the 15% assumption.

**Performance Optimization Notes:** All components are previously-defined measures or simple filtered counts — composition reuse keeps this cheap. The business risk here is interpretive (assumption transparency), not computational.

---

### 6.5 Skills Coverage Ratio by Domain
```dax
Skills Coverage Ratio =
VAR TargetHoursPerDomain = 20   -- minimum hours considered "covered" for a domain
VAR EmployeesCovered =
    CALCULATE(
        COUNTROWS( HR_Data ),
        HR_Data[Training_Hours] >= TargetHoursPerDomain
    )
RETURN
    DIVIDE( EmployeesCovered, COUNTROWS(HR_Data), 0 )
```
**Explanation:** Simplified single-domain coverage ratio. In the full Phase 2 model with `FACT_TRAINING.skill_domain_code`, this would be evaluated per-domain via `SUMMARIZE` to produce the radar chart data for Page 9.

**Business Use Case:** Page 9 radar chart — one value per skill domain spoke.

**Performance Optimization Notes:** For the multi-domain radar chart, wrap this logic in `SUMMARIZECOLUMNS` against `FACT_TRAINING[skill_domain_code]` to produce one row per domain in a single query rather than one measure call per domain — dramatically reduces visual query count from N (domains) to 1.

---

# 7. EMPLOYEE RISK SCORE — ADVANCED VARIANTS

### 7.1 Employee Risk Score (Rule-Based Composite, 0-100)
```dax
Employee Risk Score =
VAR EngRisk  = MAX( 0, (60 - HR_Data[Engagement_Score]) / 60 ) * 30
VAR SatRisk  = MAX( 0, (55 - HR_Data[Satisfaction_Score]) / 55 ) * 20
VAR AttRisk  = MAX( 0, (88 - HR_Data[Attendance_Pct]) / 88 ) * 10
VAR TenRisk  =
    SWITCH(
        TRUE(),
        HR_Data[Years_At_Company] < 1, 20,
        HR_Data[Years_At_Company] < 2, 12,
        HR_Data[Years_At_Company] > 8, 8,
        0
    )
VAR PromoRisk =
    VAR Gap = HR_Data[Years_At_Company]/2.8 - HR_Data[Promotions]
    RETURN MIN( MAX(Gap,0) * 5, 15 )
VAR PayRisk  =
    VAR CR = HR_Data[Compa_Ratio]
    RETURN IF( CR < 0.85, (0.85-CR) * 100, 0 )
RETURN
    MIN( EngRisk + SatRisk + AttRisk + TenRisk + PromoRisk + PayRisk, 100 )
```
**Explanation:** A transparent, rule-based (non-ML) risk score combining 6 weighted factors that mirror the SHAP-discovered drivers from the Phase 4 ML model — but expressed as auditable business rules rather than a black-box model, useful for organizations not yet ready to deploy ML scoring or for "explaining" the ML score in business terms.

**Business Use Case:** Page 10 — can be displayed ALONGSIDE the ML `Flight_Risk_Score` as a "business rules" cross-check. If the two scores diverge significantly for an individual, that's itself a signal worth investigating (the ML model may be picking up a pattern not captured by these explicit rules, or vice versa).

**Performance Optimization Notes:** This measure operates in row context (intended for use in a calculated column or within `SUMX`/`AVERAGEX`). As written, it references `HR_Data[Column]` directly which only works inside row-context iterators or as a calculated column. For a true DAX *measure* (aggregate context), wrap the entire body in `AVERAGEX(HR_Data, ...)` or `SUMX` as appropriate. **Recommended implementation: as a calculated column** (computed once at refresh, not per query) given its complexity — see Phase 4 Section 13 pattern.

---

### 7.2 Employee Risk Score — Average by Segment
```dax
Avg Employee Risk Score =
AVERAGEX(
    HR_Data,
    [Employee Risk Score]   -- assuming 7.1 implemented as calculated column
)
```
**Explanation:** Aggregates the per-row risk score (calculated column) to any filter context — department, level, manager, etc.

**Business Use Case:** Page 10 "Risk by Department" bar chart and Page 11 department bullet charts.

**Performance Optimization Notes:** If 7.1 is a calculated column (recommended), this becomes a trivial `AVERAGE(HR_Data[Employee Risk Score])` — storage-engine resolvable, the fastest possible pattern.

---

### 7.3 Risk Score Model Agreement Rate
```dax
Risk Model Agreement Rate =
VAR BothHighRisk =
    CALCULATE(
        COUNTROWS(HR_Data),
        HR_Data[Employee Risk Score] >= 70,
        HR_Data[Flight_Risk_Score] >= 70   -- from ML output, Phase 4
    )
VAR EitherHighRisk =
    CALCULATE(
        COUNTROWS(HR_Data),
        HR_Data[Employee Risk Score] >= 70 || HR_Data[Flight_Risk_Score] >= 70
    )
RETURN
    DIVIDE( BothHighRisk, EitherHighRisk, 0 )
```
**Explanation:** Computes the overlap (Jaccard-similarity-style) between the rule-based score (7.1) and the ML score from Phase 4 — both flagging the same individuals as high-risk validates both approaches; low overlap warrants investigation into which signals each is capturing that the other misses.

**Business Use Case:** Model governance / Page 10 — a "model health" indicator for the data science team and HR leadership jointly, supporting trust in the AI system by showing it agrees with explainable business logic most of the time.

**Performance Optimization Notes:** Requires `HR_Data[Flight_Risk_Score]` to be present (merged from the Phase 4 `PeoplePulse_Flight_Risk_Scores.csv` via `Employee_ID` join, per the Power BI setup instructions in Phase 4). The `||` boolean OR inside CALCULATE generates a UNION-style filter — for very large tables, an alternative is `COUNTROWS(A) + COUNTROWS(B) - COUNTROWS(BothHighRisk)` (inclusion-exclusion) which can sometimes be cheaper than the OR predicate.

---

### 7.4 Risk-Weighted Headcount (Capacity Planning)
```dax
Risk Weighted Headcount Loss Projection =
SUMX(
    HR_Data,
    HR_Data[Flight_Risk_Score] / 100   -- probability-weighted "expected exits"
)
```
**Explanation:** Rather than a binary "275 people are high-risk," this sums each individual's risk probability — producing an "expected value" of total exits across the WHOLE population (including medium/low risk individuals who collectively still contribute non-trivial expected attrition).

**Business Use Case:** Page 10 — feeds workforce planning's "expected attrition" forecast input, more statistically sound than only counting the high-risk bucket (which ignores the much larger medium-risk population's aggregate contribution).

**Performance Optimization Notes:** `SUMX` over 10,000 rows with a simple division — trivial. This pattern (summing probabilities for an expectation) is the statistically correct way to aggregate probabilistic model outputs; summing COUNTS of binary-thresholded categories (as in 7.1-7.3) is useful for *operational triage* but UNDERSTATES total expected attrition. Both framings should be presented together with this distinction explained in the report's methodology notes.

---

### 7.5 Risk Score Percentile Rank
```dax
Risk Score Percentile =
VAR CurrentScore = SELECTEDVALUE( HR_Data[Flight_Risk_Score] )
RETURN
    CALCULATE(
        COUNTROWS( HR_Data ),
        HR_Data[Flight_Risk_Score] <= CurrentScore
    ) / COUNTROWS( ALL(HR_Data) )
```
**Explanation:** For an individual employee row (Page 13), shows where their risk score ranks relative to the entire company population — "this employee's risk score is higher than 94% of the company" is more intuitive for an HRBP than the raw 0-100 number alone.

**Business Use Case:** Page 13 Employee Drillthrough — contextualizes the gauge value.

**Performance Optimization Notes:** `COUNTROWS(ALL(HR_Data))` forces a full-table count ignoring all filters — on Page 13 (single-employee context via drillthrough), this is evaluated once per page load, negligible cost. Avoid this pattern inside a visual that renders thousands of rows (e.g., a full employee table) as it would force a full table scan per row.

---

### 7.6 Risk Tier Migration (requires historical scoring)
```dax
Risk Tier Migration =
VAR CurrentTier =
    SWITCH(
        TRUE(),
        SELECTEDVALUE(HR_Data[Flight_Risk_Score]) >= 70, "High",
        SELECTEDVALUE(HR_Data[Flight_Risk_Score]) >= 45, "Medium",
        SELECTEDVALUE(HR_Data[Flight_Risk_Score]) >= 25, "Low",
        "Engaged"
    )
VAR PriorTier =
    VAR PriorScore =
        CALCULATE(
            MAX( FlightRiskHistory[Score] ),
            DATEADD( DimDate[Date], -1, MONTH )
        )
    RETURN
        SWITCH(
            TRUE(),
            PriorScore >= 70, "High",
            PriorScore >= 45, "Medium",
            PriorScore >= 25, "Low",
            "Engaged"
        )
RETURN
    CurrentTier & " ← " & PriorTier
```
**Explanation:** Shows tier transition (e.g., "High ← Medium") — identifies individuals whose risk is WORSENING (actionable: intervene now) vs. those who've been High Risk for months (different intervention may be needed — perhaps retention efforts already failed).

**Business Use Case:** Page 10 — prioritizes the high-risk list by "newly escalated" vs. "chronically high," since these warrant different urgency/approach.

**Performance Optimization Notes:** Requires a `FlightRiskHistory` table with weekly snapshots (per Phase 2 `hr.FlightRiskScore` design with `ScoringDate`). This is the most "advanced" measure in this section — flagged as Phase 8+ functionality once historical scoring accumulates beyond a single snapshot.

---

# 8. DEPARTMENT RANKING — ADVANCED VARIANTS

### 8.1 Department Rank by Attrition (Worst First)
```dax
Department Rank - Attrition =
RANKX(
    ALL( HR_Data[Department] ),
    CALCULATE( [Attrition Rate] ),
    ,
    DESC
)
```
**Explanation:** `RANKX` over `ALL(Department)` ranks every department by its attrition rate, with rank 1 = highest (worst) attrition. The `ALL` ensures the ranking universe is always "all departments" regardless of any single-department slicer that might otherwise restrict it.

**Business Use Case:** Page 3 / Page 11 — "Customer Success is ranked #1 (worst) of 11 departments for attrition" is a more visceral framing than the raw percentage alone.

**Performance Optimization Notes:** `RANKX` re-evaluates its expression argument for EVERY item in the ranking table — for 11 departments this means 11 evaluations of `[Attrition Rate]` per single RANKX call. At this scale (11 departments × 10,000 rows), negligible. For high-cardinality ranking dimensions (e.g., ranking 5,000 individual managers), `RANKX` becomes a meaningful cost center — consider pre-computing ranks in a summary table during refresh for dimensions >500 members.

---

### 8.2 Composite Department Health Rank
```dax
Department Health Composite Score =
VAR AttritionScore   = (1 - [Attrition Rate]) * 30
VAR EngagementScore  = ([Avg Engagement Score] / 100) * 30
VAR PerfScore        = [Pct High Performers] * 20
VAR EquityScore      = (1 - ABS([Gender Pay Gap %])) * 20
RETURN
    AttritionScore + EngagementScore + PerfScore + EquityScore

Department Rank - Composite =
RANKX(
    ALL( HR_Data[Department] ),
    [Department Health Composite Score],
    ,
    DESC   -- highest composite score = healthiest = rank 1
)
```
**Explanation:** Combines 4 KPI domains (attrition, engagement, performance, pay equity) into a single weighted health score (0-100), then ranks departments by it — answers "which department is healthiest overall" rather than requiring executives to mentally synthesize 4 separate rankings that might disagree.

**Business Use Case:** Page 1 / Page 15 — a single "department league table" that's more digestible than 4 separate ranking visuals, especially for board materials.

**Performance Optimization Notes:** The composite score measure is called once per `RANKX` evaluation per department (11 times) — each call itself composes 4 sub-measures. Total evaluation count ≈ 11 × 4 = 44 measure evaluations for the full ranking — still trivial at this scale, but illustrates why composite-of-composite measures should be flagged for review if the underlying dimension cardinality grows substantially (e.g., ranking 200 cost centers instead of 11 departments → 800 evaluations, still fine; ranking 5,000 managers → 20,000 evaluations, now worth optimizing).

---

### 8.3 Department Percentile Rank (Normalized 0-100)
```dax
Department Percentile - Engagement =
VAR CurrentDeptAvg = [Avg Engagement Score]
VAR TotalDepts = COUNTROWS( ALL(HR_Data[Department]) )
VAR DeptsBelow =
    COUNTROWS(
        FILTER(
            ALL( HR_Data[Department] ),
            CALCULATE([Avg Engagement Score]) < CurrentDeptAvg
        )
    )
RETURN
    DIVIDE( DeptsBelow, TotalDepts - 1, 0 ) * 100
```
**Explanation:** Converts a rank (1st, 2nd, 3rd...) into a percentile (0-100) — "this department is in the 80th percentile for engagement" is a more universally-understood framing than "ranked 2nd of 11," especially when comparing across different KPIs with different total counts.

**Business Use Case:** Page 11 bullet charts — percentile framing allows a single visual scale (0-100) to represent department standing across ALL KPIs consistently, regardless of how many departments/locations/levels exist in each grouping.

**Performance Optimization Notes:** The `FILTER(ALL(...), ...)` pattern requires evaluating `[Avg Engagement Score]` once per department within the filter — same cost profile as 8.1's RANKX. Functionally equivalent to `RANKX` but expressed as percentile; choose ONE pattern (RANKX-based or FILTER-based) consistently across the model rather than mixing, for maintainability.

---

### 8.4 Top/Bottom N Department Highlighter
```dax
Is Top 3 Attrition Department =
VAR CurrentRank = [Department Rank - Attrition]
RETURN
    IF( CurrentRank <= 3, "🔴 Top 3 Concern", "" )

Is Bottom 3 Engagement Department =
VAR EngRank =
    RANKX( ALL(HR_Data[Department]), CALCULATE([Avg Engagement Score]), , ASC )
RETURN
    IF( EngRank <= 3, "🟡 Bottom 3 Engagement", "" )
```
**Explanation:** Converts numeric ranks into highlight flags for conditional formatting — "Top 3 Attrition" (ASC for attrition means highest rate = rank 1-3) and "Bottom 3 Engagement" (lowest scores).

**Business Use Case:** Page 1 / Page 3 — drives conditional formatting rules in tables/matrices to visually highlight the departments needing attention without manual threshold-setting that becomes stale as the org changes.

**Performance Optimization Notes:** Reuses 8.1's ranking measure — composition keeps this cheap. Returning empty string `""` rather than `BLANK()` for the "false" case ensures the conditional formatting rule (often string-based, e.g., "show icon if value = 🔴 Top 3 Concern") behaves predictably; `BLANK()` can sometimes cause inconsistent icon-rule evaluation in older Power BI Desktop versions.

---

### 8.5 Department Trend Direction Arrow
```dax
Department Attrition Trend Arrow =
VAR CurrentRate = [Attrition Rate]
VAR PriorRate   = CALCULATE([Attrition Rate], DATEADD(DimDate[Date],-3,MONTH))
VAR ChangeThreshold = 0.01   -- 1 percentage point — below this, consider "flat"
RETURN
    SWITCH(
        TRUE(),
        ISBLANK(PriorRate), "—",
        CurrentRate - PriorRate >  ChangeThreshold, "▲",
        CurrentRate - PriorRate < -ChangeThreshold, "▼",
        "→"
    )
```
**Explanation:** A 3-month-over-3-month comparison with a "deadband" threshold (±1 point) before showing a directional arrow — prevents visual noise from showing ▲/▼ arrows for statistically meaningless month-to-month fluctuations (e.g., 18.1% vs 18.3% shouldn't trigger an "increasing" alert arrow).

**Business Use Case:** Page 11 department summary tables — the "→" (flat) state is itself informative (stable, no action needed) vs forcing every cell to show ▲ or ▼ even for noise-level changes.

**Performance Optimization Notes:** The `ISBLANK(PriorRate)` check handles the edge case of departments newly created within the last 3 months (no historical comparison possible) — without this guard, `SWITCH` would evaluate `BLANK() - CurrentRate` which DAX handles gracefully (treats BLANK as 0) but produces a misleading "▲" for a brand-new department with 0% prior attrition, which this explicit check avoids.

---

# 9. WORKFORCE HEALTH SCORE — COMPOSITE MEASURES

### 9.1 Workforce Health Score (Master Composite, 0-100)
```dax
Workforce Health Score =
VAR AttritionComponent  = ( 1 - MIN([Attrition Rate], 0.5) / 0.5 ) * 25
VAR EngagementComponent = ( [Avg Engagement Score] / 100 ) * 25
VAR PerformanceComponent = [Pct High Performers] * 20
VAR EquityComponent =
    ( 1 - MIN( ABS([Gender Pay Gap %]), 0.10 ) / 0.10 ) * 15
VAR AttendanceComponent = ( [Avg Attendance Pct] / 100 ) * 15
RETURN
    AttritionComponent + EngagementComponent + PerformanceComponent
    + EquityComponent + AttendanceComponent
```
**Explanation:** The single "headline number" for the entire platform — a 0-100 composite blending 5 KPI domains with explicit weights (25/25/20/15/15) chosen to reflect that attrition and engagement are the most consequential (combined 50%), with performance, equity, and attendance each contributing meaningfully but secondarily. Each component is normalized/capped (e.g., attrition capped at 50% to prevent a catastrophic outlier from producing a negative score) before weighting.

**Business Use Case:** Page 1 hero visual (large radial gauge) and Page 15 headline — THE number a CEO glances at. All other dashboard pages exist to explain movements in this one number.

**Performance Optimization Notes:** This measure composes 5 already-defined measures — each of which may itself be a composite (e.g., `[Pct High Performers]`). Total computational depth is shallow (2-3 levels) and Power BI's formula engine caches intermediate results within a single visual's evaluation, so depth alone isn't a concern. The real consideration: this measure should be calculated ONCE per filter context and DISPLAYED prominently — avoid placing it in a high-cardinality table (e.g., one row per employee) where it would be redundantly evaluated thousands of times with identical inputs.

---

### 9.2 Workforce Health Score — Trend
```dax
Workforce Health Score Trend =
VAR Current = [Workforce Health Score]
VAR Prior   = CALCULATE([Workforce Health Score], DATEADD(DimDate[Date],-1,MONTH))
RETURN
    Current - Prior

Workforce Health Score Trend Label =
VAR Delta = [Workforce Health Score Trend]
RETURN
    SWITCH(
        TRUE(),
        ISBLANK(Delta), "No prior data",
        Delta > 2,  "📈 Improving (+" & FORMAT(Delta,"0.0") & ")",
        Delta < -2, "📉 Declining (" & FORMAT(Delta,"0.0") & ")",
        "➡️ Stable"
    )
```
**Explanation:** Tracks the composite score's own trajectory over time, with the same "deadband" pattern as 8.5 to avoid noise-driven labels.

**Business Use Case:** Page 1 subtitle beneath the main gauge — "Workforce Health: 71.2 📈 Improving (+2.4)".

**Performance Optimization Notes:** Calls the composite measure twice (current + prior period context) — each call internally evaluates 5 sub-measures, so this is effectively a ~10-measure-evaluation chain. Still trivial for a single KPI card, but this measure should NOT be used inside a visual that iterates over many rows/categories.

---

### 9.3 Workforce Health Score — Department Comparison
```dax
Workforce Health Score - Selected vs Company =
VAR SelectedDeptScore = [Workforce Health Score]
VAR CompanyScore = CALCULATE( [Workforce Health Score], ALL(HR_Data[Department]) )
RETURN
    SelectedDeptScore - CompanyScore
```
**Explanation:** Shows how a department's composite health compares to the company-wide composite — used in Page 11's bullet-chart-style visuals.

**Business Use Case:** Page 11 — "This department's Health Score is 6.3 points BELOW the company average" gives instant relative context to the absolute number.

**Performance Optimization Notes:** `ALL(HR_Data[Department])` removes only the Department filter while preserving any other active filters (Location, Job Level, etc.) — this is intentional, allowing "this department vs. company, both filtered to the same Job Level slicer selection" comparisons. If a TOTAL company baseline (ignoring ALL filters) is desired instead, use `ALL(HR_Data)` (whole table) — choose deliberately based on the analytical question.

---

### 9.4 Workforce Health Score — Component Contribution Breakdown
```dax
Health Score Component - Attrition Contribution =
VAR Component = ( 1 - MIN([Attrition Rate], 0.5) / 0.5 ) * 25
VAR MaxPossible = 25
RETURN
    Component / MaxPossible   -- returns 0-1, format as % in visual
```
**Explanation:** Isolates ONE component's contribution as a percentage of its own maximum possible contribution — five such measures (one per component) feed a stacked bar showing "which component is dragging the score down."

**Business Use Case:** Page 1 — clicking into the Health Score gauge could surface a small stacked bar showing "Attrition: 60% of max | Engagement: 85% of max | ..." — visually identifying which domain needs the most attention to move the headline number.

**Performance Optimization Notes:** Five near-identical measures (one per component) with hardcoded `MaxPossible` denominators (25/25/20/15/15 matching 9.1's weights) — if 9.1's weights are ever changed, ALL FIVE of these measures plus 9.1 itself must be updated consistently. Recommend extracting weights into a small disconnected "Weights" table referenced by all six measures via `LOOKUPVALUE`, so weight changes happen in ONE place.

---

### 9.5 Workforce Health Score — Simulated "What-If"
```dax
Workforce Health Score - What If Attrition Improves =
VAR ImprovementPts = 'Attrition Improvement Parameter'[Value]  -- What-If parameter, 0-10
VAR SimulatedAttritionRate = MAX( [Attrition Rate] - (ImprovementPts/100), 0 )
VAR SimulatedAttritionComponent =
    ( 1 - MIN(SimulatedAttritionRate, 0.5) / 0.5 ) * 25
VAR OtherComponents =
    [Workforce Health Score]
    - ( ( 1 - MIN([Attrition Rate], 0.5) / 0.5 ) * 25 )   -- subtract current attrition component
RETURN
    OtherComponents + SimulatedAttritionComponent
```
**Explanation:** Uses a Power BI "What-If" parameter (a slider from 0-10 representing "percentage points of attrition improvement") to recompute the Health Score under a hypothetical scenario — "if we reduced attrition by 5 points, our Health Score would rise from 71.2 to 76.8."

**Business Use Case:** Page 10 — scenario-planning tool for the CHRO to quantify the Health Score impact of a proposed retention initiative BEFORE committing budget, supporting the business case.

**Performance Optimization Notes:** What-If parameters in Power BI generate a small disconnected table with a `[Value]` column bound to a slicer — referencing it via `'TableName'[Value]` (not wrapped in `SELECTEDVALUE`, though `SELECTEDVALUE` is safer if multiple values could theoretically be selected) triggers re-evaluation of this measure on every slider movement. For smooth slider interaction, ensure this measure's dependency chain (which includes the full 9.1 composite) isn't ALSO being recalculated for hundreds of other visuals simultaneously — consider placing What-If visuals on a dedicated page (Page 10) rather than embedding them in high-traffic pages like Page 1.

---

# 10. MANAGER EFFECTIVENESS SCORE — ADVANCED VARIANTS

### 10.1 Manager Effectiveness Score (Refined Composite)
```dax
Manager Effectiveness Score V2 =
VAR TeamEngagement  = CALCULATE( AVERAGE(HR_Data[Engagement_Score]) )
VAR TeamRetention   = 1 - CALCULATE( [Attrition Rate] )
VAR TeamHighPerfPct = CALCULATE( [Pct High Performers] )
VAR TeamPromoRate   = CALCULATE( [Promotion Rate] )
VAR TeamSize        = CALCULATE( COUNTROWS(HR_Data) )
VAR SizeConfidenceFactor =
    -- Small teams get a confidence discount — a single departure swings their metrics wildly
    MIN( TeamSize / 8, 1 )    -- full confidence at team size >= 8
RETURN
    (
        ( TeamEngagement/100 * 0.35 )
      + ( TeamRetention      * 0.35 )
      + ( TeamHighPerfPct    * 0.20 )
      + ( TeamPromoRate      * 0.10 )
    ) * 100 * SizeConfidenceFactor
```
**Explanation:** Extends the Phase 4 manager effectiveness formula with a `SizeConfidenceFactor` — a manager with only 2 direct reports where 1 leaves has a 50% "team attrition rate," which would unfairly tank their score. The confidence factor scales down the score's magnitude (toward 0, conservatively) for small teams, signaling "insufficient data for a reliable score" rather than presenting a misleadingly extreme number.

**Business Use Case:** Page 12 — prevents the leaderboard from being dominated by small-team managers whose scores are statistical artifacts of tiny sample sizes (both unfairly high AND unfairly low scores get dampened).

**Performance Optimization Notes:** `MIN(TeamSize/8, 1)` is a simple scalar cap — negligible cost. The broader pattern (confidence-weighting small-sample metrics) is a best practice anywhere `RANKX` or leaderboards are built over populations with highly variable group sizes; without it, leaderboards are dominated by statistical noise from the smallest groups.

---

### 10.2 Manager Effectiveness — Percentile Rank
```dax
Manager Effectiveness Percentile =
VAR CurrentManagerScore = [Manager Effectiveness Score V2]
VAR AllManagerScores =
    ADDCOLUMNS(
        VALUES( HR_Data[Manager_ID] ),
        "Score", CALCULATE( [Manager Effectiveness Score V2] )
    )
VAR ManagersBelow =
    COUNTROWS( FILTER( AllManagerScores, [Score] < CurrentManagerScore ) )
VAR TotalManagers = COUNTROWS( AllManagerScores )
RETURN
    DIVIDE( ManagersBelow, TotalManagers - 1, 0 ) * 100
```
**Explanation:** `ADDCOLUMNS` over `VALUES(Manager_ID)` constructs a virtual table of every manager paired with their computed score, then ranks the current manager against that virtual table — necessary because `RANKX` over a high-cardinality dimension (potentially hundreds of managers) benefits from this materialized-virtual-table pattern for readability, even though performance is similar to direct `RANKX`.

**Business Use Case:** Page 12 — "This manager's Effectiveness Score is in the 88th percentile of all managers" for individual manager review conversations (Page 13-style drillthrough for managers).

**Performance Optimization Notes:** `ADDCOLUMNS(VALUES(...), "Score", CALCULATE(...))` materializes ONE score per manager — for 500+ managers, this virtual table has 500+ rows each requiring a `CALCULATE` context transition. This is the single most expensive measure in this library. **Mitigation:** if this percentile is needed broadly (e.g., shown for every manager in a table), compute it ONCE as part of a `SUMMARIZECOLUMNS`-based calculated table at model-refresh time (a "Manager Scores" summary table), then this measure becomes a simple lookup — moving cost from query-time to refresh-time.

---

### 10.3 Manager Effectiveness — Engagement Component Isolation
```dax
Manager Score - Engagement Driver Only =
CALCULATE( AVERAGE(HR_Data[Engagement_Score]) ) / 100 * 35
```
**Explanation:** Isolates just the engagement-driven 35% of the score (per 10.1's weighting) — paired with similar isolations for the retention (10.4) and performance components, enabling a stacked bar "what's driving THIS manager's score" visual.

**Business Use Case:** Page 12 "Selected Manager: Component Breakdown" stacked bar — when an HR Director clicks a specific manager row, this shows WHY their score is what it is, supporting a specific coaching conversation ("your score is dragged down by the retention component specifically, not engagement").

**Performance Optimization Notes:** Simple filtered average with a constant multiplier — trivial. The value of this measure is entirely in its DECOMPOSITION clarity for the stacked-bar visual, not computational complexity.

---

### 10.4 Manager Tenure-Adjusted Effectiveness
```dax
Manager Effectiveness - Tenure Adjusted =
VAR RawScore = [Manager Effectiveness Score V2]
VAR ManagerTenureMonths =
    CALCULATE(
        AVERAGE( HR_Data[Years_At_Company] ),
        ALLEXCEPT( HR_Data, HR_Data[Manager_ID] )  -- the manager's OWN tenure, not their team's
    ) * 12
VAR GracePeriodMonths = 6
RETURN
    IF(
        ManagerTenureMonths < GracePeriodMonths,
        BLANK(),    -- too new to evaluate fairly
        RawScore
    )
```
**Explanation:** Returns `BLANK()` (displayed as "—" or "New Manager — Not Yet Rated" via a tooltip) for managers in their first 6 months in role — a team's metrics largely reflect the PREVIOUS manager's influence during this period, and scoring a brand-new manager on inherited team conditions is both unfair and produces noisy data.

**Business Use Case:** Page 12 — prevents new managers from appearing at the bottom of a leaderboard for circumstances outside their control, while the system "warms up" enough data attributable to their actual management.

**Performance Optimization Notes:** `ALLEXCEPT(HR_Data, HR_Data[Manager_ID])` is a precise context-manipulation — it removes all filters EXCEPT Manager_ID, ensuring the tenure calculation reflects "all rows where THIS person is the Manager_ID" (i.e., looking at the manager as an employee elsewhere in the table) rather than "all rows in the currently filtered team." This is a subtle but important pattern — confirm the manager's own employee record exists as a row in `HR_Data` (it does, since `Manager_ID` references valid `Employee_ID` values per Phase 3 design) for this to resolve correctly.

---

### 10.5 Manager Effectiveness — Cohort-Relative Score
```dax
Manager Effectiveness - Cohort Relative =
VAR ThisManagerScore = [Manager Effectiveness Score V2]
VAR PeerCohortAvg =
    -- compare only to managers at the SAME level (fair comparison)
    VAR ThisManagerLevel =
        CALCULATE(
            SELECTEDVALUE(HR_Data[Job_Level]),
            ALLEXCEPT(HR_Data, HR_Data[Manager_ID])
        )
    RETURN
        CALCULATE(
            AVERAGEX(
                VALUES(HR_Data[Manager_ID]),
                CALCULATE([Manager Effectiveness Score V2])
            ),
            ALL(HR_Data[Manager_ID]),
            HR_Data[Job_Level] = ThisManagerLevel
        )
RETURN
    ThisManagerScore - PeerCohortAvg
```
**Explanation:** Compares a manager's score not to ALL managers, but only to peers at the SAME job level — a newly-promoted Team Lead (L5) shouldn't be benchmarked against VPs (L7) with vastly different team sizes, budgets, and organizational influence.

**Business Use Case:** Page 12 — "This Director's Effectiveness Score is +4.2 vs. the average Director" is a fairer framing than comparing across the entire management hierarchy.

**Performance Optimization Notes:** This is the most structurally complex measure in the library — it nests `AVERAGEX` over `VALUES(Manager_ID)` (potentially hundreds of managers) WITHIN a `CALCULATE` that's already iterating for the current manager's comparison. As with 10.2, this pattern should be moved to a refresh-time summary table (`SUMMARIZECOLUMNS` by Manager_ID and Job_Level, pre-computing peer-cohort averages) for any model beyond a handful of managers. **Flagged as a candidate for the Phase 2 `AGG_*` pre-aggregation pattern** — create `AGG_MANAGER_COHORT_SCORES` refreshed nightly.

---

# 11. TIME INTELLIGENCE & UTILITY MEASURES

### 11.1 Dynamic Period Label
```dax
Selected Period Label =
VAR MinDate = MIN( DimDate[Date] )
VAR MaxDate = MAX( DimDate[Date] )
RETURN
    IF(
        MinDate = MaxDate,
        FORMAT( MinDate, "MMMM YYYY" ),
        FORMAT( MinDate, "MMM YYYY" ) & " – " & FORMAT( MaxDate, "MMM YYYY" )
    )
```
**Explanation:** Generates a human-readable label for whatever date range is currently filtered — "March 2026" for a single month, or "Jan 2025 – Mar 2026" for a range.

**Business Use Case:** Page 15 Executive Summary title — "PeoplePulse Workforce Summary — March 2026" dynamically updates if a different period is selected, without manual title editing.

**Performance Optimization Notes:** `MIN`/`MAX` over the Date table's filtered context — trivial. Place this in a Card visual's title via "Conditional formatting → Field value" binding for full dynamism.

---

### 11.2 Data Freshness Indicator
```dax
Data Last Refreshed =
"Data as of: " & FORMAT( MAX(HR_Data[Loaded_At]), "MMM DD, YYYY HH:MM" ) & " UTC"
```
**Explanation:** Surfaces the ETL load timestamp (from the `LoadedAt`/`UpdatedAt` columns defined in the Phase 4 SQL schema) directly in the report — critical for executive trust ("is this number from today or from last month?").

**Business Use Case:** Footer of every page — especially Page 15 (Executive Summary) and Page 10 (Predictive, where ML model freshness matters).

**Performance Optimization Notes:** `MAX()` over a datetime column — fully storage-engine resolvable. Place in a Text Box with a dynamic field binding rather than a Card visual for more flexible footer styling.

---

### 11.3 Filter Context Summary (Dynamic Subtitle)
```dax
Active Filter Summary =
VAR DeptFilter =
    IF( ISFILTERED(HR_Data[Department]), SELECTEDVALUE(HR_Data[Department], "Multiple"), "All Departments" )
VAR LevelFilter =
    IF( ISFILTERED(HR_Data[Job_Level]), SELECTEDVALUE(HR_Data[Job_Level], "Multiple Levels"), "All Levels" )
VAR GenderFilter =
    IF( ISFILTERED(HR_Data[Gender]), SELECTEDVALUE(HR_Data[Gender], "Multiple"), "All Genders" )
RETURN
    DeptFilter & " | " & LevelFilter & " | " & GenderFilter
    & " | n=" & FORMAT( [Total Employees], "#,##0" )
```
**Explanation:** Builds a human-readable summary of every active slicer selection — "Engineering | All Levels | All Genders | n=2,213".

**Business Use Case:** Every page's subtitle area — when a user exports a filtered view to PDF (Page 15) or screenshots a visual for a Slack message, this subtitle travels WITH the visual, preventing the all-too-common "wait, was this filtered to just Engineering or the whole company?" confusion in downstream communication.

**Performance Optimization Notes:** Three `ISFILTERED`/`SELECTEDVALUE` checks plus one measure call — negligible. This pattern should be a STANDARD text box on every page's template — define once, copy across pages, rather than rebuilding per page.

---

### 11.4 Anomaly Flag (Statistical Outlier Detection)
```dax
Is Statistical Anomaly =
VAR CurrentValue = [Attrition Rate]
VAR HistoricalAvg =
    CALCULATE(
        AVERAGEX(
            VALUES( DimDate[MonthYear] ),
            CALCULATE( [Attrition Rate] )
        ),
        DATESINPERIOD( DimDate[Date], MAX(DimDate[Date]), -12, MONTH )
    )
VAR HistoricalStdDev =
    CALCULATE(
        STDEVX.P(
            VALUES( DimDate[MonthYear] ),
            CALCULATE( [Attrition Rate] )
        ),
        DATESINPERIOD( DimDate[Date], MAX(DimDate[Date]), -12, MONTH )
    )
VAR ZScore = DIVIDE( CurrentValue - HistoricalAvg, HistoricalStdDev, 0 )
RETURN
    ABS(ZScore) > 2
```
**Explanation:** Flags the current period as a statistical anomaly if it's more than 2 standard deviations from the trailing-12-month average — a more rigorous trigger for investigation than arbitrary fixed thresholds (e.g., "alert if >25%"), since it adapts to each department's own historical volatility.

**Business Use Case:** Page 14 AI Insights — feeds the "Anomaly Detection" narrative ("Attrition this month is a statistical anomaly — 2.4 standard deviations above the trailing 12-month average of 19.1%").

**Performance Optimization Notes:** `STDEVX.P` (population standard deviation) over 12 monthly values via `VALUES(DimDate[MonthYear])` — 12 context transitions for the average, 12 more for the std dev. For a single KPI card, trivial. This measure should NOT be used as a calculated column or in a row-by-row table — it's designed for single-value display (KPI card / narrative feed) only.

---

### 11.5 RLS Helper — Current User's Department
```dax
Current User Department =
LOOKUPVALUE(
    UserDepartmentMapping[Department],
    UserDepartmentMapping[UserPrincipalName], USERPRINCIPALNAME()
)
```
**Explanation:** `USERPRINCIPALNAME()` returns the logged-in Power BI user's email/UPN; `LOOKUPVALUE` cross-references a small mapping table (one row per HRBP/Manager → their assigned department) to retrieve that user's department assignment.

**Business Use Case:** Foundation for the RLS roles defined in Phase 6's RLS table — this measure can be used in a Row-Level Security DAX filter expression: `[Department] = [Current User Department]` applied to the HRBP role, automatically scoping their entire report view without needing a separate RLS rule per department (one rule, dynamically resolved).

**Performance Optimization Notes:** `LOOKUPVALUE` against a small (one-row-per-user) mapping table is very fast — but this function is evaluated on EVERY query for EVERY visual when used in an RLS filter (since RLS filters apply to all DAX queries for that session). Keep `UserDepartmentMapping` as a small, dedicated table (not a wide dimension table) and ensure it has a unique index on `UserPrincipalName` for optimal lookup performance — critical at enterprise scale with hundreds of concurrent HRBP sessions.

---

## APPENDIX: MEASURE GOVERNANCE NOTES

**Naming Convention:** `[Domain] [Metric] [Qualifier]` — e.g., "Attrition Rate Rolling 12M", "Manager Effectiveness Score V2". Versioned measures (V2) retained alongside originals during transition periods, with V1 marked deprecated in description metadata, not deleted (preserves backward compatibility for in-flight reports).

**Calculation Groups (Power BI Premium):** For organizations on Premium capacity, many of the "time intelligence" patterns (Rolling 12M, YoY, vs Target) across DIFFERENT base measures (Attrition Rate, Avg Salary, Engagement Score, etc.) are excellent candidates for **Calculation Groups** — define "Rolling 12M" ONE TIME as a calculation group item, apply it to ANY base measure, rather than writing `[X Rolling 12M]` for every X. This Phase 7 library writes explicit per-measure variants for clarity/portability (works on Power BI Pro), but Premium-tier implementations should refactor toward calculation groups to reduce the measure count from 50+ to a more maintainable ~15 base measures + ~5 calculation group items.

**Testing Protocol:** Every measure in this library should be validated against the SQL queries in Phase 4 (`PeoplePulse_SQL_Library.sql`) — e.g., `[Attrition Rate]` in DAX should numerically match `Q-KPI-01`'s `AttritionRatePct` output for the same filter context. Discrepancies indicate either a DAX logic error or a SQL/DAX semantic mismatch (e.g., different NULL-handling) that must be reconciled before deployment.

---

*Document: PeoplePulse AI Advanced DAX Library v1.0*
*Prepared by: Power BI MVP Standard*
*Classification: Internal — BI Development Team*
