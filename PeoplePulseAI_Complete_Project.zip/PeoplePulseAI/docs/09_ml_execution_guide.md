# PeoplePulse AI — Machine Learning Execution Guide

Commands to train, persist, reload, and run inference with the attrition
prediction model from `ml_models/train_attrition_model.py`.

---

## 1. Train the Model (Full Pipeline)

```bash
python ml_models/train_attrition_model.py
```

This single command runs the entire Phase 8 pipeline: feature engineering
(21 engineered features), preprocessing (dual pipelines for tree vs. linear
models), training all 4 models (Logistic Regression, Random Forest, XGBoost
default, XGBoost GridSearchCV-tuned), SHAP explainability computation, and
percentile-based risk segmentation — then writes all output CSVs.

**Runtime:** 30–90 seconds depending on hardware (GridSearchCV with 36
parameter combinations × 5-fold CV is the slowest step).

---

## 2. Save the Model (Persist to Disk)

The base script trains in-memory and exports CSVs but does not persist the
fitted model object by default. To enable reload-without-retraining, add
this snippet (already included as `ml_models/save_model.py`):

```bash
python ml_models/save_model.py
```

This appends model serialization using `joblib`:
```python
import joblib
joblib.dump(xgb_tuned, "ml_models/artifacts/attrition_model.joblib")
joblib.dump(preprocessor_tree, "ml_models/artifacts/preprocessor.joblib")
```

**Expected output:**
```
✅ Model saved: ml_models/artifacts/attrition_model.joblib
✅ Preprocessor saved: ml_models/artifacts/preprocessor.joblib
```

---

## 3. Load a Saved Model

```bash
python -c "
import joblib
model = joblib.load('ml_models/artifacts/attrition_model.joblib')
preprocessor = joblib.load('ml_models/artifacts/preprocessor.joblib')
print('Model loaded:', type(model).__name__)
"
```

---

## 4. Score New/Updated Employee Data

```bash
python ml_models/score_employees.py --input data/PeoplePulse_HR_Dataset.csv \
                                     --output ml_models/attrition_predictions.csv
```

Use this when employee data has been updated (new hires, changed
engagement scores, etc.) and you want fresh risk scores WITHOUT
retraining the model from scratch — much faster (~5 seconds vs ~60 seconds).

**⚠️ Important schema difference:** `score_employees.py` produces a
LIGHTER output schema (`Employee_ID`, `Risk_Score`, `Risk_Tier`,
`Model_Probability` — no SHAP driver columns) because it skips the
expensive per-employee SHAP computation for speed. The full
`train_attrition_model.py` pipeline produces the COMPLETE schema
including `Top_3_Drivers` and `Recommended_Action`, which the Streamlit
app's Predictive Analytics page and `tests/test_model_validation.py`
expect. If you run `score_employees.py`, it will overwrite
`attrition_predictions.csv` with the lighter schema — re-run
`train_attrition_model.py` afterward to restore full SHAP explanations,
or point `score_employees.py`'s `--output` at a different filename
(e.g. `ml_models/quick_scores.csv`) to avoid overwriting the production file.

---

## 5. Generate Risk Predictions (Same as Step 1, Standalone)

If you only want the prediction CSVs without re-printing the full console
report:
```bash
python ml_models/train_attrition_model.py 2>/dev/null | tail -20
```

---

## 6. Export Prediction Results

Results are already exported as CSV by the main script. To export to other
formats:

**Excel:**
```bash
python -c "
import pandas as pd
df = pd.read_csv('ml_models/attrition_predictions.csv')
df.to_excel('ml_models/attrition_predictions.xlsx', index=False)
"
```

**Filtered to Critical tier only (for HRBP action list):**
```bash
python -c "
import pandas as pd
df = pd.read_csv('ml_models/active_employee_risk_list.csv')
critical = df[df['Risk_Tier'] == 'Critical']
critical.to_csv('ml_models/critical_risk_employees.csv', index=False)
print(f'{len(critical)} Critical-tier employees exported')
"
```

---

## 7. Validate Model Output

```bash
pytest tests/test_model_validation.py -v
```

This confirms (among other checks) the core calibration property: actual
attrition rate increases monotonically from Low → Medium → High → Critical
tiers. If this test fails after retraining, see the troubleshooting note
below.

---

## Expected Output Reference

After a successful run, you should see this validation table in the console:

```
RISK TIER VALIDATION (Predicted vs Actual):
          Count  AvgPredictedProb  ActualAttritionRate
RiskTier
Low        3810              12.1                  16.1
Medium     2667              28.4                  25.3
High        952              48.9                  35.4
Critical    191              71.2                  54.4
```

Exact numbers may vary ±2-3 points across reruns (model retraining
involves randomness in train/test split and cross-validation folds), but
the **monotonic increase** Low→Medium→High→Critical must always hold.

---

## Troubleshooting

| Issue | Cause | Fix |
|---|---|---|
| Risk tiers NOT monotonic after retraining | Fixed-threshold bug pattern (see `docs/12_career_assets.md` STAR Story 1) | Confirm `risk_tier()` function uses percentile thresholds (`np.percentile`), not hardcoded values like `>= 0.70` |
| `AUC` differs significantly from documented 0.601 | Different sklearn/xgboost version, or random_state not respected | Confirm `random_state=42` is set on ALL models and the train_test_split call |
| `shap.TreeExplainer` raises an error | SHAP version incompatible with installed XGBoost version | Pin versions per `requirements.txt`: `shap==0.45.0`, `xgboost==2.0.3` |
| GridSearchCV takes >5 minutes | Running on a low-core-count machine | Reduce `n_jobs=-1` parallelism is already maxed; alternatively shrink `param_grid` in the script |
| `ml_models/artifacts/` directory doesn't exist | Not created automatically | `mkdir -p ml_models/artifacts` before running `save_model.py` |
