# PeoplePulse AI — Streamlit Deployment Guide

Six deployment paths, from local development to enterprise cloud hosting.

---

## 1. Local Deployment

```bash
cd streamlit_app
pip install -r ../requirements.txt
streamlit run Home.py
```
Open `http://localhost:8501`. See `docs/07_local_installation_guide.md` for full environment setup if not already done.

---

## 2. Streamlit Community Cloud (Free, Fastest Path to a Public URL)

1. Push the repository to GitHub (public or private)
2. Go to [share.streamlit.io](https://share.streamlit.io) → **New app**
3. Select your repo, branch `main`, and set **Main file path** to `streamlit_app/Home.py`
4. Under **Advanced settings** → **Secrets**, paste (do NOT commit real secrets to the repo):
   ```toml
   DEMO_MODE = "true"
   ```
5. Click **Deploy**. Build takes 2-5 minutes.
6. Your app is live at `https://yourname-peoplepulse-ai.streamlit.app`

**Limitation:** Free tier apps sleep after inactivity and have 1GB RAM — fine for demos, not for production traffic.

---

## 3. Docker Deployment (Local or Any Container Host)

```bash
cd deployment/docker
docker compose up -d --build
```

This builds the app image (per `deployment/docker/Dockerfile`) and starts both the Streamlit app and a PostgreSQL database together. Open `http://localhost:8501`.

**To run the app container alone (without the DB, using CSV mode):**
```bash
docker build -f deployment/docker/Dockerfile -t peoplepulse-app .
docker run -p 8501:8501 -e DEMO_MODE=true peoplepulse-app
```

**Common errors:**
- `Cannot connect to the Docker daemon` — Docker Desktop isn't running; start it first.
- Build fails on `pyodbc` — ensure the Dockerfile's `apt-get install` step for `unixodbc-dev` completed (check build logs); this is already included in the provided Dockerfile.

---

## 4. Render Deployment

1. Push repo to GitHub
2. In the [Render Dashboard](https://dashboard.render.com) → **New** → **Web Service**
3. Connect your repo. Configure:
   - **Root Directory:** leave blank (repo root)
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `streamlit run streamlit_app/Home.py --server.port=$PORT --server.address=0.0.0.0`
4. Add environment variable: `DEMO_MODE=true`
5. Choose the **Free** or **Starter** instance plan → **Create Web Service**
6. Render auto-deploys on every push to `main`

**Common errors:**
- App crashes on start with `OSError: [Errno 98] Address already in use` — confirm the start command uses `$PORT` (Render assigns this dynamically), not a hardcoded `8501`.

---

## 5. AWS Deployment

### Option A — AWS App Runner (simplest managed option)
1. Push your Docker image to **Amazon ECR**:
   ```bash
   aws ecr create-repository --repository-name peoplepulse-app
   docker build -f deployment/docker/Dockerfile -t peoplepulse-app .
   docker tag peoplepulse-app:latest <account-id>.dkr.ecr.<region>.amazonaws.com/peoplepulse-app:latest
   aws ecr get-login-password | docker login --username AWS --password-stdin <account-id>.dkr.ecr.<region>.amazonaws.com
   docker push <account-id>.dkr.ecr.<region>.amazonaws.com/peoplepulse-app:latest
   ```
2. AWS Console → **App Runner** → **Create service** → source: the ECR image just pushed
3. Port: `8501`. Set environment variables (`DEMO_MODE=true`, or DB connection details if using RDS)
4. App Runner provisions a public HTTPS URL automatically with autoscaling

### Option B — ECS Fargate + RDS (full production architecture)
1. Provision an **RDS PostgreSQL** instance; deploy `sql/postgresql_schema.sql` against it; run `scripts/load_data.py` pointed at the RDS endpoint
2. Push the Docker image to ECR (as above)
3. Create an **ECS Fargate** service referencing the image, behind an **Application Load Balancer**
4. Set task environment variables to point `DB_HOST` at the RDS endpoint, `DEMO_MODE=false`
5. Configure the ALB security group to allow inbound 443 (HTTPS via ACM certificate) and the ECS task security group to allow inbound 8501 from the ALB only

**Common errors:**
- ECS task fails health check — confirm the Dockerfile's `HEALTHCHECK` path `/_stcore/health` is reachable; check ALB target group health check path is also set to `/_stcore/health`, not `/`.
- RDS connection timeout — confirm the ECS task's security group is allowed in the RDS security group's inbound rules.

---

## 6. Azure Deployment

### Option A — Azure App Service (Container)
1. Push the Docker image to **Azure Container Registry**:
   ```bash
   az acr create --name peoplepulseacr --resource-group myRG --sku Basic
   az acr login --name peoplepulseacr
   docker build -f deployment/docker/Dockerfile -t peoplepulseacr.azurecr.io/peoplepulse-app:latest .
   docker push peoplepulseacr.azurecr.io/peoplepulse-app:latest
   ```
2. **Create a Web App** → Publish: **Container** → Image source: Azure Container Registry → select the pushed image
3. **Configuration** → **Application settings** → add `WEBSITES_PORT=8501` and `DEMO_MODE=true`
4. **Configuration** → **General settings** → confirm "Always On" is enabled (prevents the app from sleeping)

### Option B — Azure SQL + App Service (full production)
1. Provision an **Azure SQL Database**; deploy `sql/03_sql_library.sql` (the native T-SQL schema) via Azure Data Studio or `sqlcmd`
2. Run `scripts/load_data.py` with `.env` configured for `DB_ENGINE=mssql` pointed at the Azure SQL connection string
3. Deploy the App Service container as in Option A, with `DB_HOST`/`DB_*` environment variables pointing at the Azure SQL server
4. Use **Azure AD authentication** for the SQL connection in production (more secure than SQL auth) — requires adjusting `pyodbc` connection string to use `Authentication=ActiveDirectoryMsi`

**Common errors:**
- `ODBC Driver 18 for SQL Server not found` inside the container — confirm the Dockerfile installs `unixodbc-dev` AND the Microsoft ODBC driver itself (the provided Dockerfile installs build dependencies; for full MSSQL support in the container, add Microsoft's apt repository and `msodbcsql18` package — see Microsoft's official linux driver install docs).
- App Service shows "Application Error" — check **Log stream** in the Azure portal; almost always a missing environment variable or the container failing its health check within the startup time limit (`WEBSITES_CONTAINER_START_TIME_LIMIT` may need increasing for slower cold starts with the ML libraries).

---

## Deployment Comparison Summary

| Path | Cost | Setup Time | Best For |
|---|---|---|---|
| Local | Free | 5 min | Development |
| Streamlit Community Cloud | Free | 10 min | Portfolio demos |
| Docker (local) | Free | 10 min | Testing prod-like setup |
| Render | Free–$25/mo | 15 min | Small team / staging |
| AWS App Runner | ~$25-50/mo | 30 min | Managed production |
| AWS ECS+RDS | ~$100+/mo | 2-4 hrs | Enterprise production |
| Azure App Service | ~$25-75/mo | 30-60 min | Microsoft-shop enterprises |
