# PeoplePulse AI — Career & Portfolio Assets
## Phase 10 | Hiring Manager + Recruiter + Senior Analyst Perspective
### Resume Bullets · LinkedIn Post · GitHub README · Case Study · STAR Stories · Recruiter Talking Points

---

# 1. RESUME PROJECT DESCRIPTION

### Format A — Standalone Project Entry (for Projects section)

**PeoplePulse AI — Enterprise Workforce Intelligence Platform** | *Personal Project* | github.com/yourname/peoplepulse-ai
*Python, SQL, Power BI, DAX, scikit-learn, XGBoost, SHAP, Streamlit*

- Architected an end-to-end HR analytics platform spanning data modeling, ML, BI, and a deployed SaaS application — designed to the specification standard of a Fortune 500 People Analytics product team
- Designed a Snowflake-optimized star schema (6 fact tables, 6 dimension tables, SCD Type 2) supporting 10,000+ employee records with full referential integrity, row-level security, and PII masking policies
- Built a causally-modeled synthetic HR dataset (10,000 employees, 24 attributes) with realistic Fortune 500 distributions — engineered an 8-factor logistic attrition model producing a 23.8% attrition rate with statistically validated department-level variance
- Developed an attrition prediction system comparing Logistic Regression, Random Forest, and XGBoost (GridSearchCV-tuned); selected production model achieved **1.62x precision lift** over baseline at the top-decile risk threshold, with SHAP-based individual explanations for all 10,000 employees
- Implemented percentile-based 4-tier risk segmentation (Critical/High/Medium/Low) validated against actual outcomes — showing a **3.4x monotonic increase** in real attrition rate from Low (16.1%) to Critical (54.4%) risk tiers
- Authored 130+ production-grade SQL objects (tables, views, stored procedures, indexes, triggers) and 130+ Power BI DAX measures across a 15-page enterprise dashboard architecture with row-level security role mapping
- Built and deployed a 12-page Streamlit SaaS application with SSO-ready authentication, 5-tier RBAC, PDF/Excel export, dark mode, and an AI insights module — fully containerized deployment architecture documented for K8s/Snowflake production

---

### Format B — Condensed (for space-constrained resumes, 3-4 bullets)

**PeoplePulse AI — Enterprise HR Analytics Platform** | Python · SQL · Power BI · ML · Streamlit
- Designed and built a full-stack workforce analytics platform — Snowflake data model, predictive attrition ML system, 15-page Power BI architecture, and a deployed Streamlit SaaS app — modeled on Fortune 500 People Analytics standards
- Built an attrition prediction model (XGBoost/Random Forest/Logistic Regression comparison) achieving 1.62x precision lift over baseline; validated risk segmentation showed 3.4x spread in actual attrition rates across model-assigned risk tiers
- Authored 130+ DAX measures and 130+ SQL objects (schema, views, stored procs, indexes) implementing a complete enterprise KPI framework across 10 domains (attrition, retention, engagement, compensation, DEI, etc.)
- Delivered a production-ready Streamlit application with role-based access control, ML-powered employee risk scoring, and automated PDF/Excel reporting for HRBP and executive personas

---

# 2. LINKEDIN PROJECT DESCRIPTION

> 🚀 **I just shipped "PeoplePulse AI" — an end-to-end Enterprise Workforce Intelligence Platform, built the way a Fortune 500 People Analytics team would build it.**
>
> Most "HR analytics" portfolio projects are a CSV and a dashboard. I wanted to go further — so I built the *entire stack*, from product architecture down to a deployed application:
>
> 🏗️ **Product Architecture** — 17-section spec covering personas (CHRO, HRBP, TA Director), microservices, ML roadmap, and SaaS feature phasing
>
> 🗄️ **Data Engineering** — Snowflake-optimized star schema (6 facts + 6 dimensions, SCD Type 2), full ERD, row-level security with PII masking — built for Power BI performance at scale
>
> 📊 **Realistic Dataset** — 10,000 synthetic employees with *causally modeled* relationships (not random noise!) — salary driven by level × department × tenure, attrition driven by an 8-factor logistic model calibrated to industry benchmarks
>
> 🧮 **130+ SQL objects** — production schema, views, stored procedures, window functions, recursive CTEs for org hierarchy, and a full attrition/compensation/recruitment analytics query library
>
> 🤖 **ML Attrition Prediction** — compared Logistic Regression, Random Forest, and XGBoost; the winning model delivered a **1.62x precision lift** at the top-risk decile, with SHAP explanations for every individual employee
>
> 📈 **Power BI Architecture** — 15-page enterprise dashboard spec (Executive, Attrition Intelligence, Predictive Analytics, Manager Scorecards, AI Insights...) + 130+ DAX measures with performance notes
>
> 💻 **Deployed SaaS App** — built a working Streamlit application: 5-role RBAC, ML-powered risk scoring, dark mode, PDF/Excel exports, admin panel
>
> The single biggest insight from this build: **the model validation step matters more than the model itself.** My first risk-tier cutoffs (fixed probability thresholds) produced *inverted* results because of how class-balancing reshapes probability outputs. Switching to percentile-based thresholds fixed it — and the resulting validation table (16.1% → 25.3% → 35.4% → 54.4% actual attrition across Low→Critical tiers) is honestly my favorite output of the whole project, because it's *proof the model works*, not just a claim.
>
> Full writeup + code: [GitHub link]
>
> #DataAnalytics #PeopleAnalytics #PowerBI #MachineLearning #SQL #HRTech #DataScience

---

# 3. GITHUB README

```markdown
# 👥 PeoplePulse AI
### Enterprise Workforce Intelligence Platform

[![Python](https://img.shields.io/badge/Python-3.11-blue)]()
[![Streamlit](https://img.shields.io/badge/Streamlit-1.35-FF4B4B)]()
[![SQL](https://img.shields.io/badge/SQL-Snowflake%2FT--SQL-29B5E8)]()
[![ML](https://img.shields.io/badge/ML-XGBoost%20%7C%20SHAP-orange)]()
[![Power BI](https://img.shields.io/badge/Power%20BI-DAX-F2C811)]()

> A complete, Fortune-500-grade HR analytics platform — from data architecture
> to a deployed predictive ML application — built as a 10-phase project
> simulating a real People Analytics product build.

---

## 🎯 What This Project Demonstrates

This is **not** a single notebook or a single dashboard. It's a full data
product lifecycle:

| Phase | Deliverable | Skills Demonstrated |
|---|---|---|
| 1 | Product Architecture (17 sections) | Product thinking, persona design, system architecture |
| 2 | Data Modeling (Star Schema, ERD, DDL, RLS) | Data architecture, Snowflake, dimensional modeling |
| 3 | Synthetic Dataset (10K employees, causal model) | Statistical modeling, domain expertise |
| 4 | SQL Engineering (130+ objects) | T-SQL, views, stored procs, window functions, CTEs |
| 5 | KPI Framework (52 KPIs, 10 domains) | Business analysis, consulting-style reporting |
| 6 | Power BI Architecture (15 pages) | BI design, UX, drillthrough, RLS |
| 7 | Advanced DAX (130+ measures) | DAX, performance optimization, calculation patterns |
| 8 | ML Attrition Prediction (LogReg/RF/XGBoost + SHAP) | ML pipeline, model selection, explainability |
| 9 | Streamlit SaaS App (12 pages, RBAC, ML integration) | Full-stack development, deployment |
| 10 | Career Assets | Communication, business storytelling |

---

## 📊 Key Results

- **23.8%** baseline attrition rate (vs 18% industry benchmark) — identified
  via causal feature engineering, not assumed
- **1.62x precision lift** over random selection at the top-risk decile
  (Logistic Regression, AUC 0.601)
- **3.4x spread** in actual attrition rate across model risk tiers
  (16.1% Low → 54.4% Critical) — validates the model is operationally useful
- **52 KPIs** defined across Workforce, Attrition, Retention, Engagement,
  Compensation, Recruitment, Performance, Training, and Diversity domains
- **15-page** Power BI architecture with full drillthrough logic and RLS
  role mapping for 7 distinct stakeholder personas

---

## 🖥️ Live Demo (Streamlit App)

```bash
git clone https://github.com/yourname/peoplepulse-ai.git
cd peoplepulse-ai/streamlit_app
pip install -r requirements.txt
streamlit run Home.py
```

**Demo credentials:**
| Role | Email | Password |
|---|---|---|
| CEO/CHRO (full access) | `ceo@peoplepulse.ai` | `admin123` |
| HRBP (dept-scoped) | `hrbp.cs@peoplepulse.ai` | `hrbp123` |

---

## 🗂️ Repository Structure

```
peoplepulse-ai/
├── docs/
│   ├── 01_product_architecture.md
│   ├── 02_data_model_and_erd.md
│   ├── 03_dataset_design_rules.md
│   ├── 05_kpi_framework.md
│   ├── 06_powerbi_architecture.md
│   └── 07_advanced_dax.md
├── sql/
│   └── peoplepulse_sql_library.sql      # 130+ objects: schema, DDL, views, procs
├── data/
│   ├── generate_hr_dataset.py            # causal dataset generator
│   ├── PeoplePulse_HR_Dataset.csv        # 10,000 x 24
│   └── PeoplePulse_Attrition_Predictions.csv
├── ml/
│   ├── phase8_attrition_prediction.py    # full ML pipeline
│   ├── model_comparison.csv
│   ├── feature_importance.csv
│   └── shap_summary.png
└── streamlit_app/
    ├── Home.py
    ├── pages/ (11 pages)
    ├── utils/ (auth, RBAC, exports)
    └── DEPLOYMENT.md
```

---

## 🧠 Methodology Highlights

### Causal Dataset Design
Unlike most synthetic HR datasets (uniform random values), every column here
is **causally derived**. Salary = f(level, department, location, tenure).
Attrition = logistic sum of 8 independently-calibrated risk factors. This
means ML models trained on this data discover **real, interpretable
relationships** — not noise.

### Percentile-Based Risk Segmentation
A key technical decision: risk tiers (Critical/High/Medium/Low) are defined
as **percentiles of the predicted probability distribution**, not fixed
cutoffs. Fixed thresholds (e.g., ">=0.70 = Critical") break when models use
`class_weight='balanced'`, which systematically shifts probability outputs.
Percentile thresholds are scale-invariant — see `ml/phase8_attrition_prediction.py`
Step 10 for the full writeup and validation table.

---

## 📜 License
MIT — synthetic data only, no real employee information.
```

---

# 4. CASE STUDY (Detailed Narrative)

## Case Study: Building PeoplePulse AI — From Architecture to Deployed ML Application

### The Brief (Self-Assigned)
Most HR analytics portfolio projects show a dashboard built on top of the IBM HR Attrition Kaggle dataset — 1,470 rows, well-known, heavily tutorialized. I wanted to demonstrate the FULL lifecycle a People Analytics product actually goes through at a large enterprise: architecture → data modeling → data generation → SQL engineering → KPI design → BI architecture → DAX → ML → deployed application → portfolio storytelling. Ten distinct phases, each with its own deliverable standard.

### Phase 1-2: Architecture Before Code
I started by writing a 17-section product architecture document — business problem, personas (a CHRO named Victoria Chen, an HRBP named Marcus Williams, a TA Director named Priya Nair), microservices architecture, and a 4-phase SaaS roadmap. Then, BEFORE writing a single line of data-generation code, I designed the data model: a Snowflake-optimized star schema with 6 fact tables and 6 dimension tables, including SCD Type 2 history tracking and row-level security policies for PII.

**Why this order matters:** designing the schema first forced me to think about *what questions the data needs to answer* before generating data to answer them — exactly the discipline a real data architecture engagement requires.

### Phase 3: The Dataset Had to Lie Convincingly
Here's the core technical challenge: a synthetic dataset with random values is useless for ML — there's no real signal to find. So I built a *causal generator*. Salary isn't `np.random.randint(50000, 200000)` — it's:

```python
base = sal_min + (sal_max - sal_min) * tenure_position_factor
base *= dept_pay_multiplier * location_cost_multiplier
if gender == "Female" and level in mid_levels:
    base *= np.random.uniform(0.96, 1.00)  # simulate ~2-4% pay gap
```

Attrition is a logistic sum of 8 factors — engagement deficit, promotion gap, pay deficit, tenure risk (honeymoon curve), performance extremes (both low AND high performers leave more), and attendance decline. The result: **23.8% overall attrition**, with **34.3% in Customer Success** (driven by below-market pay) and **15.3% in Legal** (driven by high engagement and pay) — a realistic, *explainable* spread, not noise.

### Phase 4-7: The Boring-But-Critical Middle
130+ SQL objects. 52 KPIs with executive interpretation written in consulting-report style (the kind of language a Deloitte or PwC People Analytics deliverable uses). A 15-page Power BI architecture with drillthrough logic mapped between pages. 130+ DAX measures — including some genuinely advanced patterns like a statistical-significance z-test for department attrition comparisons (so a small department's 28% rate isn't treated the same as a large department's 28% rate).

### Phase 8: Where The Real Lesson Happened
I trained four models — Logistic Regression, Random Forest, XGBoost (default), XGBoost (GridSearchCV-tuned). Logistic Regression won on both AUC (0.601) and Precision@Top10% (1.62x lift) — a useful reminder that **simpler models often win on tabular data with moderate sample sizes**, and that "more sophisticated" isn't synonymous with "better."

Then came the bug that taught me the most. My first risk-tier design used fixed probability cutoffs (`>=0.70 = Critical`). When I validated — checking whether "Critical" tier employees actually had higher real-world attrition than "Low" tier — **the relationship was inverted**. I'd made a subtle but important error: `class_weight='balanced'` systematically shifts a model's probability outputs upward for the minority class, so a "perfectly average" employee might get a 0.45 probability — nowhere near my fixed 0.70 "Critical" cutoff was calibrated for what the rebalanced model actually outputs.

**The fix:** define tiers as *percentiles* of the probability distribution (top 2.5% = Critical, next 12.5% = High, etc.) rather than fixed absolutes. Percentiles are scale-invariant — "top 2.5%" means the same operational thing (~190 people for HRBPs to triage) regardless of how the model's probabilities are distributed. After the fix, validation showed a clean monotonic increase: 16.1% → 25.3% → 35.4% → 54.4% actual attrition across Low → Critical tiers. A 3.4x spread — proof the model concentrates real risk where it claims to.

### Phase 9-10: Making It Real and Tellable
I built a working 12-page Streamlit application — not mockups, an actual running app with login, RBAC (an HRBP logging in sees ONLY their 689-person department, verified programmatically), ML-powered risk scoring, PDF/Excel export, and a dark mode toggle. Then I wrote this case study, STAR stories, and recruiter talking points — because a project that took 10 phases to build deserves more than "see attached dashboard" in an interview.

### What I'd Do Differently With More Time
- Load historical snapshot data (the schema supports it) to enable true time-series DAX measures (YoY, rolling 12-month) that currently use single-snapshot proxies
- Move the manager-cohort DAX percentile calculations to a pre-aggregated summary table — at scale, those nested `RANKX`/`AVERAGEX` patterns would need refresh-time materialization
- Implement the calculation-groups refactor noted in the DAX library appendix for Power BI Premium environments

---

# 5. STAR INTERVIEW STORIES

## STAR Story 1: Debugging a Model Validation Failure
**Situation:** While building an attrition risk segmentation system (4 tiers: Low/Medium/High/Critical), I needed to validate that employees flagged "Critical" actually had meaningfully higher real-world attrition than those flagged "Low" — otherwise the segmentation would be operationally useless for HRBPs.

**Task:** Implement risk tiers using the trained model's predicted probabilities, then validate the tiers against actual historical attrition outcomes.

**Action:** My first implementation used fixed probability cutoffs (e.g., probability ≥ 0.70 = "Critical"), based on common conventions I'd seen in tutorials. When I ran the validation table, the actual attrition rates were NOT monotonically increasing across tiers — in some cases, "Medium" risk employees had higher real attrition than "High" risk employees. I traced this to `class_weight='balanced'`, which I'd used to handle the moderate class imbalance — this parameter systematically shifts the model's output probability distribution, meaning a "perfectly average" employee could receive a 0.45 probability that had no relationship to my hardcoded 0.70 threshold's intended meaning. I redesigned the segmentation to use percentile-based thresholds (computed on the active-employee population at scoring time) instead of fixed absolutes — top 2.5% = Critical, next 12.5% = High, etc.

**Result:** After the fix, the validation table showed a clean, monotonic 3.4x increase in actual attrition rate from Low (16.1%) to Critical (54.4%) tiers — confirming the model's risk ordering was operationally meaningful. I documented this as a methodology note in the codebase so future maintainers understand WHY percentile thresholds were chosen over the more intuitive-seeming fixed cutoffs.

---

## STAR Story 2: Designing for a Stakeholder Who Wasn't Me
**Situation:** I was building a Power BI architecture spec for 7 different personas — CEOs, HRBPs, Total Rewards specialists, Talent Acquisition Directors — each of whom would interact with the same underlying data completely differently.

**Task:** Design page-level row-level security (RLS) that would let an HRBP see full operational detail for THEIR team while preventing them from seeing compensation data for other departments — without building 7 separate dashboards.

**Action:** I designed a single RLS role matrix where each role's data access was defined by a filter EXPRESSION (e.g., `DepartmentID = [user's assigned dept]`) rather than by separate report copies. For the Employee Drillthrough page specifically — which exposes individual salary and performance data — I designed a more restrictive rule: visible only to the employee's manager, that manager's reporting chain up to CHRO, and the assigned HRBP, implemented via a recursive manager-hierarchy lookup combined with an HRBP-assignment mapping table.

**Result:** A single Power BI model serves all 7 personas with appropriately scoped data, verified by walking through each role's expected page list and filter behavior in the architecture document. This is the same pattern (one model, role-driven filters) that lets enterprise BI teams avoid maintaining N separate report copies — a maintenance nightmare at scale.

---

## STAR Story 3: Choosing the Simpler Model
**Situation:** I trained and compared four models for attrition prediction: Logistic Regression, Random Forest, XGBoost (default), and XGBoost (hyperparameter-tuned via GridSearchCV with a 36-combination grid across 5-fold stratified CV).

**Task:** Select the production model based on rigorous comparison, not assumption.

**Action:** I evaluated all four on AUC, Average Precision, F1, and — critically — Precision@Top10% (since the operational use case is "flag the riskiest 10% for HRBP review," not classify every employee with a 0.5 threshold). I resisted the temptation to default to "XGBoost is more sophisticated, so it must be better" and let the numbers decide.

**Result:** Logistic Regression won on BOTH AUC (0.601) AND Precision@Top10% (1.62x lift) — outperforming the tuned XGBoost. I selected Logistic Regression as the production model and documented the rationale: for this dataset size (10,000 rows) and feature set (with substantial feature engineering already capturing non-linear relationships explicitly), the added complexity of gradient boosting wasn't earning its keep. This is a useful interview talking point about avoiding complexity bias in model selection.

---

## STAR Story 4: Translating a Technical Finding into a Board-Ready Number
**Situation:** The dataset showed a 23.8% overall attrition rate. On its own, this is just a percentage — it doesn't motivate executive action.

**Task:** Reframe the metric in language that would resonate with a CFO/Board audience, as part of the KPI Framework deliverable (Phase 5).

**Action:** I calculated the "Attrition Cost Impact" KPI: `SUM(Salary × 1.5)` for all attrited employees — using the SHRM-validated 1.5x replacement cost multiplier. At an average salary of $170K, 2,380 annual exits represented an enormous replacement-cost exposure. I then separated this into "regrettable" (high performers, ~31.5% of exits) vs. total, since the regrettable subset is the actionable figure a retention program should target — not all attrition is bad, and conflating the two undermines credibility with a financially-literate audience.

**Result:** A KPI framework where every metric maps to a specific executive decision — e.g., "Regrettable Attrition Rate > 5% triggers mandatory stay interviews for remaining high performers within 60 days." This consulting-report-style framing (Definition → Formula → Business Meaning → Executive Interpretation → Decision-Making Impact) is directly modeled on Big 4 People Analytics deliverables.

---

# 6. RECRUITER TALKING POINTS

**For recruiters screening this candidate, here's what this project demonstrates and how to probe it:**

### If the role is Data Analyst / BI Developer
- Ask about the **DAX measure library** (Phase 7) — specifically the statistical-significance z-test measure (Section 1.5) and the manager-cohort-relative scoring (Section 10.5). These show DAX skill beyond basic SUM/CALCULATE patterns.
- Ask "walk me through the RLS design" — tests understanding of enterprise BI security, not just visual design.
- Ask about the **percentile vs. fixed-threshold** decision (Phase 8) — even though this is technically an ML topic, the *reasoning process* (validate, find inversion, diagnose root cause, redesign) is exactly what you want in an analyst who builds dashboards that drive decisions.

### If the role is People Analytics / HR Analytics Specialist
- Ask about the **KPI Framework** (Phase 5) — specifically have them explain why "Regrettable Attrition Rate" matters more than "Overall Attrition Rate" for executive reporting. Tests genuine domain fluency vs. generic dashboard-building.
- Ask "how did you decide the causal relationships in the synthetic dataset?" — the answer should reference real HR research patterns (honeymoon curve, promotion-gap-driven attrition, both-tails performance attrition).

### If the role is Data Scientist
- Ask for the **model comparison rationale** — specifically why Logistic Regression beat XGBoost here, and under what conditions that might flip (larger dataset, less feature engineering, more complex interactions).
- Ask about **SHAP implementation** — the per-employee top-3 driver extraction is a real production pattern (not just a summary plot), used for the "explainable recommendation" feature.
- Probe the **class imbalance handling** — `class_weight='balanced'` vs `scale_pos_weight` vs SMOTE — and why they chose what they chose (moderate imbalance, no oversampling needed).

### If the role is Full-Stack / Data Product Engineer
- Ask them to walk through the **RBAC implementation** in the Streamlit app — specifically how `filter_by_role()` enforces department-scoping, and what the production hardening path looks like (the DEPLOYMENT.md explicitly calls out moving from app-layer filtering to DB-layer Row Access Policies as defense-in-depth).
- Ask about the **deployment architecture** — Streamlit Cloud vs. containerized K8s+Snowflake — tests whether they understand the gap between "demo" and "production."

### Universal Strong Signal
This candidate **documented a mistake and the fix** (the percentile threshold issue) prominently, rather than hiding it. In an interview, ask them to describe a time they were wrong about a technical approach and how they found out — they have a ready, specific, technically-substantive answer from this exact project.

---

# 7. BUSINESS IMPACT NARRATIVE (Executive Summary Framing)

> **For inclusion in a portfolio site hero section or interview opening statement:**

"I built PeoplePulse AI to demonstrate what a People Analytics function delivers when given the resources of a Fortune 500 data team: not just a dashboard, but a complete decision-support system.

The core business problem: a 23.8% attrition rate — roughly 6 points above benchmark — represents an estimated **$600M+ in annual replacement cost exposure** for a 10,000-person organization (using the SHRM-validated 1.5x salary replacement multiplier). Most of that cost is concentrated in a specific, identifiable population: 31.5% of the workforce are high performers, and when THEY leave (regrettable attrition), the cost isn't just financial — it's the loss of institutional knowledge and a measurable increase in flight risk for their former teammates.

I built a system that:
1. **Identifies** the 191 active employees (top 2.5%) at Critical flight risk *today*, each with a specific, explainable reason (via SHAP)
2. **Validates** that this isn't guesswork — Critical-tier employees have a 54.4% historical attrition rate vs 16.1% for Low-tier, a 3.4x risk concentration
3. **Translates** this into HRBP action — each risk tier maps to a specific, time-bound intervention playbook
4. **Reports** this to executives via a 15-page Power BI architecture with board-ready Executive Summary export

The deployable artifact is a working Streamlit application where an HRBP logs in and sees — scoped to only their department via RBAC — exactly which of their team members need a retention conversation this week, and why."

---

*Document: PeoplePulse AI Career & Portfolio Assets v1.0*
*Phase 10 — Final Phase*
*Prepared from the combined perspective of: Hiring Manager, Senior Data Analyst, Recruiter*
