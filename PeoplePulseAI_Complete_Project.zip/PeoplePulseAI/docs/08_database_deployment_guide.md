# PeoplePulse AI — Database Deployment Guide

Covers full deployment instructions for all three supported database
engines. Pick ONE based on your environment; PostgreSQL is recommended
for local development (free, lightweight, used in `docker-compose.yml`).

---

## OPTION A — PostgreSQL (Recommended)

### 1. Database Creation
```bash
# macOS
brew install postgresql@16 && brew services start postgresql@16

# Ubuntu/Debian
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql

# Create database and application user
sudo -u postgres psql -c "CREATE DATABASE peoplepulse;"
sudo -u postgres psql -c "CREATE USER peoplepulse_app WITH PASSWORD 'changeme';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE peoplepulse TO peoplepulse_app;"
```

### 2. Schema Deployment
```bash
psql -h localhost -U peoplepulse_app -d peoplepulse -f sql/postgresql_schema.sql
```
This creates 3 schemas (`hr`, `rpt`, `audit`), all reference + core tables,
indexes, views, and seeds the 11 departments / 7 levels / 11 locations /
8 sources / 5 performance ratings.

### 3. Data Loading
```bash
# Generate the demo user password hashes and append to the schema first
python scripts/generate_password_hashes.py >> /tmp/hashes_output.txt
# (review /tmp/hashes_output.txt and run any additional INSERT statements
#  manually if you need non-CEO demo accounts in the DB-backed auth table)

python scripts/load_data.py --truncate
```

### 4. Validation
```bash
psql -h localhost -U peoplepulse_app -d peoplepulse -f sql/validation/run_validation.sql
```
Expected: row counts match documented values, 0 orphaned FKs, attrition
rate ≈ 23.8%, all views return data.

---

## OPTION B — MySQL

### 1. Database Creation
```bash
# macOS
brew install mysql && brew services start mysql

# Ubuntu/Debian
sudo apt install mysql-server
sudo systemctl start mysql

mysql -u root -p -e "CREATE DATABASE peoplepulse CHARACTER SET utf8mb4;"
mysql -u root -p -e "CREATE USER 'peoplepulse_app'@'localhost' IDENTIFIED BY 'changeme';"
mysql -u root -p -e "GRANT ALL PRIVILEGES ON peoplepulse.* TO 'peoplepulse_app'@'localhost';"
```

### 2. Schema Deployment
```bash
mysql -u peoplepulse_app -p peoplepulse < sql/mysql_schema.sql
```

### 3. Data Loading
Set `.env`: `DB_ENGINE=mysql`, then:
```bash
python scripts/load_data.py --truncate
```
**Note:** MySQL has no schema namespaces — the loader script auto-detects
`DB_ENGINE=mysql` and switches to prefixed table names (`hr_employee`
instead of `hr.employee`) via the `table_name()` helper in `scripts/load_data.py`.

### 4. Validation
```bash
mysql -u peoplepulse_app -p peoplepulse
```
Then run the queries in `sql/validation/run_validation.sql`, substituting
`hr.employee` → `hr_employee` (see the "MYSQL ADAPTATION NOTES" section at
the bottom of that file).

---

## OPTION C — SQL Server / Azure SQL

### 1. Database Creation
```sql
-- Connect via sqlcmd, Azure Data Studio, or SSMS
CREATE DATABASE PeoplePulseDB;
GO
```

### 2. Schema Deployment
```bash
sqlcmd -S localhost -d PeoplePulseDB -i sql/03_sql_library.sql
```
This is the original, most complete schema (includes stored procedures,
triggers, and the full analytical query library — Phase 4 deliverable).

### 3. Data Loading
The SQL library file includes a `BULK INSERT` script in its Section 15
that loads directly from the CSV (adjust the file path for your environment):
```sql
-- See sql/03_sql_library.sql, Section 15, for the full BULK INSERT script
```
Alternatively, set `.env` `DB_ENGINE=mssql` and run:
```bash
python scripts/load_data.py --truncate
```
**Requires:** the Microsoft ODBC Driver 18 for SQL Server installed
separately (not a Python package) — see
[Microsoft's driver download page](https://learn.microsoft.com/sql/connect/odbc/download-odbc-driver-for-sql-server).

### 4. Validation
Run the equivalent T-SQL validation queries (same logic as
`sql/validation/run_validation.sql`, adjusted for T-SQL syntax — e.g.
`TOP` instead of `LIMIT`, `GETDATE()` instead of `now()`).

---

## Common Errors (All Engines)

| Error | Cause | Fix |
|---|---|---|
| `relation/table "hr.ref_department" does not exist` | Schema script didn't fully run | Check for errors mid-script; re-run from a clean DB |
| `duplicate key value violates unique constraint` | Re-running data load without `--truncate` | Add `--truncate` flag, or manually clear tables first |
| `foreign key constraint fails` during load | Reference seed data missing or mismatched names | Confirm Department/Location/Source names in CSV exactly match `ref_*` seed values (case-sensitive) |
| Connection refused | DB service not running | `brew services start postgresql@16` / `sudo systemctl start postgresql` |
| `password authentication failed` | `.env` password doesn't match DB user | Re-run the `CREATE USER` / `ALTER USER ... PASSWORD` command to sync |
