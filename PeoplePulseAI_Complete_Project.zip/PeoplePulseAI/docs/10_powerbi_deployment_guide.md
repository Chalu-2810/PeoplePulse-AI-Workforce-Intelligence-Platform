# PeoplePulse AI — Power BI Deployment Guide

Covers connecting Power BI Desktop to the data, validating the model,
and publishing to the Power BI Service with scheduled refresh.

---

## 1. Dataset Connection Steps

### Option A — Connect to CSV files (fastest, no DB required)
1. Open Power BI Desktop → **Get Data** → **Text/CSV**
2. Select `data/PeoplePulse_HR_Dataset.csv` → **Load**
3. **Get Data** again → **Text/CSV** → select `ml_models/attrition_predictions.csv` → **Load**
4. (Optional) Repeat for `ml_models/feature_importance.csv` and `ml_models/model_comparison.csv` if building the Predictive Analytics / AI Insights pages

### Option B — Connect to a live database (Postgres/MySQL/SQL Server)
1. **Get Data** → search for your engine (e.g. "PostgreSQL database")
2. Server: `localhost` (or your host), Database: `peoplepulse`
3. Choose **Import** mode (not DirectQuery) for datasets under ~1M rows — better performance for this scale
4. Select tables/views: `rpt.vw_employee_full`, `rpt.vw_department_kpis`, `rpt.vw_pay_equity`, `hr.flight_risk_score`
5. Enter credentials matching your `.env` `DB_USER`/`DB_PASSWORD`

---

## 2. Relationship Validation

After loading both tables, go to **Model view**:

1. Confirm Power BI auto-detected a relationship between `HR_Data[Employee_ID]` and `Predictions[Employee_ID]`. If not, drag-and-drop to create one manually.
2. Set cardinality to **One-to-One** (each employee has exactly one current risk score) and cross-filter direction to **Both** (allows filtering predictions by HR_Data attributes and vice versa).
3. **Validation check:** Click the relationship line — Power BI shows a tooltip confirming cardinality. If it shows "Many-to-many," your `Employee_ID` join key likely has duplicates in one of the source files — re-check `ml_models/attrition_predictions.csv` for duplicate rows (`SELECT Employee_ID, COUNT(*) FROM Predictions GROUP BY Employee_ID HAVING COUNT(*) > 1` equivalent in Power Query).

---

## 3. Loading the DAX Measures

1. In **Report view**, right-click the `HR_Data` table → **New Measure**
2. Open `powerbi/dax_measures_phase4.dax` and `docs/06_advanced_dax.md` side-by-side
3. Copy each measure's DAX code block and paste into the formula bar one at a time (Power BI does not support bulk-pasting multiple measures in Desktop — each needs its own New Measure action)
4. **Recommended:** create a dedicated empty table named `_Measures` (Modeling → New Table → `_Measures = ROW("placeholder", 0)`) and organize all measures under it via **Home Table** property, rather than scattering them across `HR_Data`/`Predictions` — keeps the field list clean

---

## 4. Measure Validation

For each measure, validate against the SQL ground truth before building visuals on top of it:

| DAX Measure | Validate Against | Expected Match |
|---|---|---|
| `[Attrition Rate]` | `sql/validation/run_validation.sql` Query #5 | ≈ 23.8% |
| `[Avg Engagement Score]` | Same query | ≈ 67.3 |
| `[Avg Salary]` | Same query | ≈ $169,953 |

**How to validate:** Add a Card visual showing `[Attrition Rate]` with no filters applied, then run the corresponding SQL query against your loaded database (or compute directly in Python: `df['Attrition'].eq('Yes').mean()`). The two numbers must match (within rounding) — if they don't, check for: (a) a stray filter on a report-level slicer, (b) the relationship cross-filter direction silently restricting rows, or (c) a typo in the DAX `CALCULATE` filter argument.

---

## 5. Building the 15 Report Pages

Follow `docs/05_powerbi_architecture.md` page-by-page. Each page section specifies the exact visuals, layout, and DAX measures needed. Recommended build order (simplest → most complex, building shared visual literacy as you go):

1. Page 1 (Executive Overview) — establishes the KPI card template reused everywhere
2. Page 11 (Department Insights) — establishes the drillthrough pattern
3. Page 3 (Attrition Intelligence) — most measure-dense page, good stress test
4. Pages 2, 4, 5, 6, 7, 8, 9 (domain pages) — can be built in parallel/any order
5. Page 12 (Manager Scorecard), Page 13 (Employee Drillthrough) — depend on Page 11's drillthrough pattern
6. Page 14 (AI Insights) — uses native Smart Narrative/Key Influencers visuals, no custom DAX needed
7. Page 15 (Executive Summary) — assembles cards from all prior pages, build last

---

## 6. Row-Level Security (RLS) Setup

1. **Modeling** tab → **Manage Roles** → **Create**
2. Create role `HRBP` with DAX filter on `HR_Data` table:
   ```dax
   [Department] = LOOKUPVALUE(UserDepartmentMapping[Department], UserDepartmentMapping[UserPrincipalName], USERPRINCIPALNAME())
   ```
   (Requires a small `UserDepartmentMapping` table — see `docs/06_advanced_dax.md` Section 11.5 for the full pattern)
3. Repeat for `HR Director`, `Total Rewards`, etc. per the role matrix in `docs/05_powerbi_architecture.md`
4. **Test:** Modeling → **View As** → select a role → confirm filtered data matches expectations before publishing

---

## 7. Publishing to Power BI Service

1. **Home** tab → **Publish** → sign in with your Power BI account → select target Workspace
2. Once published, open the report in [app.powerbi.com](https://app.powerbi.com)
3. Go to the **Dataset** settings (not the report) → confirm it shows "Last Refreshed" with today's date

---

## 8. Scheduled Refresh Configuration

**If using CSV files (Option A):** Scheduled refresh requires either (a) the **On-premises Data Gateway** installed on a machine with access to the CSV file path, or (b) moving the files to OneDrive/SharePoint and connecting via that connector instead of a local file path (Power BI Service cannot directly re-read a local filesystem path on a schedule).

**If using a live database (Option B):**
1. Dataset Settings → **Gateway connection** → install/configure the **On-premises Data Gateway** if the DB isn't cloud-hosted
2. **Scheduled refresh** → toggle **On**
3. Set frequency (e.g., Daily) and time (e.g., 6:00 AM, after the nightly `score_employees.py` cron job — see below — has updated risk scores)
4. Add a failure notification email under **Refresh failure notifications**

**Recommended automation pairing:** schedule `python ml_models/score_employees.py` via cron/Task Scheduler to run nightly BEFORE the Power BI scheduled refresh, so the dashboard always reflects the latest risk scores:
```cron
# crontab entry: re-score employees nightly at 5:00 AM, before 6:00 AM PBI refresh
0 5 * * * cd /path/to/PeoplePulseAI && /path/to/venv/bin/python ml_models/score_employees.py --output ml_models/attrition_predictions.csv
```

---

## 9. Publishing Validation Checklist

Before sharing the published report with stakeholders:
- [ ] Every KPI card matches its SQL ground-truth value (Step 4)
- [ ] RLS roles tested via "View As" for each role
- [ ] Drillthrough works: right-click a department bar → confirm it navigates to Department Insights filtered correctly
- [ ] Mobile layout configured (View → Mobile Layout) for at least the Executive Overview page
- [ ] Scheduled refresh history shows at least one successful run
- [ ] Dataset is shared with the correct Workspace audience (Viewer vs. Contributor permissions per role)
