# PeoplePulse AI — Enterprise Data Model
## Phase 2: Data Engineering & Data Modeling
### Senior Data Architect Design | Snowflake-Optimized | Power BI Ready
---

## ARCHITECTURE DECISION: WHY STAR SCHEMA + SELECTIVE SNOWFLAKING

### Schema Strategy
The PeoplePulse data warehouse uses a **Hybrid Star/Snowflake schema**:
- Core fact-to-dimension joins use **Star Schema** (denormalized dimensions) for maximum Power BI query performance
- High-cardinality sub-dimensions (Geography → City → Country, Role → Job Family → Job Level) use **Snowflake Schema** to eliminate dimension update anomalies
- All aggregation tables are pre-computed in dbt Gold layer for sub-second dashboard response

### Why Not Pure 3NF?
Third normal form (3NF/OLTP) is designed to eliminate redundancy for transactional write performance. HR analytics is read-heavy — thousands of simultaneous Power BI queries hitting the same dimension tables. Joining 12 normalized tables for a single attrition metric is 10× slower than reading a 40-column denormalized dimension. The warehouse is a reporting system, not a transaction system.

### Power BI Optimization Decisions
1. **Single-column integer surrogate keys** on all dimensions → Power BI loads faster than GUIDs
2. **Slowly Changing Dimension Type 2 (SCD2)** on Dim_Employee, Dim_Role, Dim_Compensation → preserves history for point-in-time analysis
3. **Date dimension as 10-year calendar** pre-populated → eliminates DATEADD calculations in DAX
4. **All FK-PK relationships exposed in Snowflake** → Power BI relationship view auto-detects them
5. **Numeric measures stored as DECIMAL(18,4)** not FLOAT → avoids floating-point rounding in salary calculations

---

## FACT TABLES

---

### FACT_EMPLOYEE_SNAPSHOT
**Purpose:** The master grain fact table. One row per employee per month-end snapshot date. This is the foundation for all headcount, attrition, and workforce composition analysis. Using a periodic snapshot (rather than a transaction table) means Power BI can answer "how many employees did we have on March 31?" without complex window functions — it's a simple COUNT.

**Enterprise Reasoning:** CHROs and CFOs need point-in-time headcount for budgeting. Salary planning cycles compare "headcount today" vs. "headcount last quarter." An accumulating snapshot fact fails here because employees can change status multiple times. A monthly snapshot is the right grain.

**Grain:** One row per (Employee × Month-End Date)

| Column | Data Type | Constraint | Description |
|--------|-----------|-----------|-------------|
| employee_snapshot_key | BIGINT | PK, NOT NULL | Surrogate primary key (auto-increment) |
| employee_key | INT | FK → Dim_Employee, NOT NULL | Links to current employee dimension row |
| employee_id | VARCHAR(20) | NOT NULL | Natural key from source HRIS |
| date_key | INT | FK → Dim_Date, NOT NULL | Snapshot date (always month-end) |
| department_key | INT | FK → Dim_Department, NOT NULL | Department at time of snapshot |
| location_key | INT | FK → Dim_Location, NOT NULL | Work location at time of snapshot |
| manager_key | INT | FK → Dim_Manager, NULL | Direct manager (NULL = no manager / CEO) |
| role_key | INT | FK → Dim_Role, NOT NULL | Role/job code at time of snapshot |
| employment_status_code | VARCHAR(20) | NOT NULL | Active / LOA / PIP / Notice / Terminated |
| employment_type_code | VARCHAR(20) | NOT NULL | Full-Time / Part-Time / Contract / Intern |
| fte_value | DECIMAL(5,2) | NOT NULL | Full-time equivalent (1.0 = full-time) |
| tenure_months | INT | NOT NULL | Months since hire date at snapshot |
| tenure_band_code | VARCHAR(20) | NOT NULL | <6m / 6-12m / 1-2y / 2-5y / 5-10y / 10y+ |
| is_active_flag | BOOLEAN | NOT NULL | TRUE = counted in active headcount |
| is_regrettable_exit_flag | BOOLEAN | NULL | Populated if termination row |
| voluntary_exit_flag | BOOLEAN | NULL | Populated if termination row |
| exit_reason_code | VARCHAR(50) | NULL | Resignation / Layoff / Performance / etc |
| compa_ratio | DECIMAL(6,4) | NULL | Base salary ÷ midpoint of pay range |
| total_comp_usd | DECIMAL(18,2) | NULL | Total compensation annualized (USD normalized) |
| performance_rating_code | VARCHAR(20) | NULL | Most recent perf rating at snapshot |
| flight_risk_score | DECIMAL(5,2) | NULL | ML model score 0-100 (updated weekly) |
| engagement_score | DECIMAL(5,2) | NULL | Most recent survey score 0-100 |
| created_at | TIMESTAMP_NTZ | NOT NULL | ETL load timestamp |
| updated_at | TIMESTAMP_NTZ | NOT NULL | Last update timestamp |

**Indexes / Clustering:** CLUSTER BY (date_key, department_key) in Snowflake
**Power BI Measure Examples:** COUNTROWS (headcount), CALCULATE(COUNTROWS, is_active=TRUE) (active headcount), AVERAGEX (avg compa-ratio)

---

### FACT_ATTENDANCE
**Purpose:** Daily attendance records at employee-day grain. Captures presence, absence types, late arrivals, and leave utilization. This table is the source for burnout risk modeling (consecutive late arrivals + high absence frequency), FMLA tracking, and workforce availability planning.

**Enterprise Reasoning:** Absence analytics are a leading indicator for engagement collapse. Research shows employees who miss 3+ unplanned days in 90 days are 2.4× more likely to resign within 6 months. Without this fact table, that correlation is invisible.

**Grain:** One row per (Employee × Work Day)

| Column | Data Type | Constraint | Description |
|--------|-----------|-----------|-------------|
| attendance_key | BIGINT | PK, NOT NULL | Surrogate primary key |
| employee_key | INT | FK → Dim_Employee, NOT NULL | Employee dimension link |
| date_key | INT | FK → Dim_Date, NOT NULL | Work day date |
| department_key | INT | FK → Dim_Department, NOT NULL | Department at time of record |
| location_key | INT | FK → Dim_Location, NOT NULL | Expected work location |
| attendance_status_code | VARCHAR(30) | NOT NULL | Present / Absent-Excused / Absent-Unexcused / Late / WFH / Leave |
| leave_type_code | VARCHAR(30) | NULL | Annual / Sick / FMLA / Parental / Bereavement / Unpaid |
| leave_plan_key | INT | NULL | FK → Dim_Leave_Plan |
| hours_scheduled | DECIMAL(5,2) | NOT NULL | Hours expected per schedule |
| hours_worked | DECIMAL(5,2) | NOT NULL | Actual hours recorded (0 if absent) |
| hours_overtime | DECIMAL(5,2) | NOT NULL | Hours beyond standard (default 0) |
| hours_leave_taken | DECIMAL(5,2) | NOT NULL | Leave hours consumed |
| hours_leave_balance | DECIMAL(8,2) | NULL | Remaining balance at day-end |
| late_arrival_minutes | INT | NOT NULL | Minutes late (0 if on-time) |
| early_departure_minutes | INT | NOT NULL | Minutes left early (0 if full day) |
| is_holiday_flag | BOOLEAN | NOT NULL | TRUE if company/statutory holiday |
| is_weekend_flag | BOOLEAN | NOT NULL | TRUE if Sat/Sun |
| unplanned_absence_flag | BOOLEAN | NOT NULL | TRUE if same-day or no-notice |
| created_at | TIMESTAMP_NTZ | NOT NULL | ETL load timestamp |

**Indexes / Clustering:** CLUSTER BY (date_key, employee_key)
**Power BI Measure Examples:** Absence Rate = DIVIDE(absence_days, scheduled_days), Unplanned Absence Rate, Leave Balance Utilization

---

### FACT_PERFORMANCE
**Purpose:** Records performance evaluation outcomes at the employee-review-cycle grain. Stores both numerical ratings and categorical outcomes (meets/exceeds/PIP). This fact table is critical for: flight risk modeling (performance decline pattern), HIPO identification, promotion readiness scoring, and legal defensibility of termination decisions.

**Enterprise Reasoning:** Performance data joined to compensation data reveals pay-for-performance alignment. Joined to attrition data, it reveals whether high performers are leaving at disproportionate rates (regrettable attrition). Without this table, those questions are unanswerable. Grain is review-cycle not calendar year because companies run mid-year, annual, and project-based reviews simultaneously.

**Grain:** One row per (Employee × Review Cycle × Review Type)

| Column | Data Type | Constraint | Description |
|--------|-----------|-----------|-------------|
| performance_key | BIGINT | PK, NOT NULL | Surrogate primary key |
| employee_key | INT | FK → Dim_Employee, NOT NULL | Employee dimension link |
| manager_key | INT | FK → Dim_Manager, NOT NULL | Reviewing manager |
| review_date_key | INT | FK → Dim_Date, NOT NULL | Date review was finalized |
| department_key | INT | FK → Dim_Department, NOT NULL | Department at time of review |
| role_key | INT | FK → Dim_Role, NOT NULL | Role at time of review |
| review_cycle_code | VARCHAR(30) | NOT NULL | Annual-2024 / Mid-Year-2024 / Project-Q3 |
| review_type_code | VARCHAR(30) | NOT NULL | Manager-Review / Peer-360 / Self-Assessment / Calibration |
| rating_numeric | DECIMAL(4,2) | NOT NULL | Raw numeric score (e.g. 1.0–5.0) |
| rating_label_code | VARCHAR(30) | NOT NULL | Distinguished / Exceeds / Meets / Below / Unacceptable |
| rating_normalized | DECIMAL(5,4) | NOT NULL | Score normalized 0–1.0 for cross-cycle comparison |
| goal_achievement_pct | DECIMAL(5,2) | NULL | % of goals marked complete |
| goals_set_count | INT | NULL | Number of goals defined |
| goals_achieved_count | INT | NULL | Number of goals achieved |
| competency_score_avg | DECIMAL(4,2) | NULL | Average across competency dimensions |
| leadership_score | DECIMAL(4,2) | NULL | Leadership competency (NULL for IC roles) |
| innovation_score | DECIMAL(4,2) | NULL | Innovation/problem-solving competency |
| collaboration_score | DECIMAL(4,2) | NULL | Collaboration/teamwork competency |
| execution_score | DECIMAL(4,2) | NULL | Delivery/execution competency |
| potential_rating_code | VARCHAR(20) | NULL | High / Medium / Standard (HIPO assessment) |
| pip_flag | BOOLEAN | NOT NULL | TRUE = on Performance Improvement Plan |
| calibration_adjusted_flag | BOOLEAN | NOT NULL | TRUE = rating changed during calibration |
| calibration_delta | DECIMAL(4,2) | NULL | Rating change (positive = upgraded) |
| created_at | TIMESTAMP_NTZ | NOT NULL | ETL load timestamp |

**Indexes / Clustering:** CLUSTER BY (review_date_key, department_key)
**Power BI Measure Examples:** % High Performers by department, Rating Distribution histogram, Manager calibration consistency score

---

### FACT_RECRUITMENT
**Purpose:** Accumulating snapshot fact tracking each job requisition from open to filled/cancelled. One row per (Requisition × Candidate × Stage). This supports the full talent acquisition analytics suite: source effectiveness, time-to-fill, offer acceptance rate, and quality-of-hire (by linking back to FACT_PERFORMANCE 12 months post-hire).

**Enterprise Reasoning:** Talent acquisition is the most expensive HR process — a bad hire at Director level costs 2–3× annual salary. Without this table joined to FACT_PERFORMANCE, you cannot calculate quality-of-hire by source, recruiter, or hiring manager. This is the table that lets a TA Director say "LinkedIn employee referrals produce employees 40% more likely to exceed expectations at 12 months."

**Grain:** One row per (Candidate Application × Pipeline Stage Transition)

| Column | Data Type | Constraint | Description |
|--------|-----------|-----------|-------------|
| recruitment_key | BIGINT | PK, NOT NULL | Surrogate primary key |
| requisition_id | VARCHAR(30) | NOT NULL | Natural key from ATS |
| candidate_id | VARCHAR(30) | NOT NULL | Natural key from ATS |
| employee_key | INT | FK → Dim_Employee, NULL | Populated when candidate becomes employee |
| department_key | INT | FK → Dim_Department, NOT NULL | Hiring department |
| location_key | INT | FK → Dim_Location, NOT NULL | Role location |
| role_key | INT | FK → Dim_Role, NOT NULL | Role being filled |
| manager_key | INT | FK → Dim_Manager, NOT NULL | Hiring manager |
| recruiter_employee_key | INT | FK → Dim_Employee, NOT NULL | Assigned recruiter |
| open_date_key | INT | FK → Dim_Date, NOT NULL | Req opened date |
| close_date_key | INT | FK → Dim_Date, NULL | Req closed/filled date |
| application_date_key | INT | FK → Dim_Date, NOT NULL | Candidate applied date |
| stage_entry_date_key | INT | FK → Dim_Date, NOT NULL | Date entered current stage |
| stage_exit_date_key | INT | FK → Dim_Date, NULL | Date exited current stage (NULL = in-stage) |
| hire_date_key | INT | FK → Dim_Date, NULL | Official hire/start date |
| source_channel_code | VARCHAR(50) | NOT NULL | LinkedIn / Referral / Indeed / Agency / Career-Site |
| source_subchannel | VARCHAR(100) | NULL | Specific job board post, referrer name, agency name |
| pipeline_stage_code | VARCHAR(30) | NOT NULL | Applied / Screen / Phone / Onsite / Offer / Hired / Rejected |
| rejection_reason_code | VARCHAR(50) | NULL | Withdrew / Failed-Assessment / No-Offer / Declined-Offer |
| offer_amount_usd | DECIMAL(18,2) | NULL | Offered base salary (USD) |
| offer_accepted_flag | BOOLEAN | NULL | NULL until offer stage |
| days_to_fill | INT | NULL | Calendar days from open to hire |
| days_in_stage | INT | NOT NULL | Days spent in current/last stage |
| interview_count | INT | NOT NULL | Total interviews conducted |
| interview_score_avg | DECIMAL(4,2) | NULL | Average interview scorecard rating |
| candidate_nps_score | INT | NULL | Candidate experience NPS (-100 to 100) |
| req_priority_code | VARCHAR(20) | NOT NULL | Critical / High / Standard |
| req_type_code | VARCHAR(20) | NOT NULL | Backfill / New-Headcount / Replacement |
| is_diversity_hire_flag | BOOLEAN | NULL | Per company DEI definitions |
| created_at | TIMESTAMP_NTZ | NOT NULL | ETL load timestamp |

**Indexes / Clustering:** CLUSTER BY (open_date_key, department_key)
**Power BI Measure Examples:** Time-to-Fill (avg days_to_fill), Offer Acceptance Rate, Source-of-Hire breakdown, Pipeline conversion funnel by stage

---

### FACT_COMPENSATION
**Purpose:** Records every compensation change event at the employee-event grain. Includes base salary changes, bonus payouts, equity grants, and benefits cost. This is NOT a snapshot table — it captures the history of every change event, enabling trend analysis, promotion uplift calculations, and pay equity residual modeling.

**Enterprise Reasoning:** Annual salary survey is insufficient for a 45,000-person global organization. Pay equity gaps emerge in real-time — through merit cycles, off-cycle adjustments, and role reclassifications. An event-driven compensation fact table is the only way to detect "we approved 23 off-cycle increases this quarter, 87% went to men" before it becomes a lawsuit. The compa_ratio field here is the input for the ML Pay Equity Anomaly Detector.

**Grain:** One row per (Employee × Compensation Change Event)

| Column | Data Type | Constraint | Description |
|--------|-----------|-----------|-------------|
| compensation_key | BIGINT | PK, NOT NULL | Surrogate primary key |
| employee_key | INT | FK → Dim_Employee, NOT NULL | Employee dimension link |
| effective_date_key | INT | FK → Dim_Date, NOT NULL | Date change became effective |
| end_date_key | INT | FK → Dim_Date, NULL | Date change superseded (NULL = current) |
| department_key | INT | FK → Dim_Department, NOT NULL | Department at time of change |
| role_key | INT | FK → Dim_Role, NOT NULL | Role at time of change |
| location_key | INT | FK → Dim_Location, NOT NULL | Location (for geo-differential) |
| manager_key | INT | FK → Dim_Manager, NULL | Approving manager |
| change_type_code | VARCHAR(30) | NOT NULL | Hire / Merit / Promotion / Market-Adj / Equity-Correction / Off-Cycle |
| change_reason_code | VARCHAR(50) | NULL | Free-text reason category |
| base_salary_new_usd | DECIMAL(18,2) | NOT NULL | New base salary (USD normalized) |
| base_salary_prev_usd | DECIMAL(18,2) | NULL | Previous base (NULL for new hire) |
| base_salary_change_usd | DECIMAL(18,2) | NULL | Absolute change |
| base_salary_change_pct | DECIMAL(7,4) | NULL | Percentage change |
| local_currency_code | CHAR(3) | NOT NULL | ISO 4217 (USD, EUR, GBP, INR, etc.) |
| base_salary_local | DECIMAL(18,2) | NOT NULL | Salary in local currency |
| target_bonus_pct | DECIMAL(5,2) | NULL | Target bonus as % of base |
| target_bonus_usd | DECIMAL(18,2) | NULL | Target bonus USD |
| actual_bonus_usd | DECIMAL(18,2) | NULL | Actual bonus paid (after payout event) |
| equity_grant_usd | DECIMAL(18,2) | NULL | Value of equity granted |
| equity_grant_shares | INT | NULL | Number of shares/RSUs |
| equity_vest_schedule_code | VARCHAR(20) | NULL | 4yr-1yr-cliff / 3yr-monthly / etc. |
| total_target_comp_usd | DECIMAL(18,2) | NULL | Base + target bonus + annualized equity |
| benefits_cost_usd | DECIMAL(18,2) | NULL | Employer benefits cost (annualized) |
| pay_grade_code | VARCHAR(20) | NULL | Pay grade/band (L3, L4, G5, etc.) |
| pay_range_min_usd | DECIMAL(18,2) | NULL | Salary band minimum |
| pay_range_mid_usd | DECIMAL(18,2) | NULL | Salary band midpoint |
| pay_range_max_usd | DECIMAL(18,2) | NULL | Salary band maximum |
| compa_ratio | DECIMAL(6,4) | NULL | base ÷ range_mid (1.0 = at midpoint) |
| market_percentile | DECIMAL(5,2) | NULL | Position vs. external market data |
| approved_by_employee_key | INT | FK → Dim_Employee, NULL | HR/manager who approved change |
| created_at | TIMESTAMP_NTZ | NOT NULL | ETL load timestamp |

**Indexes / Clustering:** CLUSTER BY (effective_date_key, department_key)
**Power BI Measure Examples:** Pay Equity Gap (gender/ethnicity), Compa-Ratio distribution, Merit increase by performance rating correlation

---

### FACT_TRAINING
**Purpose:** Records all learning and development activities at the employee-course-completion grain. Captures enrollments, completions, assessment scores, and hours invested. This table powers L&D ROI analysis, skills gap tracking, mandatory compliance completion rates, and learning-to-performance correlation.

**Enterprise Reasoning:** L&D spend at Fortune 500 companies averages $1,200–$2,000/employee/year. Without this table joined to FACT_PERFORMANCE, you cannot answer "does our leadership development program actually produce better-rated managers 12 months later?" That question, unanswered, means L&D budgets get cut in downturns. This table is the evidence base for defending and optimizing learning investment.

**Grain:** One row per (Employee × Course Enrollment)

| Column | Data Type | Constraint | Description |
|--------|-----------|-----------|-------------|
| training_key | BIGINT | PK, NOT NULL | Surrogate primary key |
| employee_key | INT | FK → Dim_Employee, NOT NULL | Employee dimension link |
| course_key | INT | FK → Dim_Course, NOT NULL | Course/content dimension |
| enrollment_date_key | INT | FK → Dim_Date, NOT NULL | Date enrolled |
| completion_date_key | INT | FK → Dim_Date, NULL | Date completed (NULL if in-progress) |
| due_date_key | INT | FK → Dim_Date, NULL | Compliance deadline (if applicable) |
| department_key | INT | FK → Dim_Department, NOT NULL | Department at time of enrollment |
| role_key | INT | FK → Dim_Role, NOT NULL | Role at time of enrollment |
| delivery_method_code | VARCHAR(30) | NOT NULL | eLearning / ILT / VILT / Coaching / Conference |
| status_code | VARCHAR(20) | NOT NULL | Enrolled / In-Progress / Completed / Failed / Withdrawn |
| completion_flag | BOOLEAN | NOT NULL | TRUE = successfully completed |
| is_mandatory_flag | BOOLEAN | NOT NULL | TRUE = compliance/mandatory training |
| is_overdue_flag | BOOLEAN | NOT NULL | TRUE = past due date and not complete |
| hours_assigned | DECIMAL(6,2) | NOT NULL | Expected learning hours |
| hours_completed | DECIMAL(6,2) | NOT NULL | Actual hours (0 if not started) |
| assessment_score_pct | DECIMAL(5,2) | NULL | Assessment/quiz score 0–100 |
| assessment_passed_flag | BOOLEAN | NULL | NULL if no assessment |
| assessment_attempts | INT | NOT NULL | Number of attempts (default 1) |
| learning_path_code | VARCHAR(50) | NULL | Assigned learning path/curriculum |
| skill_domain_code | VARCHAR(50) | NULL | Technical / Leadership / Compliance / Soft-Skills |
| skill_tags | ARRAY | NULL | Array of skill taxonomy tags |
| cost_usd | DECIMAL(10,2) | NULL | Cost of training (external/vendor) |
| satisfaction_score | DECIMAL(4,2) | NULL | Post-training feedback score (1–5) |
| manager_assigned_flag | BOOLEAN | NOT NULL | TRUE = assigned by manager vs. self-enrolled |
| created_at | TIMESTAMP_NTZ | NOT NULL | ETL load timestamp |

**Indexes / Clustering:** CLUSTER BY (completion_date_key, department_key)
**Power BI Measure Examples:** Mandatory Compliance Rate, Hours-per-Employee, L&D Cost per Completion, Skills Coverage Rate

---

## DIMENSION TABLES

---

### DIM_EMPLOYEE
**Purpose:** The central conformed dimension. Implements SCD Type 2 — every time an employee's attributes change (role, department, salary band, location, name), a new row is inserted with a new surrogate key, and the old row is closed with an `end_date`. This preserves perfect historical accuracy: a FACT_ATTENDANCE record from 2022 links to the 2022 version of Dim_Employee, not today's version.

**Enterprise Reasoning:** Without SCD2, "what was the attrition rate for employees who were in the Engineering department in 2022?" becomes an impossible query — because current Dim_Employee shows where people work TODAY. SCD2 is non-negotiable for any HR system that needs historical accuracy.

| Column | Data Type | Constraint | Description |
|--------|-----------|-----------|-------------|
| employee_key | INT | PK, NOT NULL | Surrogate key (auto-increment per SCD2 version) |
| employee_id | VARCHAR(20) | NOT NULL | Natural key from HRIS (stable across versions) |
| employee_global_id | VARCHAR(36) | NOT NULL | UUID for cross-system identity |
| scd_version | INT | NOT NULL | Version number (1 = original, 2 = first change, etc.) |
| effective_start_date | DATE | NOT NULL | When this version became effective |
| effective_end_date | DATE | NULL | When superseded (NULL = current version) |
| is_current_flag | BOOLEAN | NOT NULL | TRUE = this is the active SCD2 row |
| first_name | VARCHAR(100) | NOT NULL | Legal first name |
| last_name | VARCHAR(100) | NOT NULL | Legal last name |
| full_name | VARCHAR(200) | NOT NULL | Concatenated display name |
| preferred_name | VARCHAR(100) | NULL | Preferred/nickname if different |
| email_work | VARCHAR(200) | NOT NULL | Work email address |
| hire_date | DATE | NOT NULL | Original hire date (never changes across versions) |
| rehire_date | DATE | NULL | Most recent rehire date if applicable |
| termination_date | DATE | NULL | Termination date (populated on exit) |
| birth_date | DATE | NULL | Date of birth (PII — masked for most roles) |
| age_band_code | VARCHAR(20) | NULL | <25 / 25-34 / 35-44 / 45-54 / 55-64 / 65+ |
| gender_code | VARCHAR(20) | NULL | Male / Female / Non-binary / Prefer-not-to-say |
| ethnicity_code | VARCHAR(30) | NULL | Per EEOC categories (PII — masked for most roles) |
| nationality_code | CHAR(2) | NULL | ISO 3166 country code |
| highest_education_code | VARCHAR(30) | NULL | High-School / Bachelor / Master / PhD / Other |
| years_experience_prior | DECIMAL(4,1) | NULL | Years of experience before joining |
| employment_status_code | VARCHAR(20) | NOT NULL | Active / Terminated / LOA / Inactive |
| employee_type_code | VARCHAR(20) | NOT NULL | Full-Time / Part-Time / Contract / Intern |
| flsa_status_code | VARCHAR(20) | NULL | Exempt / Non-Exempt (US specific) |
| remote_work_type_code | VARCHAR(20) | NULL | On-site / Hybrid / Fully-Remote |
| created_at | TIMESTAMP_NTZ | NOT NULL | Row creation timestamp |
| source_system_code | VARCHAR(30) | NOT NULL | Workday / BambooHR / SAP / etc. |

**PII Note:** gender_code, ethnicity_code, birth_date masked for ANALYST role; visible only to COMP_ADMIN, HR_DIRECTOR, COMPLIANCE roles via Snowflake row-level security.

---

### DIM_DEPARTMENT
**Purpose:** Conformed dimension representing the organizational hierarchy. Supports drill-down analysis from company → division → function → department → team. Implements SCD Type 1 (overwrite) because we want current org structure for current analysis — historical org restructures are tracked via FACT_EMPLOYEE_SNAPSHOT which carries point-in-time department_key.

| Column | Data Type | Constraint | Description |
|--------|-----------|-----------|-------------|
| department_key | INT | PK, NOT NULL | Surrogate key |
| department_id | VARCHAR(30) | NOT NULL | Natural key from HRIS |
| department_name | VARCHAR(100) | NOT NULL | Display name (e.g. "Product Engineering") |
| department_code | VARCHAR(20) | NOT NULL | Short code (e.g. "PROD-ENG") |
| cost_center_code | VARCHAR(30) | NOT NULL | Finance cost center mapping |
| company_code | VARCHAR(20) | NOT NULL | Legal entity code |
| division_name | VARCHAR(100) | NOT NULL | Top-level division (e.g. "Technology") |
| division_code | VARCHAR(20) | NOT NULL | Division short code |
| function_name | VARCHAR(100) | NOT NULL | Function (e.g. "Software Engineering") |
| function_code | VARCHAR(20) | NOT NULL | Function short code |
| sub_function_name | VARCHAR(100) | NULL | Sub-function if applicable |
| department_head_employee_key | INT | FK → Dim_Employee, NULL | Department head reference |
| parent_department_key | INT | FK → Dim_Department, NULL | Parent dept (self-referencing for hierarchy) |
| hierarchy_level | INT | NOT NULL | 1=Company, 2=Division, 3=Function, 4=Dept, 5=Team |
| hierarchy_path | VARCHAR(500) | NOT NULL | Full path "Org/Tech/Engineering/Platform/Backend" |
| headcount_budget | INT | NULL | Approved headcount budget |
| opex_budget_usd | DECIMAL(18,2) | NULL | Operating expense budget |
| is_active_flag | BOOLEAN | NOT NULL | FALSE = deprecated/reorganized |
| effective_start_date | DATE | NOT NULL | When department was created |
| effective_end_date | DATE | NULL | When department was disbanded |
| created_at | TIMESTAMP_NTZ | NOT NULL | Row creation timestamp |

---

### DIM_LOCATION
**Purpose:** Conformed dimension for all work locations. Supports geographic analysis (headcount by city, country, region) and geo-differential compensation analysis (San Francisco roles have a 1.25× location multiplier vs. national median). Snowflaked into City → State → Country → Region hierarchy for clean reporting.

| Column | Data Type | Constraint | Description |
|--------|-----------|-----------|-------------|
| location_key | INT | PK, NOT NULL | Surrogate key |
| location_id | VARCHAR(30) | NOT NULL | Natural key |
| location_name | VARCHAR(100) | NOT NULL | Office/site name (e.g. "SF HQ – 3rd Floor") |
| location_type_code | VARCHAR(30) | NOT NULL | Headquarters / Regional-Office / Satellite / Home / Remote |
| address_line_1 | VARCHAR(200) | NULL | Street address |
| city_name | VARCHAR(100) | NOT NULL | City |
| state_province_code | VARCHAR(10) | NULL | State/province abbreviation |
| state_province_name | VARCHAR(100) | NULL | Full state/province name |
| country_code | CHAR(2) | NOT NULL | ISO 3166-1 alpha-2 |
| country_name | VARCHAR(100) | NOT NULL | Full country name |
| region_code | VARCHAR(20) | NOT NULL | AMER / EMEA / APAC / LATAM |
| region_name | VARCHAR(50) | NOT NULL | Americas / Europe Middle East Africa / Asia Pacific |
| metro_area_code | VARCHAR(30) | NULL | NYC / SF-Bay / LON / SYD etc. |
| timezone_code | VARCHAR(50) | NOT NULL | IANA timezone (e.g. America/New_York) |
| geo_differential_factor | DECIMAL(6,4) | NULL | Location cost-of-living multiplier |
| is_remote_eligible_flag | BOOLEAN | NOT NULL | TRUE = remote work permitted from this location |
| latitude | DECIMAL(10,7) | NULL | Geo coordinates for map visualization |
| longitude | DECIMAL(10,7) | NULL | Geo coordinates for map visualization |
| is_active_flag | BOOLEAN | NOT NULL | FALSE = closed location |
| created_at | TIMESTAMP_NTZ | NOT NULL | Row creation timestamp |

---

### DIM_DATE
**Purpose:** The standard time dimension. Pre-populated for 10+ years. Every date attribute that HR analysis needs is pre-calculated here — fiscal year, quarter, ISO week, holiday flags, working day flags. This eliminates complex DAX or SQL date math in every report. Power BI imports this entire table into memory (~3,650 rows) and relationship-traverses it for free.

**Enterprise Reasoning:** HR analytics has complex date logic. "What is the 90-day new hire attrition rate for Q2 FY2024?" requires fiscal year mapping, working-day counting, and cohort date windowing. Without a proper date dimension, every analyst re-invents these calculations inconsistently. One date dimension, calculated once, used everywhere.

| Column | Data Type | Constraint | Description |
|--------|-----------|-----------|-------------|
| date_key | INT | PK, NOT NULL | YYYYMMDD integer (e.g. 20240315) |
| full_date | DATE | NOT NULL | Actual date value |
| day_of_week_num | INT | NOT NULL | 1=Monday to 7=Sunday |
| day_of_week_name | VARCHAR(10) | NOT NULL | Monday, Tuesday, etc. |
| day_of_week_short | CHAR(3) | NOT NULL | Mon, Tue, etc. |
| day_of_month | INT | NOT NULL | 1–31 |
| day_of_year | INT | NOT NULL | 1–366 |
| week_of_year | INT | NOT NULL | ISO week number 1–53 |
| iso_year_week | VARCHAR(8) | NOT NULL | 2024-W12 format |
| month_num | INT | NOT NULL | 1–12 |
| month_name | VARCHAR(10) | NOT NULL | January, February, etc. |
| month_short | CHAR(3) | NOT NULL | Jan, Feb, etc. |
| month_year | VARCHAR(8) | NOT NULL | Jan-2024 |
| quarter_num | INT | NOT NULL | 1–4 |
| quarter_label | VARCHAR(6) | NOT NULL | Q1, Q2, Q3, Q4 |
| year_num | INT | NOT NULL | Calendar year |
| year_quarter | VARCHAR(7) | NOT NULL | 2024-Q1 |
| is_weekday_flag | BOOLEAN | NOT NULL | TRUE = Mon–Fri |
| is_weekend_flag | BOOLEAN | NOT NULL | TRUE = Sat–Sun |
| is_company_holiday_flag | BOOLEAN | NOT NULL | TRUE = company holiday |
| is_us_federal_holiday_flag | BOOLEAN | NOT NULL | TRUE = US federal holiday |
| is_month_end_flag | BOOLEAN | NOT NULL | TRUE = last calendar day of month |
| is_quarter_end_flag | BOOLEAN | NOT NULL | TRUE = last calendar day of quarter |
| is_year_end_flag | BOOLEAN | NOT NULL | TRUE = December 31 |
| fiscal_year | INT | NOT NULL | Fiscal year (may differ from calendar year) |
| fiscal_quarter_num | INT | NOT NULL | Fiscal quarter 1–4 |
| fiscal_quarter_label | VARCHAR(8) | NOT NULL | FY24-Q1 |
| fiscal_month_num | INT | NOT NULL | Fiscal month 1–12 |
| fiscal_period_label | VARCHAR(8) | NOT NULL | FY24-P03 |
| days_in_month | INT | NOT NULL | 28, 29, 30, or 31 |
| relative_day_offset | INT | NOT NULL | Days from today (negative=past, positive=future) |
| relative_month_offset | INT | NOT NULL | Months from current month |

---

### DIM_MANAGER
**Purpose:** Role-playing dimension extending Dim_Employee specifically for manager attributes and managerial effectiveness metrics. While every manager IS an employee, the managerial context — span of control, team turnover, 360 feedback scores — justifies a separate dimension that aggregates team-level metrics onto the manager record. This is a common Power BI pattern: role-playing dimensions that reference the same underlying entity table with different semantic context.

| Column | Data Type | Constraint | Description |
|--------|-----------|-----------|-------------|
| manager_key | INT | PK, NOT NULL | Surrogate key |
| employee_key | INT | FK → Dim_Employee, NOT NULL | Links to Dim_Employee for base attributes |
| employee_id | VARCHAR(20) | NOT NULL | Natural key (denormalized for query performance) |
| full_name | VARCHAR(200) | NOT NULL | Denormalized for display |
| department_key | INT | FK → Dim_Department, NOT NULL | Manager's home department |
| management_level_code | VARCHAR(30) | NOT NULL | Team-Lead / Manager / Sr-Manager / Director / VP / SVP / C-Suite |
| direct_report_count | INT | NOT NULL | Current direct report headcount |
| total_org_size | INT | NOT NULL | Total span (directs + skip-level) |
| span_of_control_ratio | DECIMAL(5,2) | NOT NULL | Total org / direct management layers |
| tenure_as_manager_months | INT | NOT NULL | Months in current managerial role |
| manager_effectiveness_score | DECIMAL(5,2) | NULL | Composite: team engagement + team attrition + 360 scores |
| team_voluntary_attrition_rate | DECIMAL(6,4) | NULL | Rolling 12-month voluntary attrition for their team |
| team_engagement_score_avg | DECIMAL(5,2) | NULL | Average team engagement score |
| team_performance_avg | DECIMAL(5,2) | NULL | Average performance rating for direct reports |
| upward_feedback_score | DECIMAL(5,2) | NULL | Manager rating from 360/upward feedback surveys |
| promotion_rate_of_team | DECIMAL(6,4) | NULL | % of team promoted in last 12 months |
| hire_approval_count_ytd | INT | NOT NULL | New hires approved year-to-date |
| termination_approval_count_ytd | INT | NOT NULL | Terminations approved year-to-date |
| is_current_flag | BOOLEAN | NOT NULL | TRUE = currently holds managerial role |
| effective_start_date | DATE | NOT NULL | When this version effective |
| effective_end_date | DATE | NULL | When superseded |
| created_at | TIMESTAMP_NTZ | NOT NULL | Row creation timestamp |

---

### DIM_ROLE
**Purpose:** Conformed job architecture dimension. Captures the full job taxonomy — job family → job function → job title → job level → pay grade. Implements SCD Type 2 because job codes and pay grades change over time. This dimension is critical for: compensation benchmarking (need consistent job codes to match to market data), org design analysis (spans and layers by level), and skills gap analysis (required skills per role vs. available skills in workforce).

| Column | Data Type | Constraint | Description |
|--------|-----------|-----------|-------------|
| role_key | INT | PK, NOT NULL | Surrogate key (SCD2 versioned) |
| role_id | VARCHAR(30) | NOT NULL | Natural key (job code from HRIS) |
| scd_version | INT | NOT NULL | SCD2 version number |
| effective_start_date | DATE | NOT NULL | When this version effective |
| effective_end_date | DATE | NULL | When superseded (NULL = current) |
| is_current_flag | BOOLEAN | NOT NULL | TRUE = active version |
| job_title | VARCHAR(100) | NOT NULL | Official job title |
| job_title_standard | VARCHAR(100) | NOT NULL | Standardized title for cross-company benchmarking |
| job_family_code | VARCHAR(30) | NOT NULL | Engineering / Product / Finance / Sales / HR / Operations |
| job_family_name | VARCHAR(100) | NOT NULL | Full job family name |
| job_function_code | VARCHAR(30) | NOT NULL | Sub-family (e.g. Software-Engineering within Engineering) |
| job_function_name | VARCHAR(100) | NOT NULL | Full job function name |
| job_level_code | VARCHAR(20) | NOT NULL | IC1 / IC2 / IC3 / IC4 / M1 / M2 / M3 / D1 / VP1 |
| job_level_name | VARCHAR(50) | NOT NULL | Associate / Mid / Senior / Staff / Principal / Manager |
| career_track_code | VARCHAR(20) | NOT NULL | Individual-Contributor / Manager / Executive |
| pay_grade_code | VARCHAR(20) | NOT NULL | G3 / G4 / L5 / L6 etc. (company-specific) |
| flsa_status_code | VARCHAR(20) | NOT NULL | Exempt / Non-Exempt |
| is_manager_role_flag | BOOLEAN | NOT NULL | TRUE = this role includes people management |
| is_executive_flag | BOOLEAN | NOT NULL | TRUE = VP and above |
| required_education_code | VARCHAR(30) | NULL | Minimum required education level |
| eeoc_job_category_code | VARCHAR(30) | NOT NULL | EEOC category for workforce data reporting |
| o_net_soc_code | VARCHAR(10) | NULL | O*NET Standard Occupational Classification |
| target_pay_range_min_usd | DECIMAL(18,2) | NULL | Role pay range minimum |
| target_pay_range_mid_usd | DECIMAL(18,2) | NULL | Role pay range midpoint |
| target_pay_range_max_usd | DECIMAL(18,2) | NULL | Role pay range maximum |
| required_skills | ARRAY | NULL | Array of required skill tags |
| is_critical_role_flag | BOOLEAN | NOT NULL | TRUE = designated business-critical position |
| created_at | TIMESTAMP_NTZ | NOT NULL | Row creation timestamp |

---

## DATA LINEAGE

### Source-to-Target Lineage

```
WORKDAY HRIS
├── Worker Object → dbt_bronze.workday_workers → dbt_silver.employees → DIM_EMPLOYEE (SCD2)
├── Position Object → dbt_bronze.workday_positions → dbt_silver.roles → DIM_ROLE (SCD2)
├── Organization Object → dbt_bronze.workday_orgs → dbt_silver.departments → DIM_DEPARTMENT
└── Compensation Object → dbt_bronze.workday_comp → dbt_silver.comp_events → FACT_COMPENSATION

GREENHOUSE ATS
├── Job Object → dbt_bronze.gh_jobs → dbt_silver.requisitions → FACT_RECRUITMENT (req dims)
├── Application Object → dbt_bronze.gh_applications → dbt_silver.applications → FACT_RECRUITMENT
└── Scorecard Object → dbt_bronze.gh_scorecards → dbt_silver.interview_scores → FACT_RECRUITMENT

ADP PAYROLL
├── Pay Statement → dbt_bronze.adp_pay → dbt_silver.pay_events → FACT_COMPENSATION (bonus/actual pay)
└── Time & Attendance → dbt_bronze.adp_time → dbt_silver.attendance → FACT_ATTENDANCE

CORNERSTONE LMS
├── Course Catalog → dbt_bronze.csod_courses → dbt_silver.courses → DIM_COURSE
└── Transcript → dbt_bronze.csod_transcripts → dbt_silver.enrollments → FACT_TRAINING

QUALTRICS SURVEY
├── Engagement Survey → dbt_bronze.qualtrics_engagement → dbt_silver.engagement_scores
│   → FACT_EMPLOYEE_SNAPSHOT (engagement_score field, updated monthly)
└── Exit Survey → dbt_bronze.qualtrics_exit → dbt_silver.exit_data
    → FACT_RECRUITMENT (candidate_nps_score) + FACT_EMPLOYEE_SNAPSHOT (exit_reason_code)

WORKDAY + ADP (ATTENDANCE)
└── Time-Off Requests + Schedules → dbt_bronze.time_off → dbt_silver.attendance → FACT_ATTENDANCE

ML MODELS (WRITE-BACK)
└── Flight Risk Scorer (weekly) → ml_predictions.flight_risk → FACT_EMPLOYEE_SNAPSHOT (flight_risk_score)
```

### dbt Transformation Layers

```
BRONZE (Raw + Typed)
  - Cast all fields to proper types
  - Handle NULL/empty string normalization
  - Add source_system_code and ingestion_timestamp
  - No business logic

SILVER (Standardized + Deduped)
  - Deduplicate on natural keys
  - Standardize codes to agreed taxonomy (e.g. "Full Time" / "FT" / "F" → "Full-Time")
  - Apply exchange rate normalization (local currency → USD)
  - Resolve entity references (employee_id → employee_key)

GOLD (Semantic + Business Ready)
  - Apply SCD2 logic for slowly changing dimensions
  - Compute derived fields (tenure_months, compa_ratio, fte_value)
  - Apply row-level security tags
  - Create fact tables with all FK relationships validated
  - Compute pre-aggregated summary tables for Power BI performance
```

---

## POWER BI OPTIMIZATION NOTES

### Relationship Model
- All fact-to-dimension relationships are MANY-TO-ONE (standard star schema)
- All relationships use INT surrogate keys (not VARCHAR natural keys)
- Date table marked as "Date table" in Power BI with date_key as the date column
- Dim_Manager and Dim_Employee both visible as separate tables — role-playing pattern

### Pre-Aggregated Summary Tables (dbt Gold)
Create these additional tables to avoid Power BI computing expensive aggregations:

- `agg_headcount_monthly` — pre-calculated monthly headcount by dept/location/function
- `agg_attrition_monthly` — voluntary/involuntary attrition by cohort, pre-calculated
- `agg_source_quality` — source → 12-month performance correlation, pre-joined
- `agg_compensation_equity` — pay gap statistics by gender/ethnicity/level, pre-computed
- `agg_training_completion` — compliance training completion rates by dept

### Incremental Refresh Strategy
- FACT tables: 2-year rolling window with 2-day incremental refresh
- DIM tables: full refresh nightly (dimensions are small, fast to reload)
- Aggregation tables: triggered after fact refresh completes

---

## BUSINESS DEFINITIONS GLOSSARY

| Term | Business Definition |
|------|-------------------|
| Active Headcount | Count of employees with employment_status_code = 'Active' AND is_active_flag = TRUE at a given point in time |
| Regrettable Attrition | Voluntary separations where the company would have preferred to retain the employee (is_regrettable_exit_flag = TRUE). Typically top performers and critical-skill holders |
| Voluntary Attrition Rate | (Voluntary separations in period) ÷ (Average active headcount in period) × 100. Excludes layoffs, deaths, retirement |
| Compa-Ratio | Employee base salary ÷ midpoint of their pay range. 1.0 = at market midpoint. <0.8 = below market. >1.2 = above market |
| FTE (Full-Time Equivalent) | Part-time headcount normalized to full-time: a 20hr/week employee = 0.5 FTE |
| Time to Fill | Calendar days from requisition open_date to the candidate's hire_date. Excludes time when req is on hold |
| Quality of Hire | Composite score: (performance_rating_normalized + retention_12m_flag + engagement_score_normalized) ÷ 3, calculated 12 months post-hire |
| Span of Control | Number of direct reports managed. Optimal range varies by level: IC managers = 6–10, Director+ = 4–8 |
| Flight Risk Score | ML model output 0–100: probability employee resigns voluntarily within 90 days. >70 = High Risk (HRBP alert). 40–70 = Medium. <40 = Low |
| Pay Equity Gap | Unexplained pay difference between demographic groups after controlling for legitimate differentiators (level, tenure, performance, location, function) |
| eNPS (Employee Net Promoter Score) | % Promoters (score 9–10) minus % Detractors (score 0–6) on "Would you recommend this company as a place to work?" |
| Tenure | Time in months from hire_date (or most recent rehire_date) to the analysis date |
| Internal Mobility Rate | % of open roles filled by internal candidates. Formula: internal_fills ÷ total_fills × 100 |
| Regrettable Attrition Rate | (Regrettable voluntary separations) ÷ (Average active headcount) × 100. Target < 5% for most organizations |
```

---

*Document: PeoplePulse AI Data Model v1.0*
*Author: Senior Data Architecture Team*
*Classification: Internal — Data Engineering*
