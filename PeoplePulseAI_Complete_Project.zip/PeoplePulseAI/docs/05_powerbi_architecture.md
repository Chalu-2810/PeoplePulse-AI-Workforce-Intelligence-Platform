# PeoplePulse AI — Power BI Enterprise Dashboard Architecture
## Phase 6 | Senior Power BI Architect Design Specification
### 15 Pages | Fortune 500 Standard | Production-Ready Build Guide

---

## GLOBAL DESIGN SYSTEM

**Theme:** Custom JSON theme — Primary `#0066CC` (PeoplePulse Blue), Secondary `#1D9E75` (Retention Green), Alert `#D85A30` (Risk Coral), Neutral background `#F7F6F2`, Card background `#FFFFFF`, Typography: Segoe UI / Inter.

**Global Filter Pane (persists across all pages via Sync Slicers):** Department · Location · Job Level · Gender · Work Mode · Date/Period (if historical snapshots loaded).

**Navigation:** Left rail icon navigation (custom SVG buttons via bookmarks) — Executive Overview pinned as home; AI Insights and Executive Summary accessible from every page via a persistent top-right "Insights" button.

**Page Canvas:** 1920×1080 (16:9), 12-column grid, 24px gutters.

---

# PAGE 1 — EXECUTIVE OVERVIEW

**Business Objective:** Give a CHRO/CEO a complete workforce health read in under 30 seconds — the "walk into the boardroom" page.

**KPIs (top KPI strip, 6 cards):**
Total Headcount · Attrition Rate (RAG) · Avg Engagement Score · Avg Salary · High Flight Risk Count · Regrettable Attrition %

**Visuals:**
- Top strip: 6 KPI cards with trend sparklines and YoY delta arrows
- Center-left: Headcount by Department (clustered bar) with Attrition Rate overlay (line, secondary axis)
- Center-right: Organizational Health Index — radial gauge combining engagement, attrition, performance into single 0-100 score
- Bottom-left: Donut — Gender distribution
- Bottom-center: Treemap — Headcount by Location
- Bottom-right: Mini engagement-tier funnel (Engaged → Low Risk → Medium Risk → High Risk)

**Layout Design:**
```
┌─────┬─────┬─────┬─────┬─────┬─────┐
│ KPI │ KPI │ KPI │ KPI │ KPI │ KPI │  ← Row 1: KPI strip (8% height)
├─────────────────┬───────────────────┤
│ Dept Headcount + │  Org Health Index │  ← Row 2: 60% height
│ Attrition overlay│  (radial gauge)   │
├──────────┬───────┴────────┬──────────┤
│  Gender  │  Location       │ Engmt    │  ← Row 3: 32% height
│  Donut   │  Treemap        │ Funnel   │
└──────────┴─────────────────┴──────────┘
```

**User Journey:** Land here by default → scan KPI strip for RAG alerts → click any department bar to cross-filter the entire page → click "Insights" for AI narrative → drill to Page 2/3 for deep dives.

**Filters:** Global filter pane (Dept/Location/Level/Gender/WorkMode). No page-specific filters — this page must show the *whole* org by default.

**Drillthrough Logic:** Right-click any department → "Drill through to Department Insights (Page 11)" passing DepartmentName as filter context.

**Storytelling Flow:** Headline number (headcount + attrition RAG) → "where" (department breakdown) → "why it matters" (org health composite) → "who" (demographic composition) → "what's coming" (flight risk funnel teaser, full detail on Page 4/10).

---

# PAGE 2 — WORKFORCE ANALYTICS

**Business Objective:** Deep operational view of organizational structure, composition, and capacity for HR Operations and Workforce Planning teams.

**KPIs:** Total FTE · Span of Control (avg) · Org Pyramid Ratio (IC:Mgr:Exec) · Remote/Hybrid/Onsite % · Avg Tenure · Headcount Growth Rate

**Visuals:**
- Org Pyramid: horizontal stacked bar by Job Level (L1 at bottom, L8 at top) — visual pyramid shape
- Span of Control distribution: histogram with overlay markers at "optimal," "overloaded," "under-span" thresholds
- Work Mode by Department: 100% stacked bar
- Tenure distribution: histogram with median line
- Age Band × Job Level matrix (heatmap)
- Geographic map: bubble map sized by headcount per location

**Layout Design:**
```
┌─────┬─────┬─────┬─────┬─────┬─────┐
│ KPI │ KPI │ KPI │ KPI │ KPI │ KPI │
├──────────────────┬────────────────┤
│  Org Pyramid      │  Geographic Map│
│  (stacked bar)    │  (bubble map)  │
├─────────┬─────────┼────────────────┤
│ Span of │ WorkMode│  Age × Level    │
│ Control │ by Dept │  Heatmap        │
│ Histogram│ 100%bar│                 │
└─────────┴─────────┴────────────────┘
```

**User Journey:** HR Ops lead checks org pyramid for delayering opportunities → checks span-of-control histogram for overloaded managers → cross-references with geographic map for real-estate decisions.

**Filters:** Global pane + page-specific slicer for "Career Track" (IC/Manager/Executive).

**Drillthrough Logic:** Click any bar in Span of Control histogram → drill through to Manager Scorecard (Page 12), pre-filtered to managers in that span bucket.

**Storytelling Flow:** Structure (pyramid) → capacity (span of control) → location strategy (work mode + geo map) → demographic context (age × level heatmap, sets up Page 8 Diversity deep-dive).

---

# PAGE 3 — ATTRITION INTELLIGENCE

**Business Objective:** The single most scrutinized page — diagnoses attrition root causes for HR Director and CHRO decision-making.

**KPIs:** Overall Attrition Rate · Voluntary Attrition Rate · Regrettable Attrition Rate · New Hire (≤1yr) Attrition Rate · Attrition Cost Impact ($)

**Visuals:**
- Attrition Rate by Department: horizontal bar, sorted descending, RAG colored
- Attrition by Tenure Band: line chart (survival curve) with annotated risk zones
- Exit Reason distribution: horizontal bar (attrited population only)
- Attrition Driver Decomposition table: metric / attrited avg / retained avg / delta (from Q-ATT-01)
- 9-Box Engagement × Performance Matrix with attrition rate per quadrant
- Regrettable vs. Managed Exit split: stacked bar by department

**Layout Design:**
```
┌─────┬─────┬─────┬─────┬─────┐
│ KPI │ KPI │ KPI │ KPI │ KPI │
├───────────────┬───────────────┤
│ Attrition by   │ Survival Curve │
│ Dept (h-bar)   │ by Tenure Band │
├───────────────┼───────────────┤
│ Exit Reason    │  9-Box Matrix  │
│ (h-bar)        │  (heatmap)     │
├────────────────┴───────────────┤
│  Attrition Driver Decomposition │
│  (table, sortable by |Delta|)   │
└──────────────────────────────────┘
```

**User Journey:** CHRO opens page → immediately sees which departments are RAG-red → clicks survival curve to understand *when* people leave → reviews exit reasons for *why* → uses driver decomposition table for root-cause evidence → drills into 9-box to identify "Flight Risk HiPo" quadrant for urgent action.

**Filters:** Global pane + "Attrition Type" slicer (All / Voluntary / Involuntary / Regrettable Only).

**Drillthrough Logic:** Click any department bar → drillthrough to Department Insights (Page 11) filtered to that department's attrited population. Click 9-box "Flight Risk HiPo" quadrant → drillthrough to Employee Drillthrough (Page 13) showing the named individual list (HRBP/Director access only).

**Storytelling Flow:** "How bad is it" (headline rates) → "where" (department) → "when" (tenure curve) → "why" (exit reasons + driver decomposition) → "who's most at risk right now" (9-box, sets up Page 10 Predictive).

---

# PAGE 4 — EMPLOYEE EXPERIENCE

**Business Objective:** Engagement, satisfaction, attendance, and wellbeing — the "how does it feel to work here" page for HR Director and CHRO.

**KPIs:** Avg Engagement Score · eNPS · Avg Satisfaction Score · % High Flight Risk · Avg Attendance % · Chronic Absenteeism Rate

**Visuals:**
- Engagement by Department: bar chart, RAG colored, sorted ascending (worst first)
- Engagement-Satisfaction Gap: dual-line trend (if historical data) or scatter (current snapshot) by department
- Honeymoon Curve: Engagement Score by Tenure Band (line chart, annotated)
- Flight Risk Tier distribution: donut (High/Medium/Low/Engaged) with employee counts
- Attendance vs. Engagement scatter plot (validates correlation, Section 5.4 of KPI framework)
- Leave Utilization distribution: histogram with "healthy zone" band highlighted

**Layout Design:**
```
┌─────┬─────┬─────┬─────┬─────┬─────┐
│ KPI │ KPI │ KPI │ KPI │ KPI │ KPI │
├──────────────────┬────────────────┤
│ Engagement by Dept│ Flight Risk     │
│ (RAG bar, asc)    │ Tier Donut      │
├─────────┬─────────┼────────────────┤
│Honeymoon│Attendance│ Leave          │
│ Curve   │ Scatter │ Utilization    │
└─────────┴─────────┴────────────────┘
```

**User Journey:** HR Director checks engagement RAG by dept → identifies worst-performing teams → reviews honeymoon curve to contextualize whether low scores are tenure-driven or systemic → checks flight risk donut for headcount-at-risk → cross-references attendance scatter for corroborating signal.

**Filters:** Global pane + "Engagement Tier" slicer for focused analysis.

**Drillthrough Logic:** Click any department in Engagement bar → drillthrough to Manager Scorecard (Page 12) for that department, surfacing which managers' teams are driving the low score.

**Storytelling Flow:** Overall sentiment (eNPS, engagement) → where it's worst (dept bar) → is it structural or temporal (honeymoon curve) → who's at risk right now (flight risk donut) → corroborating behavioral evidence (attendance/leave).

---

# PAGE 5 — COMPENSATION ANALYTICS

**Business Objective:** Total Rewards and Legal/Compliance view of pay competitiveness, equity, and cost structure.

**KPIs:** Avg Compa-Ratio · Gender Pay Gap % · Total Compensation Cost · % Below Market (Compa<0.85) · Avg Bonus-to-Base Ratio

**Visuals:**
- Salary Distribution by Level: box-and-whisker (P10/P25/Median/P75/P90) — built via custom visual or layered bar
- Pay Equity Heatmap: Gender Pay Gap % by Job Level × Department
- Compa-Ratio Distribution: histogram with risk bands colored (Severely Underpaid → Top of Band)
- Bonus-to-Base by Performance Tier: grouped bar (differentiation visual)
- Salary Band Penetration scatter: Years in Level (X) vs Band Penetration % (Y)
- Total Comp Cost by Department: treemap sized by cost, colored by avg compa-ratio

**Layout Design:**
```
┌─────┬─────┬─────┬─────┬─────┐
│ KPI │ KPI │ KPI │ KPI │ KPI │
├───────────────┬───────────────┤
│ Salary Box Plot│ Pay Equity     │
│ by Level       │ Heatmap        │
├───────┬────────┼────────────────┤
│ Compa │ Bonus  │ Band Penetration│
│ Ratio │ Diff.  │ Scatter         │
│ Hist  │ Bar    │                 │
└───────┴────────┴─────────────────┘
│      Total Comp Cost Treemap     │
└────────────────────────────────────┘
```

**User Journey:** Total Rewards lead opens page → checks pay equity heatmap for red cells → drills into specific level/department → cross-checks compa-ratio histogram for "Severely Underpaid" population → reviews bonus differentiation for pay-for-performance validation.

**Filters:** Global pane + "Pay Component" slicer (Base / Bonus / Total Comp).

**Drillthrough Logic:** Click any cell in Pay Equity Heatmap → drillthrough to Employee Drillthrough (Page 13) filtered to that Level × Department × Gender combination, showing individual compa-ratios (restricted to Comp Admin / HR Director roles via RLS).

**Storytelling Flow:** Market position (compa-ratio) → fairness (equity heatmap) → individual risk (compa-ratio distribution) → effectiveness of differentiation (bonus chart) → total cost context (treemap, bridges to CFO conversation).

---

# PAGE 6 — RECRUITMENT ANALYTICS

**Business Objective:** TA Director and TA Leadership view of pipeline health, source effectiveness, and hiring funnel performance.

**KPIs:** Avg Time to Fill · Offer Acceptance Rate · Internal Hire Rate · Avg Candidate NPS · Top Source Quality Score

**Visuals:**
- Hiring Funnel: Applied → Screen → Interview → Offer → Hired (funnel chart with conversion % at each stage)
- Source Quality Quadrant: Cost-per-Hire (X) vs Quality-of-Hire Score (Y), bubble sized by volume
- Time to Fill by Role Level: box plot vs. benchmark line
- Source Mix: donut with retention rate overlay (table beside)
- Internal vs External Fill trend: stacked area chart
- Candidate Experience NPS: gauge with trend sparkline

**Layout Design:**
```
┌─────┬─────┬─────┬─────┬─────┐
│ KPI │ KPI │ KPI │ KPI │ KPI │
├──────────────────┬────────────────┤
│  Hiring Funnel    │ Source Quality │
│  (funnel chart)   │ Quadrant       │
├─────────┬─────────┼────────────────┤
│ Time to │ Source  │ Internal vs    │
│ Fill    │ Mix     │ External Trend │
│ Box Plot│ Donut   │                │
└─────────┴─────────┴────────────────┘
```

**User Journey:** TA Director opens page → reviews funnel for the stage with biggest drop-off → checks source quality quadrant to reallocate budget → reviews time-to-fill against benchmark by level → checks internal mobility trend for culture narrative.

**Filters:** Global pane + "Recruitment Source" and "Job Level" slicers.

**Drillthrough Logic:** Click any funnel stage → drillthrough to a requisition-level detail page (not in the 15 core pages but supported via tooltip page) showing open reqs stuck at that stage >X days.

**Storytelling Flow:** Pipeline health (funnel) → where candidates come from and their quality (source quadrant + mix) → efficiency (time to fill) → culture signal (internal mobility) → candidate-side experience (NPS).

---

# PAGE 7 — PERFORMANCE ANALYTICS

**Business Objective:** Validates performance management process integrity and links performance to other workforce outcomes for HR Director.

**KPIs:** Avg Performance Rating · % High Performers · Performance Distribution Adherence (actual vs target curve) · Perf-Comp Correlation (R²) · PIP Conversion Rate

**Visuals:**
- Performance Distribution: stacked bar, actual vs. target (5/26/53/12/3%), by department (reveals inflation by manager/dept)
- Performance vs. Compensation scatter: Rating (X) vs Compa-Ratio (Y), colored by department, trend line + R²
- High Performer Retention comparison: side-by-side bars (Overall Retention vs. High-Performer Retention)
- Performance Rating Trend (if historical): line chart by department
- PIP Outcomes Sankey: PIP entry → Improved / Voluntary Exit / Involuntary Exit
- Training Hours by Performance Tier: bar chart (links to Page 9)

**Layout Design:**
```
┌─────┬─────┬─────┬─────┬─────┐
│ KPI │ KPI │ KPI │ KPI │ KPI │
├───────────────┬───────────────┤
│ Perf Distrib.  │ Perf vs Comp  │
│ Actual v Target│ Scatter + R²  │
│ by Dept        │               │
├────────┬───────┼───────────────┤
│Retention│ PIP   │ Training Hrs  │
│Compare  │ Sankey│ by Perf Tier  │
└────────┴───────┴───────────────┘
```

**User Journey:** HR Director checks distribution adherence to spot calibration drift by department → reviews perf-comp scatter for pay-for-performance evidence → checks retention comparison for the "are we keeping our best people" question → reviews PIP Sankey to understand what the PIP process is actually doing in practice.

**Filters:** Global pane + "Review Cycle" slicer (if multiple cycles loaded) + "Manager" search box.

**Drillthrough Logic:** Click any department bar in Distribution chart → drillthrough to Manager Scorecard (Page 12) filtered to that department, surfacing per-manager rating distributions for calibration discussion prep.

**Storytelling Flow:** Process integrity (distribution adherence) → does pay reflect performance (scatter) → are we keeping the best (retention comparison) → what happens to the struggling (PIP Sankey) → investment context (training by tier, bridges to Page 9).

---

# PAGE 8 — DIVERSITY ANALYTICS

**Business Objective:** DEI Lead and CHRO view of representation, equity, and inclusion health for internal strategy and ESG/board reporting.

**KPIs:** Female Representation % (Overall) · Female Representation % (L6+) · Pay Equity Index (composite) · Diversity Hiring Rate Differential · Diversity-Attrition Differential

**Visuals:**
- Representation Pipeline: funnel-style chart showing gender % at each job level L1→L8 (the "leaky pipeline" visual)
- Pay Equity Index gauge with sub-component breakdown table on click
- New Hire vs Existing Workforce composition: dual bar comparison by demographic dimension
- Attrition Rate by Demographic Group × Department: heatmap with statistical-significance flagging (asterisk annotations)
- Age Band distribution: population pyramid style chart
- Recruitment Source diversity profile: stacked bar by source showing demographic mix

**Layout Design:**
```
┌─────┬─────┬─────┬─────┬─────┐
│ KPI │ KPI │ KPI │ KPI │ KPI │
├──────────────────┬────────────────┤
│ Representation     │ Pay Equity     │
│ Pipeline (funnel)  │ Index Gauge    │
├─────────┬─────────┼────────────────┤
│New Hire │Attrition │ Age Band       │
│ vs      │ Diff.    │ Population     │
│Existing │ Heatmap  │ Pyramid         │
└─────────┴─────────┴────────────────┘
│   Recruitment Source Diversity Bar  │
└────────────────────────────────────┘
```

**User Journey:** DEI Lead opens page → checks representation pipeline for the level with steepest drop-off → reviews pay equity index, drills into sub-components if below threshold → checks new-hire vs existing comparison to assess trajectory → reviews attrition differential heatmap for "where are we losing specific groups disproportionately."

**Filters:** Global pane + "Demographic Dimension" slicer (Gender / Age Band / Ethnicity if available).

**Drillthrough Logic:** Click any level in Representation Pipeline → drillthrough to Department Insights (Page 11) filtered to that level, cross-tabbed by department, to identify which departments drive the pipeline leak at that level.

**Storytelling Flow:** Where are we now (pipeline) → are we paying fairly (equity index) → are we improving (new hire trajectory) → are we retaining everyone equally (attrition differential) → channel-level root cause (source diversity profile, bridges to Page 6).

---

# PAGE 9 — LEARNING & DEVELOPMENT

**Business Objective:** L&D Director view of training investment, effectiveness, and skills coverage for budget justification and strategic workforce planning.

**KPIs:** Avg Training Hours/Employee · Training Cost (Total) · Mandatory Compliance Rate · Training-Retention Differential · Skills Gap Coverage Ratio (avg across domains)

**Visuals:**
- Training Hours by Job Level: bar chart vs. ATD benchmark line
- Training Hours: Retained vs Attrited box plot comparison
- Mandatory Compliance Rate by Department: bar chart, RAG colored, 95% threshold line
- Skills Gap Coverage radar chart: current vs. target coverage by skill domain
- Training Investment by Department: treemap sized by total hours × $50/hr
- Satisfaction Score (post-training) trend by delivery method (eLearning/ILT/VILT/Coaching)

**Layout Design:**
```
┌─────┬─────┬─────┬─────┬─────┐
│ KPI │ KPI │ KPI │ KPI │ KPI │
├──────────────────┬────────────────┤
│ Training Hours by │ Skills Gap     │
│ Level vs Benchmark│ Radar Chart    │
├─────────┬─────────┼────────────────┤
│Training │Compliance│ Investment    │
│Retained │ by Dept  │ Treemap       │
│vs Exit  │ (RAG)    │               │
└─────────┴─────────┴────────────────┘
```

**User Journey:** L&D Director checks hours vs. benchmark for budget justification → reviews retention differential as ROI evidence → checks compliance RAG for legal-risk departments needing escalation → reviews skills gap radar for next year's curriculum planning priorities.

**Filters:** Global pane + "Skill Domain" and "Delivery Method" slicers.

**Drillthrough Logic:** Click any department in Compliance bar (especially red) → drillthrough to Employee Drillthrough (Page 13) filtered to overdue-mandatory-training individuals in that department, for manager follow-up list export.

**Storytelling Flow:** Investment level (hours + cost) → does it work (retention differential) → are we compliant (mandatory rate) → are we future-ready (skills gap radar) → where's the money going (investment treemap).

---

# PAGE 10 — PREDICTIVE ANALYTICS

**Business Objective:** Surfaces the ML Flight Risk model outputs (Phase 4) for proactive HRBP action — the most "AI-forward" page in the platform.

**KPIs:** Total High Risk Employees · Model AUC/Confidence indicator · Precision@Top10% · Predicted Attrition Cost (High Risk population × avg salary × 1.5) · Avg Risk Score (company-wide)

**Visuals:**
- Risk Tier Distribution: donut (High/Medium/Low/Engaged) with validated actual-attrition-rate-per-tier table beside it (model validation transparency)
- SHAP Feature Importance: horizontal bar chart, top 15 global drivers
- Risk Score Distribution: histogram with tier boundary lines annotated
- High-Risk Employee table: sortable/filterable list with Risk Score, Top 3 Drivers, Department, Manager — **row-level security restricted to HRBP/Director**
- Risk by Department: bar chart, % of dept population in High Risk tier
- "What-If" parameter slicers (what-if Engagement +10 → recalculated risk distribution) — using Power BI What-If parameters

**Layout Design:**
```
┌─────┬─────┬─────┬─────┬─────┐
│ KPI │ KPI │ KPI │ KPI │ KPI │
├──────────────────┬────────────────┤
│ Risk Tier Donut +  │ SHAP Feature   │
│ Validation Table   │ Importance bar │
├─────────┬─────────┴────────────────┤
│ Risk by │  High-Risk Employee Table │
│ Dept Bar│  (drill list, RLS)        │
├─────────┴───────────────────────────┤
│  What-If Engagement Sensitivity Bar  │
└────────────────────────────────────────┘
```

**User Journey:** HRBP opens page filtered to own department (via RLS) → reviews risk tier donut → scrolls high-risk employee table → for each named individual, reviews top-3 SHAP drivers to prepare a targeted retention conversation → uses what-if slicer to model "if I get this person a promotion, how does their risk change."

**Filters:** Global pane + Risk Tier slicer + "Model Run Date" slicer (for weekly refresh history).

**Drillthrough Logic:** Click any employee row → drillthrough to Employee Drillthrough (Page 13) for that individual's full profile, including historical engagement trend if available.

**Storytelling Flow:** How big is the problem (tier distribution + validation) → what causes it generally (SHAP global importance) → who specifically (employee table) → what can I do about it (what-if sensitivity).

**⚠️ RLS NOTE:** This page's employee-level table MUST be governed by row-level security — HRBPs see only their department; HR Director/CHRO see all. Implement via Power BI RLS roles mapped to `ManagerID`/`DepartmentID` hierarchy.

---

# PAGE 11 — DEPARTMENT INSIGHTS

**Business Objective:** Single-department deep-dive — the page every HRBP lives in daily. Designed to be entered primarily via drillthrough from other pages.

**KPIs:** (All KPIs from Pages 1-10, but filtered to ONE department) Headcount · Attrition Rate · Avg Engagement · Avg Salary · High Performer % · Avg Tenure · Compa-Ratio · Internal Mobility Rate

**Visuals:**
- KPI strip (8 cards) — department-specific values with company-average comparison arrows
- Department vs. Company Benchmark: bullet chart for each KPI (department value vs. company average vs. target)
- Headcount trend (if historical data available): line chart
- Top 5 Flight Risk individuals in this department: mini-table
- Manager list within department with mini-effectiveness scores: table
- Role/Level breakdown: treemap

**Layout Design:**
```
┌─────┬─────┬─────┬─────┬─────┬─────┬─────┬─────┐
│ KPI │ KPI │ KPI │ KPI │ KPI │ KPI │ KPI │ KPI │
├──────────────────────────┬────────────────────┤
│  Bullet Chart Grid         │  Headcount Trend   │
│  (8 KPIs vs benchmark)     │  Line Chart        │
├─────────────┬──────────────┴────────────────────┤
│ Top 5 Flight │  Manager List w/ Mini-Scores       │
│ Risk Table   │  (table)                           │
├──────────────┴────────────────────────────────────┤
│              Role/Level Treemap                    │
└─────────────────────────────────────────────────────┘
```

**User Journey:** This page is reached via drillthrough (right-click "Department" on any page 1-10 visual). HRBP reviews bullet charts to see exactly which KPIs are off-benchmark → checks top-5 flight risk table for immediate action items → reviews manager mini-scores to identify which team within the department needs support.

**Filters:** This page IS the filter — receives DepartmentName from drillthrough context. Includes a "Back" button (Power BI native drillthrough back arrow) plus a department selector for lateral navigation without returning to source page.

**Drillthrough Logic:** This is itself a drillthrough TARGET from Pages 1, 2, 3, 4, 5, 8. It is also a drillthrough SOURCE — clicking the Manager List → Manager Scorecard (Page 12); clicking Flight Risk table → Employee Drillthrough (Page 13).

**Storytelling Flow:** "How is MY department doing vs. company" (bullet charts) → "what's the trend" (headcount line) → "who needs my attention today" (flight risk table) → "which of my managers needs support" (manager list).

---

# PAGE 12 — MANAGER SCORECARD

**Business Objective:** Surfaces the Manager Effectiveness Score (Phase 4 stored procedure output) for HR Director performance conversations with people-leaders.

**KPIs:** Company Avg Effectiveness Score · % Managers in "Red" RAG · Avg Span of Control · % Managers Exceeding 15% Below-Expectations Threshold

**Visuals:**
- Manager Effectiveness Leaderboard: table — Manager Name, Dept, Team Size, Avg Engagement, Retention Rate, High Performer %, Effectiveness Score, RAG — sortable, top/bottom 10 highlighted
- Effectiveness Score Distribution: histogram with RAG zones colored
- Span of Control vs. Effectiveness Score: scatter plot (tests "is overload hurting effectiveness")
- Team Attrition Rate by Manager: bar chart, top 10 highest
- Effectiveness Score Components breakdown: stacked bar (Engagement component / Retention component / High-Performer component) for selected manager (via "Focus mode" on table row click)

**Layout Design:**
```
┌─────┬─────┬─────┬─────┐
│ KPI │ KPI │ KPI │ KPI │
├───────────────┬───────────────┤
│ Effectiveness  │ Score          │
│ Leaderboard    │ Distribution   │
│ (table, sort)  │ Histogram      │
├────────────────┼────────────────┤
│ Span vs Effect.│ Team Attrition │
│ Scatter        │ Top 10 Bar     │
├────────────────┴────────────────┤
│  Selected Manager: Component     │
│  Breakdown (stacked bar)         │
└────────────────────────────────────┘
```

**User Journey:** HR Director opens page → sorts leaderboard by Effectiveness Score ascending → identifies bottom-10 managers for coaching conversations → checks span-vs-effectiveness scatter to determine if low scores correlate with overload (structural fix) vs. individual coaching need → clicks a specific manager row to see component breakdown for a targeted conversation ("your retention component is what's dragging your score").

**Filters:** Global pane + "Management Level" slicer (Team-Lead / Manager / Director / VP).

**Drillthrough Logic:** Click any manager row → drillthrough to Department Insights (Page 11) filtered to that manager's team (using ManagerID, not DepartmentID, as the filter — requires a secondary drillthrough filter field).

**Storytelling Flow:** Overall manager population health (distribution) → who needs attention (leaderboard sorted) → is it structural or individual (span scatter) → specific coaching focus (component breakdown).

---

# PAGE 13 — EMPLOYEE DRILLTHROUGH

**Business Objective:** Individual employee profile page — the "single pane of glass" for an HRBP preparing for a 1:1 conversation. Accessed exclusively via drillthrough (never a primary navigation target).

**KPIs:** N/A (this is an individual record page, not an aggregate KPI page) — instead shows individual values with context.

**Visuals:**
- Employee header card: Name, Photo placeholder, Title, Department, Manager, Tenure, Location, Work Mode
- Individual metrics vs. department average: bullet charts for Salary (Compa-Ratio), Engagement, Satisfaction, Attendance, Performance Rating, Training Hours
- Flight Risk gauge with Top 3 SHAP drivers listed as annotated callouts
- Promotion history timeline: horizontal timeline showing hire date, promotion events, current tenure
- Compensation history (if historical comp events loaded): line chart of salary over time
- Recommended Actions panel: rule-based text recommendations (e.g., "Promotion gap of 3.2 years with Performance=5 — recommend promotion committee review")

**Layout Design:**
```
┌──────────────────────────────────────────────┐
│  Employee Header Card (name, title, dept...)  │
├───────────────┬────────────────────────────────┤
│ Individual vs  │  Flight Risk Gauge +          │
│ Dept Avg       │  Top 3 SHAP Drivers           │
│ Bullet Charts  │  (callout cards)              │
├────────────────┴────────────────────────────────┤
│  Promotion History Timeline                      │
├──────────────────────────────────────────────────┤
│  Compensation History Line Chart                 │
├──────────────────────────────────────────────────┤
│  Recommended Actions Panel (rule-based text)     │
└──────────────────────────────────────────────────┘
```

**User Journey:** HRBP arrives here exclusively via drillthrough from Page 3 (9-box), Page 10 (high-risk table), or Page 11 (top-5 flight risk). Reviews full individual context in under a minute, reads recommended actions, and exits to schedule a conversation.

**Filters:** None — fully driven by drillthrough filter context (single EmployeeID). Includes prominent "← Back" button.

**Drillthrough Logic:** This page is a TERMINAL drillthrough target — no further drillthrough from here except "Back" navigation.

**🔒 ROW-LEVEL SECURITY:** This page exposes PII (compensation, performance ratings, demographic data). RLS must restrict access to: the employee's own Manager, that Manager's chain up to CHRO, and HRBP assigned to that department. Implemented via Power BI RLS role mapped against `ManagerID` hierarchy table (recursive) and `HRBP_Assignment` mapping table (from Phase 2 RLS design).

**Storytelling Flow:** Who is this person (header) → how do they compare to peers (bullet charts) → why are they flagged (SHAP drivers) → what's their trajectory (promotion/comp history) → what should I do (recommended actions).

---

# PAGE 14 — AI INSIGHTS

**Business Objective:** Natural-language, AI-generated narrative summary of the current data state — democratizes insight access for non-technical executives. Accessible via persistent button from every page.

**KPIs:** N/A — narrative-first page, supporting visuals are secondary.

**Visuals:**
- AI Narrative Panel (large text area, top): auto-generated summary using Power BI's "Smart Narrative" visual, dynamically updated based on current filter context — e.g., *"Attrition rate is 23.8%, 5.8 points above the industry benchmark of 18%. Customer Success shows the highest departmental attrition at 34.3%, driven primarily by below-market compensation (avg compa-ratio 0.81) and declining engagement scores (avg 58.2, down from 64 last quarter)."*
- Key Influencers visual: Power BI native "Key Influencers" visual — "What influences Attrition = Yes?" with auto-discovered factors ranked
- Anomaly Detection chart: time-series with Power BI's built-in anomaly detection highlighting unusual spikes (requires historical data)
- Q&A Visual: natural-language query box (Power BI Q&A) pre-seeded with example questions: "What is attrition rate by department?", "Show engagement trend for Sales"
- Decomposition Tree: "Analyze Attrition Count by" — interactive AI-assisted breakdown allowing users to explore which dimension explains the most variance

**Layout Design:**
```
┌────────────────────────────────────────────────┐
│         AI Narrative Panel (Smart Narrative)     │
├───────────────────────┬───────────────────────────┤
│  Key Influencers       │   Anomaly Detection       │
│  (Attrition=Yes)       │   Time Series             │
├───────────────────────┴───────────────────────────┤
│  Decomposition Tree (Analyze Attrition Count by)   │
├──────────────────────────────────────────────────────┤
│  Q&A Natural Language Query Box                      │
└────────────────────────────────────────────────────────┘
```

**User Journey:** An executive who doesn't want to navigate 14 pages clicks "Insights" from anywhere → reads the auto-generated narrative for the current filter context → uses Key Influencers to understand causality → types a follow-up question in the Q&A box → uses decomposition tree to self-serve explore a specific curiosity without needing an analyst.

**Filters:** Inherits global filter context from whichever page the user clicked "Insights" from — all visuals respond to that context dynamically.

**Drillthrough Logic:** Key Influencers and Decomposition Tree nodes can right-click → drillthrough to Employee Drillthrough (Page 13) for the specific cohort identified.

**Storytelling Flow:** This page IS the story — it's designed for executives who want the narrative *told to them* rather than constructed by navigating visuals. The flow is: read → ask → explore → (optionally) drill to specifics.

---

# PAGE 15 — EXECUTIVE SUMMARY

**Business Objective:** The "print to PDF for the board deck" page — static-feeling, high information density, designed for export and offline distribution.

**KPIs:** All 10 KPI domain headline metrics (one per domain) in a single dense grid — Headcount, Attrition Rate, Retention Rate (HiPo), Engagement Score, Attendance Rate, Compa-Ratio, Time to Fill, High Performer %, Training Hours, Pay Equity Index.

**Visuals:**
- KPI Grid: 10 cards in a 2×5 grid, each with current value, prior period value, delta arrow, and RAG indicator
- Trend Mini-Charts: each KPI card includes a small embedded sparkline (12-period trend)
- Top 3 Wins this period: text callout box (e.g., "Pay equity gap narrowed from 3.1% to 2.3%")
- Top 3 Risks this period: text callout box (e.g., "Customer Success attrition increased to 34.3%, now highest of all departments")
- Department Summary Table: one row per department with 6 key metrics — designed for print legibility (alternating row shading, no scroll)
- Footer: Data refresh timestamp, model version (for flight risk score), prepared-by/for fields

**Layout Design:**
```
┌──────────────────────────────────────────────────┐
│   Title: "PeoplePulse Workforce Summary — [Date]"  │
├──────────────────┬───────────────────────────────────┤
│  KPI Grid (2×5)   │   Top 3 Wins / Top 3 Risks         │
│  w/ sparklines    │   (text callout boxes)            │
├──────────────────┴───────────────────────────────────┤
│         Department Summary Table (print-optimized)    │
├──────────────────────────────────────────────────────┤
│  Footer: refresh timestamp, model version, prepared-for│
└──────────────────────────────────────────────────────┘
```

**User Journey:** HR Director, the Friday before a Monday board meeting, opens this page, reviews the wins/risks callouts (manually curated or templated with dynamic text via DAX), exports to PDF (File → Export → PDF in Power BI Desktop, or scheduled via Power BI Service subscription), and attaches to the board pack.

**Filters:** Minimal — typically locked to "All" / company-wide view, since this is the summary-of-summaries. A single "As of Date" parameter if historical snapshots are available.

**Drillthrough Logic:** None — this is a terminal, export-oriented page by design. No interactive drilling expected (though technically still possible) since its purpose is static reproduction.

**Storytelling Flow:** This page doesn't need to "build" a narrative interactively — it presents the narrative pre-built: headline numbers → curated wins/risks (the "so what") → supporting department detail (the "evidence") → provenance footer (the "trust signal" — when was this generated, from what model version).

---

## CROSS-PAGE NAVIGATION MAP

```
                    ┌─────────────────────┐
                    │  Page 1: Executive   │ ◄────────────┐
                    │      Overview        │               │
                    └──────────┬───────────┘               │
                                │                            │
        ┌───────────┬──────────┼──────────┬───────────┐    │
        ▼           ▼          ▼          ▼           ▼    │
    ┌───────┐  ┌────────┐  ┌────────┐  ┌────────┐ ┌──────┐│
    │Page 2 │  │ Page 3 │  │ Page 4 │  │ Page 5 │ │Page 8││
    │Workfrc│  │Attrtion│  │Exp.    │  │ Comp   │ │Divers││
    └───┬───┘  └───┬────┘  └───┬────┘  └───┬────┘ └──┬───┘│
        │          │           │           │          │    │
        └──────────┴─────┬─────┴───────────┴──────────┘    │
                          ▼                                  │
                  ┌───────────────┐                          │
                  │  Page 11:      │──────┐                   │
                  │  Department    │      │                   │
                  │  Insights      │      ▼                   │
                  └───────┬────────┘  ┌────────────┐          │
                          │           │ Page 12:    │          │
                          ▼           │ Manager     │          │
                  ┌───────────────┐   │ Scorecard   │          │
                  │  Page 13:      │◄──┴────────────┘          │
                  │  Employee      │                            │
                  │  Drillthrough  │                            │
                  │  (terminal)    │                            │
                  └────────────────┘                            │
                                                                  │
    Page 6 (Recruitment), Page 7 (Performance), Page 9 (L&D),    │
    Page 10 (Predictive) ──► all drillthrough to Page 11 / 13 ───┤
                                                                  │
    Page 14 (AI Insights) ◄── accessible from ALL pages ─────────┤
    Page 15 (Executive Summary) ◄── accessible from Page 1 ──────┘
```

---

## ROW-LEVEL SECURITY (RLS) ROLE SUMMARY

| Role | Pages Fully Visible | Pages Restricted | Restriction Logic |
|---|---|---|---|
| **CEO/CHRO** | All 15 | None | No row filters |
| **HR Director** | All 15 | Page 13 (own division only) | `Department IN (assigned divisions)` |
| **HRBP** | 1,3,4,10,11,12,13 | Pages 5 (comp detail), 13 | `DepartmentID = [user's assigned dept]` |
| **TA Director** | 1,6,2,8 | Pages 5,10,13 | `Page = 'Recruitment*' OR Page IN (1,2,8)` |
| **L&D Director** | 1,9 | All others | `Page IN (1,9)` |
| **Total Rewards** | 1,5,8 | Page 13 (comp fields only) | `Page IN (1,5,8)` |
| **Manager (self-service)** | 11,12 (own team only) | All employee-level detail | `ManagerID = CURRENTUSER()` |

---

*Document: PeoplePulse AI Power BI Architecture v1.0*
*Prepared by: Senior Power BI Architect*
*Classification: Internal — BI Development Team*
