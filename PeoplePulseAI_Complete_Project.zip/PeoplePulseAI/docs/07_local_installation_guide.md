# PeoplePulse AI — Local Installation Guide

This guide takes a developer from a fresh clone to a fully running platform
(database + ML model + Power BI-ready data + Streamlit app) on a local machine.

---

## Step 1 — Install Python

PeoplePulse AI requires **Python 3.11 or higher**.

**Windows:** Download from [python.org](https://www.python.org/downloads/) and check "Add Python to PATH" during install.
**macOS:** `brew install python@3.11`
**Linux:** `sudo apt install python3.11 python3.11-venv`

Verify:
```bash
python3 --version
# Expected output: Python 3.11.x or higher
```

**Common error:** `command not found: python3` on Windows — use `python` instead of `python3` for all commands in this guide.

---

## Step 2 — Clone and Create a Virtual Environment

```bash
git clone https://github.com/yourname/peoplepulse-ai.git
cd PeoplePulseAI

python3 -m venv venv

# Activate it:
source venv/bin/activate        # macOS / Linux
venv\Scripts\activate           # Windows
```

You should see `(venv)` prepended to your terminal prompt once activated.

**Common error:** `Permission denied` on macOS/Linux when activating — run `chmod +x venv/bin/activate` first.

---

## Step 3 — Install Dependencies

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

**Expected output:** ~15 packages installed successfully, ending with `Successfully installed ...`. This typically takes 1-3 minutes.

**Common errors:**
- `error: Microsoft Visual C++ 14.0 required` (Windows) — install [Visual C++ Build Tools](https://visualstudio.microsoft.com/visual-cpp-build-tools/), needed for xgboost/shap compilation.
- `pyodbc` install fails — this package is only needed for SQL Server connectivity. If you're using PostgreSQL (recommended default), you can comment out the `pyodbc` line in `requirements.txt`.
- `shap` install is slow — this is normal; it compiles C extensions. Allow 2-3 minutes.

---

## Step 4 — Configure Environment Variables

```bash
cp .env.example .env
```

Open `.env` and confirm/adjust:
```
DB_ENGINE=postgresql
DEMO_MODE=true        # leave as 'true' for local development — uses
                       # the hardcoded demo accounts, no DB auth needed
```

For this guide, **`DEMO_MODE=true` is sufficient** — you do not need to set up a database to run the Streamlit app, since it reads directly from `data/PeoplePulse_HR_Dataset.csv`. Database setup (Step 5) is only required if you want to query the data via SQL or connect Power BI to a live database rather than the CSV.

---

## Step 5 — (Optional) Database Setup

Skip this step if you only want to run the Streamlit app and Power BI against the CSV file directly.

See **`docs/03_database_deployment_guide.md`** for full instructions covering PostgreSQL, MySQL, and SQL Server. Quick path for PostgreSQL:

```bash
# Install PostgreSQL if not already installed (macOS example):
brew install postgresql@16
brew services start postgresql@16

# Create the database and user
psql postgres -c "CREATE DATABASE peoplepulse;"
psql postgres -c "CREATE USER peoplepulse_app WITH PASSWORD 'changeme';"
psql postgres -c "GRANT ALL PRIVILEGES ON DATABASE peoplepulse TO peoplepulse_app;"

# Deploy schema
psql -d peoplepulse -f sql/postgresql_schema.sql

# Load data
python scripts/load_data.py
```

**Expected output:** `✅ Data load complete.` after roughly 10-30 seconds.

**Common errors:**
- `psql: command not found` — PostgreSQL client tools aren't on PATH; on macOS run `brew link postgresql@16`.
- `FATAL: password authentication failed` — double check `.env` `DB_PASSWORD` matches what you set in the `CREATE USER` command.
- `relation "hr.ref_department" does not exist` during data load — the schema script didn't run successfully; check for errors in its output before re-running `load_data.py`.

---

## Step 6 — Generate / Verify the Dataset

The dataset already exists at `data/PeoplePulse_HR_Dataset.csv` (10,000 rows). To regenerate it from scratch (e.g., after modifying the generation logic):

```bash
python data/generate_hr_dataset.py
```

**Expected output:** Console prints a quality report ending with:
```
✅ Dataset saved to: data/PeoplePulse_HR_Dataset.csv
   File shape: 10,000 rows × 24 columns
```

---

## Step 7 — Train the ML Model

```bash
python ml_models/train_attrition_model.py
```

**Expected output:** ~30-90 seconds of console output covering feature engineering, 4 model training runs, SHAP computation, and risk segmentation, ending with:
```
PHASE 8 COMPLETE
SUMMARY:
  - Production model: Logistic Regression (AUC=0.6010)
  - Precision@Top10% lift: 1.62x over random selection
  - All 9,712 active employees scored and segmented
```

This produces (or refreshes) `ml_models/attrition_predictions.csv`, `ml_models/active_employee_risk_list.csv`, `ml_models/feature_importance.csv`, `ml_models/model_comparison.csv`, and `assets/shap_summary.png`.

**Common errors:**
- `ModuleNotFoundError: No module named 'xgboost'` — re-run Step 3, ensure the virtual environment is activated.
- Script runs but AUC differs slightly from documented values — minor version differences in scikit-learn/xgboost can shift results by ±0.01-0.02; this is expected and not a bug.

---

## Step 8 — Set Up Power BI (Windows / Power BI Desktop)

See **`docs/04_powerbi_deployment_guide.md`** for the complete walkthrough. Quick path:

1. Open Power BI Desktop → Get Data → Text/CSV → select `data/PeoplePulse_HR_Dataset.csv`
2. Get Data again → Text/CSV → select `ml_models/attrition_predictions.csv`
3. In Model view, create relationship: `HR_Data[Employee_ID]` → `Predictions[Employee_ID]` (1:1)
4. Create a new table named `Measures`
5. Paste DAX from `powerbi/dax_measures_phase4.dax` and `docs/07_advanced_dax.md`
6. Build report pages per `docs/06_powerbi_architecture.md`

---

## Step 9 — Launch the Streamlit Application

```bash
cd streamlit_app
streamlit run Home.py
```

**Expected output:**
```
You can now view your Streamlit app in your browser.
Local URL: http://localhost:8501
```

Your browser should open automatically. If not, navigate to `http://localhost:8501`.

**Login with any demo account**, e.g.:
- Email: `ceo@peoplepulse.ai`
- Password: `admin123`

**Common errors:**
- `Address already in use` — another process is using port 8501; run `streamlit run Home.py --server.port=8502` instead.
- Blank page / "Please wait..." forever — check the terminal for a Python traceback; most commonly caused by `data/PeoplePulse_HR_Dataset.csv` not being found (confirm you're running from the `streamlit_app/` directory, or that `DATA_PATH` in `.env` is correct).
- `KeyError: 'user'` — clear your browser's local storage for localhost:8501 or open in an incognito window; this happens if a previous session's state is stale after a code change.

---

## Step 10 — Run the Test Suite (Validation)

```bash
cd ..   # back to project root
pytest tests/ -v
```

**Expected output:** `77 passed` (or more, if you've added tests) in under 5 seconds.

If any test fails, the failure message will point to the specific data quality, KPI, model, or RBAC issue — see `docs/08_testing_and_validation.md` for how to interpret failures.

---

## Summary — Full Command Sequence

```bash
git clone https://github.com/yourname/peoplepulse-ai.git
cd PeoplePulseAI
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python ml_models/train_attrition_model.py
pytest tests/ -v
cd streamlit_app
streamlit run Home.py
```

From a clean clone, this entire sequence takes approximately **5-8 minutes** on a typical laptop.
