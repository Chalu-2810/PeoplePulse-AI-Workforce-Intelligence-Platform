"""
PeoplePulse AI — Universal Data Loader
=========================================
Loads PeoplePulse_HR_Dataset.csv into the configured database
(PostgreSQL / MySQL / SQL Server) using SQLAlchemy, resolving
natural-key columns (Department, Location, etc.) to the surrogate
keys defined in the reference tables.

Prerequisites:
  1. Run the appropriate schema script first:
       - sql/postgresql_schema.sql  (psql -f ...)
       - sql/mysql_schema.sql
       - sql/mssql_schema.sql
  2. Configure .env with DATABASE_URL (or DB_ENGINE + DB_* components)

Usage:
    python scripts/load_data.py
    python scripts/load_data.py --csv data/PeoplePulse_HR_Dataset.csv
    python scripts/load_data.py --truncate   # wipe hr.employee before loading
"""

import os
import argparse
import pandas as pd
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

load_dotenv()


def build_connection_string() -> str:
    explicit = os.getenv("DATABASE_URL", "").strip()
    if explicit:
        return explicit

    engine = os.getenv("DB_ENGINE", "postgresql").lower()
    host = os.getenv("DB_HOST", "localhost")
    port = os.getenv("DB_PORT", "5432")
    name = os.getenv("DB_NAME", "peoplepulse")
    user = os.getenv("DB_USER", "peoplepulse_app")
    pwd  = os.getenv("DB_PASSWORD", "")

    if engine == "postgresql":
        return f"postgresql+psycopg2://{user}:{pwd}@{host}:{port}/{name}"
    elif engine == "mysql":
        return f"mysql+pymysql://{user}:{pwd}@{host}:{port}/{name}"
    elif engine == "mssql":
        return f"mssql+pyodbc://{user}:{pwd}@{host}:{port}/{name}?driver=ODBC+Driver+18+for+SQL+Server"
    else:
        raise ValueError(f"Unsupported DB_ENGINE: {engine}")


def to_sql_kwargs(engine_name: str) -> dict:
    """MySQL has no schema namespaces — tables are prefixed (hr_employee)
    rather than namespaced (hr.employee). PostgreSQL/MSSQL use schema=."""
    if engine_name == "mysql":
        return {"schema": None}
    return {"schema": "hr"}


def table_name(engine_name: str, base: str) -> str:
    """Returns 'employee' for Postgres/MSSQL (used with schema='hr') or
    'hr_employee' for MySQL (no schema, prefixed table name)."""
    return f"hr_{base}" if engine_name == "mysql" else base


def main():
    parser = argparse.ArgumentParser(description="Load PeoplePulse HR dataset into the database")
    parser.add_argument("--csv", default="data/PeoplePulse_HR_Dataset.csv")
    parser.add_argument("--truncate", action="store_true", help="Truncate hr.employee before loading")
    args = parser.parse_args()

    conn_str = build_connection_string()
    engine_name = os.getenv("DB_ENGINE", "postgresql").lower()
    engine = create_engine(conn_str)
    print(f"Connecting to: {conn_str.split('@')[-1]}")

    df = pd.read_csv(args.csv)
    df["Exit_Reason"] = df["Exit_Reason"].fillna("N/A")
    print(f"Loaded CSV: {df.shape[0]:,} rows x {df.shape[1]} columns")

    sql_kwargs = to_sql_kwargs(engine_name)
    t_employee = table_name(engine_name, "employee")
    t_dept = table_name(engine_name, "ref_department")
    t_loc = table_name(engine_name, "ref_location")
    t_src = table_name(engine_name, "ref_recruitment_source")
    t_frs = table_name(engine_name, "flight_risk_score")
    schema_prefix = "hr." if engine_name != "mysql" else ""

    with engine.connect() as conn:
        dept_map = dict(conn.execute(text(f"SELECT department_name, department_id FROM {schema_prefix}{t_dept}")).fetchall())
        loc_map  = dict(conn.execute(text(f"SELECT location_name, location_id FROM {schema_prefix}{t_loc}")).fetchall())
        src_map  = dict(conn.execute(text(f"SELECT source_name, source_id FROM {schema_prefix}{t_src}")).fetchall())

        missing_depts = set(df["Department"].unique()) - set(dept_map.keys())
        missing_locs  = set(df["Location"].unique()) - set(loc_map.keys())
        missing_srcs  = set(df["Recruitment_Source"].unique()) - set(src_map.keys())
        if missing_depts or missing_locs or missing_srcs:
            raise ValueError(
                f"Reference data mismatch — run the schema script's seed section first.\n"
                f"Missing departments: {missing_depts}\nMissing locations: {missing_locs}\n"
                f"Missing sources: {missing_srcs}"
            )

        if args.truncate:
            print(f"Truncating {schema_prefix}{t_employee} (and dependent flight_risk_score rows)...")
            if engine_name == "postgresql":
                conn.execute(text(f"TRUNCATE TABLE {schema_prefix}{t_frs} CASCADE"))
                conn.execute(text(f"TRUNCATE TABLE {schema_prefix}{t_employee} CASCADE"))
            else:
                conn.execute(text(f"DELETE FROM {schema_prefix}{t_frs}"))
                conn.execute(text(f"DELETE FROM {schema_prefix}{t_employee}"))
            conn.commit()

        # Build load-ready dataframe with resolved FKs
        load_df = pd.DataFrame({
            "employee_id":          df["Employee_ID"],
            "employee_name":        df["Employee_Name"],
            "age":                  df["Age"],
            "gender":               df["Gender"],
            "department_id":        df["Department"].map(dept_map),
            "job_role":             df["Job_Role"],
            "job_level":            df["Job_Level"],
            "manager_id":           df["Manager_ID"],
            "location_id":          df["Location"].map(loc_map),
            "work_mode":            df["Work_Mode"],
            "years_at_company":     df["Years_At_Company"],
            "salary":               df["Salary"],
            "bonus":                df["Bonus"],
            "recruitment_source_id": df["Recruitment_Source"].map(src_map),
            "performance_rating":   df["Performance_Rating"],
            "performance_label":    df["Performance_Label"],
            "attendance_pct":       df["Attendance_Pct"],
            "training_hours":       df["Training_Hours"],
            "engagement_score":     df["Engagement_Score"],
            "satisfaction_score":   df["Satisfaction_Score"],
            "promotions":           df["Promotions"],
            "leave_count":          df["Leave_Count"],
            "attrition":            df["Attrition"],
            "exit_reason":          df["Exit_Reason"].replace("N/A", None),
        })

        # IMPORTANT: insert in two passes to satisfy the self-referencing
        # manager_id FK — first insert all rows with manager_id=NULL,
        # then UPDATE to set manager_id (avoids FK ordering errors since
        # managers may appear later in the file than their reports).
        load_df_pass1 = load_df.drop(columns=["manager_id"])
        manager_lookup = load_df[["employee_id", "manager_id"]].copy()

        print(f"Inserting {len(load_df_pass1):,} employees (pass 1, manager_id deferred)...")
        load_df_pass1.to_sql(t_employee, engine, if_exists="append", index=False, method="multi", chunksize=500, **sql_kwargs)

        print("Updating manager_id (pass 2)...")
        with engine.begin() as update_conn:
            for _, row in manager_lookup.iterrows():
                if pd.notna(row["manager_id"]):
                    update_conn.execute(
                        text(f"UPDATE {schema_prefix}{t_employee} SET manager_id = :mgr WHERE employee_id = :emp"),
                        {"mgr": row["manager_id"], "emp": row["employee_id"]}
                    )

    print("\n✅ Data load complete.")
    print("   Run sql/validation/run_validation.sql to verify row counts and referential integrity.")


if __name__ == "__main__":
    main()
