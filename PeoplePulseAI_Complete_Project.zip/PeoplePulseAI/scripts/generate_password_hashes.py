"""
PeoplePulse AI — Password Hash Generator
==========================================
Generates SHA-256 hashes for the demo user passwords, matching the
algorithm used in streamlit_app/utils/helpers.py (`_hash()` function).

Usage:
    python scripts/generate_password_hashes.py
    python scripts/generate_password_hashes.py --password "MyNewPassword123"

With no arguments, prints hashes for all 5 demo passwords and ready-to-paste
SQL INSERT statements for hr.app_user (matches sql/postgresql_schema.sql).
"""

import hashlib
import argparse


def hash_password(pw: str) -> str:
    return hashlib.sha256(pw.encode()).hexdigest()


DEMO_USERS = [
    ("ceo@peoplepulse.ai",          "Victoria Chen",   "admin123", "CEO/CHRO",      None),
    ("hrdirector@peoplepulse.ai",   "Marcus Williams", "hrdir123", "HR Director",   None),
    ("hrbp.cs@peoplepulse.ai",      "Priya Nair",      "hrbp123",  "HRBP",          "Customer Success"),
    ("hrbp.eng@peoplepulse.ai",     "Rachel Kim",      "hrbp123",  "HRBP",          "Engineering"),
    ("totalrewards@peoplepulse.ai", "David Osei",      "comp123",  "Total Rewards", None),
    ("admin@peoplepulse.ai",        "System Admin",    "super123", "Admin",         None),
]


def main():
    parser = argparse.ArgumentParser(description="Generate SHA-256 password hashes")
    parser.add_argument("--password", help="Generate hash for a single custom password")
    args = parser.parse_args()

    if args.password:
        print(f"Password: {args.password}")
        print(f"SHA-256:  {hash_password(args.password)}")
        return

    print("=" * 70)
    print("DEMO USER PASSWORD HASHES")
    print("=" * 70)
    for email, name, pw, role, dept in DEMO_USERS:
        print(f"{email:32s} | {pw:10s} -> {hash_password(pw)}")

    print("\n" + "=" * 70)
    print("READY-TO-PASTE SQL (PostgreSQL / hr.app_user)")
    print("=" * 70)
    for email, name, pw, role, dept in DEMO_USERS:
        h = hash_password(pw)
        if dept:
            print(f"""INSERT INTO hr.app_user (email, full_name, password_hash, role, department_id)
SELECT '{email}', '{name}', '{h}', '{role}', department_id
FROM hr.ref_department WHERE department_name='{dept}';
""")
        else:
            print(f"""INSERT INTO hr.app_user (email, full_name, password_hash, role, department_id)
VALUES ('{email}', '{name}', '{h}', '{role}', NULL);
""")


if __name__ == "__main__":
    main()
