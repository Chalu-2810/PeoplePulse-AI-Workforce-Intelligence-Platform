"""
PeoplePulse AI — Enterprise HR Dataset Generator
=================================================
10,000 employee records with realistic business distributions.
Simulates actual workforce patterns seen in Fortune 500 organizations.

Design Philosophy:
  - Every column is causally related to others (salary driven by role + level + location + tenure)
  - Attrition is correlated (low engagement + low pay + no promotion = high attrition)
  - Distributions mirror real HRIS data (right-skewed tenure, bimodal performance, etc.)
  - Manager hierarchy is realistic (span of control 5-12, 6 org levels)
"""

import pandas as pd
import numpy as np
from faker import Faker
import warnings
warnings.filterwarnings("ignore")

np.random.seed(42)
fake = Faker()
Faker.seed(42)

N = 10_000

# ─────────────────────────────────────────────────────────────────
# 1. WORKFORCE STRUCTURE DEFINITIONS
# ─────────────────────────────────────────────────────────────────

DEPARTMENTS = {
    "Engineering":         {"weight": 0.22, "pay_multiplier": 1.35, "attrition_base": 0.14},
    "Product":             {"weight": 0.08, "pay_multiplier": 1.40, "attrition_base": 0.13},
    "Sales":               {"weight": 0.18, "pay_multiplier": 1.10, "attrition_base": 0.20},
    "Marketing":           {"weight": 0.08, "pay_multiplier": 1.05, "attrition_base": 0.16},
    "Finance":             {"weight": 0.07, "pay_multiplier": 1.15, "attrition_base": 0.09},
    "Human Resources":     {"weight": 0.05, "pay_multiplier": 0.95, "attrition_base": 0.12},
    "Operations":          {"weight": 0.12, "pay_multiplier": 0.90, "attrition_base": 0.17},
    "Customer Success":    {"weight": 0.07, "pay_multiplier": 0.88, "attrition_base": 0.22},
    "Legal & Compliance":  {"weight": 0.03, "pay_multiplier": 1.30, "attrition_base": 0.07},
    "Data & Analytics":    {"weight": 0.05, "pay_multiplier": 1.38, "attrition_base": 0.13},
    "IT Infrastructure":   {"weight": 0.05, "pay_multiplier": 1.10, "attrition_base": 0.11},
}

ROLES_BY_DEPT = {
    "Engineering":        ["Software Engineer I", "Software Engineer II", "Senior Software Engineer",
                           "Staff Engineer", "Principal Engineer", "Engineering Manager",
                           "Senior Engineering Manager", "Director of Engineering", "VP Engineering"],
    "Product":            ["Associate Product Manager", "Product Manager", "Senior Product Manager",
                           "Principal PM", "Group Product Manager", "Director of Product", "VP Product"],
    "Sales":              ["Sales Development Rep", "Account Executive", "Senior Account Executive",
                           "Enterprise AE", "Sales Manager", "Regional Sales Director", "VP Sales"],
    "Marketing":          ["Marketing Coordinator", "Marketing Manager", "Senior Marketing Manager",
                           "Growth Marketing Manager", "Marketing Director", "VP Marketing"],
    "Finance":            ["Financial Analyst", "Senior Financial Analyst", "Finance Manager",
                           "Senior Finance Manager", "Controller", "Director of Finance", "VP Finance", "CFO"],
    "Human Resources":    ["HR Coordinator", "HR Business Partner", "Senior HRBP", "HR Manager",
                           "Talent Acquisition Specialist", "TA Manager", "HR Director", "CHRO"],
    "Operations":         ["Operations Analyst", "Operations Specialist", "Operations Manager",
                           "Senior Operations Manager", "Director of Operations", "VP Operations"],
    "Customer Success":   ["Customer Success Rep", "Customer Success Manager", "Senior CSM",
                           "Enterprise CSM", "CS Team Lead", "Director of Customer Success"],
    "Legal & Compliance": ["Paralegal", "Associate Counsel", "Counsel", "Senior Counsel",
                           "Deputy General Counsel", "General Counsel"],
    "Data & Analytics":   ["Data Analyst", "Senior Data Analyst", "Data Scientist", "Senior Data Scientist",
                           "Analytics Manager", "Principal Data Scientist", "Director of Analytics"],
    "IT Infrastructure":  ["IT Support Specialist", "Systems Administrator", "Network Engineer",
                           "Senior Systems Engineer", "IT Manager", "Director of IT"],
}

# Level-to-base-salary mapping (USD, annual base, national median)
ROLE_LEVEL_SALARY = {
    "L1": (55_000,  68_000),   # Entry / Coordinator / Support
    "L2": (68_000,  85_000),   # Associate / Analyst I
    "L3": (85_000, 110_000),   # Specialist / Analyst II / Engineer I
    "L4": (110_000, 140_000),  # Senior Specialist / Engineer II
    "L5": (140_000, 175_000),  # Staff / Principal / Senior Manager
    "L6": (175_000, 230_000),  # Director
    "L7": (230_000, 320_000),  # VP / Senior Director
    "L8": (320_000, 500_000),  # C-Suite
}

ROLE_TO_LEVEL = {
    # Engineering
    "Software Engineer I": "L3", "Software Engineer II": "L4",
    "Senior Software Engineer": "L4", "Staff Engineer": "L5",
    "Principal Engineer": "L5", "Engineering Manager": "L5",
    "Senior Engineering Manager": "L5", "Director of Engineering": "L6",
    "VP Engineering": "L7",
    # Product
    "Associate Product Manager": "L3", "Product Manager": "L4",
    "Senior Product Manager": "L4", "Principal PM": "L5",
    "Group Product Manager": "L5", "Director of Product": "L6", "VP Product": "L7",
    # Sales
    "Sales Development Rep": "L2", "Account Executive": "L3",
    "Senior Account Executive": "L4", "Enterprise AE": "L4",
    "Sales Manager": "L5", "Regional Sales Director": "L6", "VP Sales": "L7",
    # Marketing
    "Marketing Coordinator": "L2", "Marketing Manager": "L4",
    "Senior Marketing Manager": "L4", "Growth Marketing Manager": "L4",
    "Marketing Director": "L6", "VP Marketing": "L7",
    # Finance
    "Financial Analyst": "L3", "Senior Financial Analyst": "L4",
    "Finance Manager": "L4", "Senior Finance Manager": "L5",
    "Controller": "L5", "Director of Finance": "L6",
    "VP Finance": "L7", "CFO": "L8",
    # HR
    "HR Coordinator": "L2", "HR Business Partner": "L3",
    "Senior HRBP": "L4", "HR Manager": "L4",
    "Talent Acquisition Specialist": "L3", "TA Manager": "L4",
    "HR Director": "L6", "CHRO": "L8",
    # Operations
    "Operations Analyst": "L3", "Operations Specialist": "L3",
    "Operations Manager": "L4", "Senior Operations Manager": "L5",
    "Director of Operations": "L6", "VP Operations": "L7",
    # Customer Success
    "Customer Success Rep": "L2", "Customer Success Manager": "L3",
    "Senior CSM": "L4", "Enterprise CSM": "L4",
    "CS Team Lead": "L4", "Director of Customer Success": "L6",
    # Legal
    "Paralegal": "L2", "Associate Counsel": "L3",
    "Counsel": "L4", "Senior Counsel": "L5",
    "Deputy General Counsel": "L6", "General Counsel": "L7",
    # Data
    "Data Analyst": "L3", "Senior Data Analyst": "L4",
    "Data Scientist": "L4", "Senior Data Scientist": "L5",
    "Analytics Manager": "L5", "Principal Data Scientist": "L5",
    "Director of Analytics": "L6",
    # IT
    "IT Support Specialist": "L2", "Systems Administrator": "L3",
    "Network Engineer": "L3", "Senior Systems Engineer": "L4",
    "IT Manager": "L4", "Director of IT": "L6",
}

LOCATIONS = {
    "San Francisco, CA":  {"weight": 0.14, "cost_mult": 1.30, "region": "West"},
    "New York, NY":       {"weight": 0.16, "cost_mult": 1.28, "region": "Northeast"},
    "Austin, TX":         {"weight": 0.12, "cost_mult": 1.05, "region": "South"},
    "Seattle, WA":        {"weight": 0.10, "cost_mult": 1.22, "region": "West"},
    "Chicago, IL":        {"weight": 0.09, "cost_mult": 1.08, "region": "Midwest"},
    "Boston, MA":         {"weight": 0.07, "cost_mult": 1.18, "region": "Northeast"},
    "Denver, CO":         {"weight": 0.07, "cost_mult": 1.02, "region": "West"},
    "Atlanta, GA":        {"weight": 0.06, "cost_mult": 0.97, "region": "South"},
    "Remote - US":        {"weight": 0.12, "cost_mult": 0.95, "region": "Remote"},
    "London, UK":         {"weight": 0.04, "cost_mult": 1.15, "region": "EMEA"},
    "Toronto, Canada":    {"weight": 0.03, "cost_mult": 0.88, "region": "Canada"},
}

RECRUITMENT_SOURCES = {
    "LinkedIn":           0.28,
    "Employee Referral":  0.22,
    "Company Website":    0.12,
    "Indeed":             0.10,
    "Recruiter/Agency":   0.09,
    "University Campus":  0.08,
    "Glassdoor":          0.06,
    "Internal Transfer":  0.05,
}

WORK_MODES = {
    "On-site":    0.28,
    "Hybrid":     0.45,
    "Remote":     0.27,
}

EXIT_REASONS = [
    "Better Opportunity", "Higher Compensation", "Work-Life Balance",
    "Career Growth", "Relocation", "Manager Issues",
    "Company Culture", "Role Mismatch", "Personal Reasons", "Retirement"
]

PERFORMANCE_LABELS = {
    1: "Unacceptable",
    2: "Below Expectations",
    3: "Meets Expectations",
    4: "Exceeds Expectations",
    5: "Distinguished",
}

# ─────────────────────────────────────────────────────────────────
# 2. GENERATE BASE EMPLOYEE RECORDS
# ─────────────────────────────────────────────────────────────────

print("Generating base employee records...")

emp_ids = [f"EMP{str(i).zfill(5)}" for i in range(10001, 10001 + N)]

# Gender — realistic enterprise distribution
genders = np.random.choice(
    ["Male", "Female", "Non-binary"],
    size=N,
    p=[0.54, 0.43, 0.03]
)

# First/Last names by gender
first_names, last_names = [], []
for g in genders:
    if g == "Male":
        first_names.append(fake.first_name_male())
    elif g == "Female":
        first_names.append(fake.first_name_female())
    else:
        first_names.append(fake.first_name())
    last_names.append(fake.last_name())

full_names = [f"{f} {l}" for f, l in zip(first_names, last_names)]

# Age — bimodal: early-career cluster (22-30) and mid-career (32-52)
ages_young  = np.random.normal(26, 3, int(N * 0.38)).clip(22, 32)
ages_mid    = np.random.normal(40, 8, int(N * 0.50)).clip(30, 62)
ages_senior = np.random.normal(56, 4, N - int(N*0.38) - int(N*0.50)).clip(52, 67)
ages = np.concatenate([ages_young, ages_mid, ages_senior])
np.random.shuffle(ages)
ages = ages[:N].astype(int)

# Department — weighted distribution
dept_names  = list(DEPARTMENTS.keys())
dept_weights = [DEPARTMENTS[d]["weight"] for d in dept_names]
departments  = np.random.choice(dept_names, size=N, p=dept_weights)

# Job Role — sampled within department
job_roles = []
for dept in departments:
    roles = ROLES_BY_DEPT[dept]
    # Weight toward IC roles (more junior) — realistic pyramid
    n_roles = len(roles)
    role_weights = np.array([max(1, n_roles - i) for i in range(n_roles)], dtype=float)
    role_weights /= role_weights.sum()
    job_roles.append(np.random.choice(roles, p=role_weights))

job_roles = np.array(job_roles)

# Level for each role
levels = np.array([ROLE_TO_LEVEL.get(r, "L3") for r in job_roles])

# Years at Company — right-skewed (exponential-like), clipped to age constraint
# Most companies have median tenure ~3-4 years (SHRM benchmarks)
yac_raw = np.random.exponential(scale=3.8, size=N)
years_at_company = np.clip(yac_raw, 0.25, 35).round(1)
# Constrain: can't have more years at company than (age - 18)
years_at_company = np.minimum(years_at_company, ages - 18)
years_at_company = np.maximum(years_at_company, 0.25)

# ─────────────────────────────────────────────────────────────────
# 3. LOCATION & WORK MODE
# ─────────────────────────────────────────────────────────────────

print("Assigning locations and work modes...")

loc_names   = list(LOCATIONS.keys())
loc_weights = [LOCATIONS[l]["weight"] for l in loc_names]
locations   = np.random.choice(loc_names, size=N, p=loc_weights)

# Work mode — correlated with location (Remote employees more likely to be in Remote-US)
work_modes = []
for loc in locations:
    if loc == "Remote - US":
        wm = np.random.choice(["Remote", "Hybrid"], p=[0.88, 0.12])
    else:
        wm = np.random.choice(["On-site", "Hybrid", "Remote"], p=[0.32, 0.50, 0.18])
    work_modes.append(wm)
work_modes = np.array(work_modes)

# ─────────────────────────────────────────────────────────────────
# 4. SALARY — Driven by role level + department + location + tenure
# ─────────────────────────────────────────────────────────────────

print("Computing realistic salaries...")

salaries = []
bonuses  = []
for i in range(N):
    level   = levels[i]
    dept    = departments[i]
    loc     = locations[i]
    tenure  = years_at_company[i]

    sal_min, sal_max = ROLE_LEVEL_SALARY[level]
    pay_mult = DEPARTMENTS[dept]["pay_multiplier"]
    cost_mult = LOCATIONS[loc]["cost_mult"]

    # Base from level range — tenure creates position within band
    tenure_factor = min(tenure / 8, 1.0)  # maxes out at 8 years in band
    base_position = 0.35 + tenure_factor * 0.55  # between 35th and 90th percentile of band
    noise = np.random.normal(0, 0.04)             # compa-ratio noise ±4%

    base = sal_min + (sal_max - sal_min) * np.clip(base_position + noise, 0, 1)
    base *= pay_mult * cost_mult

    # Gender pay gap simulation — systemic but not legal (unexplained ~3%)
    if genders[i] == "Female" and level in ["L3", "L4", "L5"]:
        gap = np.random.uniform(0.96, 1.00)  # 0-4% gap to model
        base *= gap

    salaries.append(round(base / 1000) * 1000)  # round to nearest $1K

    # Bonus — % of base, driven by level and department
    if dept == "Sales":
        bonus_pct = np.random.triangular(0.05, 0.20, 0.60)
    elif level in ["L6", "L7", "L8"]:
        bonus_pct = np.random.triangular(0.10, 0.25, 0.45)
    elif level == "L5":
        bonus_pct = np.random.triangular(0.05, 0.15, 0.30)
    else:
        bonus_pct = np.random.triangular(0.03, 0.08, 0.20)

    bonus = round(base * bonus_pct / 500) * 500
    bonuses.append(bonus)

salaries = np.array(salaries, dtype=int)
bonuses  = np.array(bonuses, dtype=int)

# ─────────────────────────────────────────────────────────────────
# 5. PERFORMANCE RATING — Calibrated bell curve with realistic skew
# ─────────────────────────────────────────────────────────────────

print("Generating performance ratings...")

# Real enterprise distribution (post-calibration):
# 5% Distinguished, 25% Exceeds, 55% Meets, 12% Below, 3% Unacceptable
perf_scores = np.random.choice(
    [5, 4, 3, 2, 1],
    size=N,
    p=[0.05, 0.25, 0.55, 0.12, 0.03]
)

# Slight correlation: longer tenure employees slightly more likely to exceed
tenure_boost = (years_at_company > 5).astype(float) * 0.05
for i in range(N):
    if tenure_boost[i] > 0 and perf_scores[i] == 3 and np.random.random() < 0.12:
        perf_scores[i] = 4

perf_labels = np.array([PERFORMANCE_LABELS[p] for p in perf_scores])

# ─────────────────────────────────────────────────────────────────
# 6. ENGAGEMENT & SATISFACTION — Correlated with performance and pay
# ─────────────────────────────────────────────────────────────────

print("Computing engagement and satisfaction scores...")

engagement_scores   = []
satisfaction_scores = []

for i in range(N):
    perf    = perf_scores[i]
    tenure  = years_at_company[i]
    level   = levels[i]
    dept    = departments[i]

    # Base engagement from performance (high performers slightly more engaged)
    eng_base = {5: 82, 4: 74, 3: 63, 2: 48, 1: 35}[perf]
    eng_noise = np.random.normal(0, 8)

    # Tenure effect: honeymoon (0-1yr high), dip at 2-4yr, rises if survived
    if tenure < 1:
        eng_tenure_adj = 8
    elif tenure < 3:
        eng_tenure_adj = np.random.uniform(-5, 2)
    elif tenure < 7:
        eng_tenure_adj = np.random.uniform(-3, 5)
    else:
        eng_tenure_adj = np.random.uniform(2, 10)

    # Department culture effect
    dept_eng_adj = {
        "Engineering": 3, "Product": 4, "Finance": 1,
        "Sales": -2, "Customer Success": -4, "Operations": -3,
        "Legal & Compliance": 2, "Data & Analytics": 5,
        "Human Resources": 1, "Marketing": 2, "IT Infrastructure": 0,
    }.get(dept, 0)

    eng = np.clip(eng_base + eng_noise + eng_tenure_adj + dept_eng_adj, 10, 100)
    engagement_scores.append(round(eng, 1))

    # Satisfaction correlated with engagement but distinct construct
    # Pay satisfaction component
    sal_i = salaries[i]
    sal_level_median = np.mean(ROLE_LEVEL_SALARY[level])
    pay_sat_adj = np.clip((sal_i - sal_level_median) / sal_level_median * 20, -10, 15)

    sat = np.clip(eng * 0.70 + pay_sat_adj + np.random.normal(5, 8), 10, 100)
    satisfaction_scores.append(round(sat, 1))

engagement_scores   = np.array(engagement_scores)
satisfaction_scores = np.array(satisfaction_scores)

# ─────────────────────────────────────────────────────────────────
# 7. ATTENDANCE PERCENTAGE — Correlated with engagement
# ─────────────────────────────────────────────────────────────────

print("Generating attendance patterns...")

attendance_pcts = []
for i in range(N):
    eng = engagement_scores[i]
    # High engagement → high attendance
    att_base = 88 + (eng - 50) * 0.15
    att_noise = np.random.normal(0, 3)
    # Remote workers have slightly lower recorded attendance
    if work_modes[i] == "Remote":
        att_noise -= 1.5
    att = np.clip(att_base + att_noise, 60, 100)
    attendance_pcts.append(round(att, 1))

attendance_pcts = np.array(attendance_pcts)

# ─────────────────────────────────────────────────────────────────
# 8. TRAINING HOURS — Driven by level, performance, and department
# ─────────────────────────────────────────────────────────────────

print("Computing training hours...")

training_hours = []
for i in range(N):
    level = levels[i]
    perf  = perf_scores[i]
    dept  = departments[i]

    # Base by level: senior roles invest more in learning
    base_hours = {
        "L1": 18, "L2": 22, "L3": 28, "L4": 35,
        "L5": 42, "L6": 38, "L7": 30, "L8": 20
    }[level]

    # Performance: high performers pursue more training
    perf_adj = {5: 18, 4: 10, 3: 0, 2: -5, 1: -8}[perf]

    # Department culture
    dept_adj = {
        "Engineering": 12, "Data & Analytics": 15, "Product": 8,
        "Sales": 20, "Human Resources": 10, "Legal & Compliance": 18,
        "Finance": 8, "Customer Success": 12, "IT Infrastructure": 14,
        "Operations": 5, "Marketing": 6
    }.get(dept, 0)

    noise = np.random.normal(0, 6)
    hours = np.clip(base_hours + perf_adj + dept_adj + noise, 4, 120)
    training_hours.append(round(hours, 1))

training_hours = np.array(training_hours)

# ─────────────────────────────────────────────────────────────────
# 9. PROMOTION HISTORY — Correlated with tenure, performance, level
# ─────────────────────────────────────────────────────────────────

print("Simulating promotion history...")

promotions = []
for i in range(N):
    tenure = years_at_company[i]
    perf   = perf_scores[i]
    level  = levels[i]

    # More promotions with longer tenure
    expected_promos = tenure / 2.8   # average 1 promo per ~2.8 years

    # Performance multiplier
    perf_mult = {5: 1.8, 4: 1.3, 3: 0.9, 2: 0.5, 1: 0.2}[perf]

    # Senior roles have fewer promotions (rarer at top)
    level_mult = {"L1": 1.2, "L2": 1.1, "L3": 1.0, "L4": 0.9,
                  "L5": 0.7, "L6": 0.5, "L7": 0.3, "L8": 0.1}[level]

    promos = np.random.poisson(expected_promos * perf_mult * level_mult)
    promos = np.clip(promos, 0, int(tenure / 1.2))
    promotions.append(int(promos))

promotions = np.array(promotions)

# ─────────────────────────────────────────────────────────────────
# 10. LEAVE COUNT (annual leave days taken)
# ─────────────────────────────────────────────────────────────────

leave_counts = []
for i in range(N):
    eng  = engagement_scores[i]
    dept = departments[i]

    # Low engagement → more sick/personal leave
    base_leave = np.random.normal(12, 4)
    disengaged_adj = max(0, (50 - eng) * 0.15)

    dept_adj = {
        "Customer Success": 3, "Sales": 2, "Operations": 2,
        "Legal & Compliance": -1, "Finance": -1
    }.get(dept, 0)

    leave = np.clip(base_leave + disengaged_adj + dept_adj, 0, 30)
    leave_counts.append(int(round(leave)))

leave_counts = np.array(leave_counts)

# ─────────────────────────────────────────────────────────────────
# 11. RECRUITMENT SOURCE — slight dept correlations
# ─────────────────────────────────────────────────────────────────

recruit_sources = []
for i in range(N):
    dept  = departments[i]
    level = levels[i]

    sources = list(RECRUITMENT_SOURCES.keys())
    weights = list(RECRUITMENT_SOURCES.values())

    # Engineers more likely via LinkedIn/referral
    if dept in ["Engineering", "Data & Analytics"]:
        weights[0] *= 1.25  # LinkedIn
        weights[1] *= 1.30  # Referral

    # Entry roles more via campus/Indeed
    if level in ["L1", "L2"]:
        weights[5] *= 2.0   # Campus
        weights[3] *= 1.40  # Indeed

    # Senior roles more via agency
    if level in ["L6", "L7", "L8"]:
        weights[4] *= 2.5   # Agency
        weights[7] *= 2.0   # Internal Transfer

    weights = np.array(weights)
    weights /= weights.sum()
    recruit_sources.append(np.random.choice(sources, p=weights))

recruit_sources = np.array(recruit_sources)

# ─────────────────────────────────────────────────────────────────
# 12. MANAGER ASSIGNMENT — Realistic org hierarchy
# ─────────────────────────────────────────────────────────────────

print("Building manager hierarchy...")

# Identify manager-eligible employees (L5+)
manager_eligible = [i for i in range(N) if levels[i] in ["L5", "L6", "L7", "L8"]]

manager_ids = []
for i in range(N):
    if levels[i] in ["L7", "L8"]:
        manager_ids.append("EMP10001")  # CEO / top of org
    elif levels[i] == "L6":
        # VP/SVP reports to C-suite
        vp_pool = [j for j in manager_eligible if levels[j] in ["L7", "L8"]]
        mgr = np.random.choice(vp_pool) if vp_pool else 0
        manager_ids.append(emp_ids[mgr])
    elif levels[i] == "L5":
        dir_pool = [j for j in manager_eligible if levels[j] == "L6"
                    and departments[j] == departments[i]]
        if not dir_pool:
            dir_pool = [j for j in manager_eligible if levels[j] == "L6"]
        mgr = np.random.choice(dir_pool) if dir_pool else 0
        manager_ids.append(emp_ids[mgr] if dir_pool else "EMP10001")
    else:
        # IC/Analyst reports to a manager in same department
        mgr_pool = [j for j in manager_eligible if levels[j] in ["L4", "L5"]
                    and departments[j] == departments[i]]
        if not mgr_pool:
            mgr_pool = [j for j in manager_eligible if departments[j] == departments[i]]
        if not mgr_pool:
            mgr_pool = manager_eligible[:10]
        mgr = np.random.choice(mgr_pool)
        manager_ids.append(emp_ids[mgr])

manager_ids = np.array(manager_ids)

# ─────────────────────────────────────────────────────────────────
# 13. ATTRITION STATUS — Causally modeled, not random
# ─────────────────────────────────────────────────────────────────

print("Modeling attrition outcomes causally...")

attrition_flags = []
exit_reasons    = []

for i in range(N):
    dept    = departments[i]
    eng     = engagement_scores[i]
    sat     = satisfaction_scores[i]
    perf    = perf_scores[i]
    tenure  = years_at_company[i]
    level   = levels[i]
    promos  = promotions[i]
    sal     = salaries[i]
    level_mid = np.mean(ROLE_LEVEL_SALARY[level])

    # Base attrition rate from department
    base_rate = DEPARTMENTS[dept]["attrition_base"]

    # === ATTRITION DRIVERS (additive logistic model) ===

    # 1. Engagement driver — strongest predictor
    eng_risk = max(0, (60 - eng) * 0.006)          # adds up to +0.06 per 10pt drop

    # 2. No promotion frustration
    expected_promos = max(1, tenure / 3)
    promo_gap = max(0, expected_promos - promos - 1)
    promo_risk = promo_gap * 0.03

    # 3. Pay dissatisfaction
    pay_ratio = sal / (level_mid * DEPARTMENTS[dept]["pay_multiplier"])
    pay_risk = max(0, (0.85 - pay_ratio) * 0.15) if pay_ratio < 0.85 else 0

    # 4. Tenure risk — highest in years 1-2 and after year 7
    if tenure < 1:
        tenure_risk = 0.12
    elif tenure < 2:
        tenure_risk = 0.08
    elif tenure < 5:
        tenure_risk = 0.01
    elif tenure < 8:
        tenure_risk = 0.02
    else:
        tenure_risk = 0.04

    # 5. Performance risk: both low and high performers leave more
    if perf == 5:
        perf_risk = 0.04   # HiPos poached externally
    elif perf == 4:
        perf_risk = 0.00
    elif perf == 3:
        perf_risk = 0.01
    elif perf == 2:
        perf_risk = 0.06
    else:
        perf_risk = 0.12   # PIP → likely exit

    # 6. Attendance: chronic absence → higher attrition
    att_risk = max(0, (85 - attendance_pcts[i]) * 0.003)

    # Total attrition probability
    total_risk = base_rate + eng_risk + promo_risk + pay_risk + tenure_risk + perf_risk + att_risk
    total_risk = np.clip(total_risk, 0.02, 0.85)

    left = np.random.random() < total_risk
    attrition_flags.append("Yes" if left else "No")

    if left:
        # Assign exit reason based on driving factor
        if pay_risk > 0.08:
            reason = "Higher Compensation"
        elif eng < 40:
            reason = np.random.choice(["Manager Issues", "Company Culture", "Work-Life Balance"])
        elif promo_gap > 2:
            reason = np.random.choice(["Career Growth", "Better Opportunity"])
        elif perf == 1 or perf == 2:
            reason = np.random.choice(["Role Mismatch", "Personal Reasons"])
        elif tenure > 20:
            reason = "Retirement"
        else:
            reason = np.random.choice(EXIT_REASONS, p=[0.22, 0.18, 0.14, 0.16, 0.06, 0.08, 0.06, 0.04, 0.04, 0.02])
        exit_reasons.append(reason)
    else:
        exit_reasons.append("N/A")

attrition_flags = np.array(attrition_flags)
exit_reasons    = np.array(exit_reasons)

# ─────────────────────────────────────────────────────────────────
# 14. ASSEMBLE DATAFRAME
# ─────────────────────────────────────────────────────────────────

print("Assembling final dataset...")

df = pd.DataFrame({
    "Employee_ID":          emp_ids,
    "Employee_Name":        full_names,
    "Age":                  ages,
    "Gender":               genders,
    "Department":           departments,
    "Job_Role":             job_roles,
    "Job_Level":            levels,
    "Manager_ID":           manager_ids,
    "Location":             locations,
    "Work_Mode":            work_modes,
    "Years_At_Company":     years_at_company,
    "Salary":               salaries,
    "Bonus":                bonuses,
    "Recruitment_Source":   recruit_sources,
    "Performance_Rating":   perf_scores,
    "Performance_Label":    perf_labels,
    "Attendance_Pct":       attendance_pcts,
    "Training_Hours":       training_hours,
    "Engagement_Score":     engagement_scores,
    "Satisfaction_Score":   satisfaction_scores,
    "Promotions":           promotions,
    "Leave_Count":          leave_counts,
    "Attrition":            attrition_flags,
    "Exit_Reason":          exit_reasons,
})

# ─────────────────────────────────────────────────────────────────
# 15. QUALITY CHECKS
# ─────────────────────────────────────────────────────────────────

print("\n===== DATASET QUALITY REPORT =====")
print(f"Total records:        {len(df):,}")
print(f"Attrition rate:       {(df['Attrition']=='Yes').mean()*100:.1f}%")
print(f"Avg salary:           ${df['Salary'].mean():,.0f}")
print(f"Median tenure:        {df['Years_At_Company'].median():.1f} years")
print(f"Avg engagement:       {df['Engagement_Score'].mean():.1f}/100")
print(f"Avg satisfaction:     {df['Satisfaction_Score'].mean():.1f}/100")
print(f"Avg attendance:       {df['Attendance_Pct'].mean():.1f}%")
print(f"Avg training hrs:     {df['Training_Hours'].mean():.1f}")
print(f"\nGender split:\n{df['Gender'].value_counts()}")
print(f"\nTop 5 departments:\n{df['Department'].value_counts().head()}")
print(f"\nPerformance distribution:\n{df['Performance_Label'].value_counts()}")
print(f"\nAttrition by department:")
att = df.groupby("Department")["Attrition"].apply(lambda x: (x=="Yes").mean()*100).round(1)
print(att.sort_values(ascending=False))
print(f"\nRecruitment source split:\n{df['Recruitment_Source'].value_counts()}")

# ─────────────────────────────────────────────────────────────────
# 16. SAVE
# ─────────────────────────────────────────────────────────────────

output_path = "/mnt/user-data/outputs/PeoplePulse_HR_Dataset.csv"
df.to_csv(output_path, index=False)
print(f"\n✅ Dataset saved to: {output_path}")
print(f"   File shape: {df.shape[0]:,} rows × {df.shape[1]} columns")
